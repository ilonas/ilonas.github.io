var wixdocs = require('wixdocs-static');

wixdocs({
    dir: __dirname,
    theme : 'odin',
    jsdoc : {
        conf : __dirname + '/jsdoc.conf.json',
        filtering : false
    },
    lessTarget : __dirname + '/jsdoc/assets/jsdoc.less',
    sourcePath: "jsdoc/wixdocs",
    assetsPath: {"source": __dirname + "/jsdoc/assets/images", "destination" : "images" },
    distPath : "jsdoc/site",
    searchText : "Search SDK",
    siteTitle: "Wix JS SDK",
    logoUrl: "http://wix.github.io/js-sdk-docs/",
    themeOptions : {
        logoTitle : "Code",
        jumboTitle : 'API Reference',
        jumboSubTitle: 'Information about the Wix JS SDK'
    },
    clean : true,
    slidingMenus : false,
    headingLevel : 2,
    navLevel : 3,
    analytics: 'UA-65338180-1',
    debug: true,
    watchDirs : [
        'js/**/*'
    ]
});