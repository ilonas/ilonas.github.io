var webpack = require('webpack');
var path = require('path');

module.exports = function (options) {
    var entry = [
        options.entry || "./js/Wix.js"
    ];

    var output = {
        path: __dirname + '/build',
        filename: options.filename || "Wix.js",
        pathinfo: options.minimize ? false: true
    };

    var resolve = {
        root: path.resolve('./js/modules'),
        extensions: ['', '.js']
    };

    var plugins =  [
        new webpack.NoErrorsPlugin()
    ];

    if(options.minimize) {
        plugins.push(new webpack.optimize.UglifyJsPlugin({minimize: true}));
    }

    return {
        entry: entry,
        output: output,
        module: {
            loaders: [
                { test: /\.js?$/, loaders: ['babel'], exclude: /node_modules/ },
                { test: /\.js$/, exclude: /node_modules/, loader: 'babel-loader'},
                { test: require.resolve("./js/Wix"), loader: "expose?Wix" },
                { test: /\.js$/, loaders: ['jshint-loader'], exclude: [/node_modules/, /vendors/]  }
            ]
        },
        resolve: resolve,
        plugins: plugins
    };
};