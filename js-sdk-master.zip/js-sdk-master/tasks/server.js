module.exports = function(grunt) {
	var express = require("express");
	grunt.registerTask("server", "static file development server", function() {

		var app, webPort, webRoot, distRoot;
		function getFileContent(fileName, callback){
			fs = require('fs');
			fs.readFile(fileName, 'utf8', function (err,data) {
				if (err) {
					return console.log(err);
				}
				return callback(data);
			});
		}


		webPort = grunt.config.get("server.web.port") || Math.floor(Math.random() * 8000) + 1;
		app = express();
		app.use(express.static(process.cwd()));
		app.get("/_api/app-integration-bus-web/v1/contacts", function(req, res){
			res.type('application/json');
			getFileContent('src/test/server/stub/contacts.ok.json', function(data){
				res.send(data);
			});
		});

        app.get("/_api/app-integration-bus-web/v1/contacts/:contactId", function(req, res){
            console.log(req.params.contactId);
            res.type('application/json');
            getFileContent('src/test/server/stub/contactById.ok.json', function(data){
                res.send(data);
            });
        });

		app.get("/api/contacts/error", function(request, res){
			res.type('application/json');
			getFileContent('src/test/server/stub/contacts.error.json', function(data){
				res.send(data);
			});
		});

		app.use(express.errorHandler());
		app.listen(webPort);
		grunt.log.writeln("Starting express web server in \"./dev\" on port " + webPort);
		return app;

	});
};