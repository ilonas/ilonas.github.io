/**
 * @memberof Wix
 * @namespace Wix.Contacts
 */
define(['privates/utils', 'privates/responseHandlers', 'privates/reporter', 'privates/postMessage'], function (utils, responseHandlers, reporter, postMessage) {

    var namespace = 'Contacts';

    var getContacts = function (options, onSuccess, onFailure) {
        if (!utils.isObject(options)) {
            reporter.reportSdkError('Missing mandatory argument - options, must be an object');
            return;
        }

        if (!utils.isFunction(onSuccess)) {
            reporter.reportSdkError('Missing mandatory argument - onSuccess, must be a function');
            return;
        }

        var args = {
            options: options
        };

        var onComplete = function onComplete(response) {
            responseHandlers.handleCursorResponse(response, onSuccess, onFailure, postMessage.MessageTypes.GET_CONTACTS, options);
        };

        postMessage.sendMessage(postMessage.MessageTypes.GET_CONTACTS, namespace, args, onComplete);
    };

    var getContactById = function (id, onSuccess, onFailure) {
        if (typeof id !== 'string') {
            reporter.reportSdkError('Missing mandatory argument - id, must be a string');
            return;
        }

        if (!utils.isFunction(onSuccess)) {
            reporter.reportSdkError('Missing mandatory argument - onSuccess, must be a function');
            return;
        }

        if (!utils.isFunction(onFailure)) {
            reporter.reportSdkError('Missing mandatory argument - onFailure, must be a function');
            return;
        }

        var args = {
            id: id
        };

        var onComplete = function onComplete(response) {
            responseHandlers.handleDataResponse(response, onSuccess, onFailure);
        };

        postMessage.sendMessage(postMessage.MessageTypes.GET_CONTACT_BY_ID, namespace, args, onComplete);
    };

    function validateReconcileParams(contactInfo, onSuccess, onFailure) {
        var result = {
            passed: false
        };
        if (contactInfo === undefined) {
            result = {
                passed: false,
                error: 'Missing mandatory contact options parameter'
            };
        } else if (!utils.isObject(contactInfo)) {
            result = {
                passed: false,
                error: 'Contact options parameter must be an object'
            };
        } else if (onSuccess && !utils.isFunction(onSuccess)) {
            result = {
                passed: false,
                error: 'Missing mandatory argument - onSuccess, must be a function'
            };
        } else if (onFailure && !utils.isFunction(onFailure)) {
            result = {
                passed: false,
                error: 'Missing mandatory argument - onFailure, must be a function'
            };
        } else {
            result = {
                passed: true
            };
        }
        return result;
    }
    var reconcileContact = function (contactInfo, onSuccess, onFailure) {
        var validation = validateReconcileParams(contactInfo, onSuccess, onFailure);
        if (validation.passed) {
            var onComplete = function onComplete(response) {
                responseHandlers.handleDataResponse(response, onSuccess, onFailure);
            };
            postMessage.sendMessage(postMessage.MessageTypes.RECONCILE_CONTACT, namespace, contactInfo, onComplete);
        } else {
            reporter.reportSdkError(validation.error);
        }
    };
    return {
        /**
         * Gets a list of all contacts that have interacted with a given site.
         * @memberof Wix.Contacts
         * @author lior.shefer@wix.com
         * @since  1.31.0
         * @function
         * @param {Object} options object that supports two parameters: 'label' and 'pageSize'.
         * 'label' can either be a list of strings or a string. if a list, the strings are joined together with a comma
         * to be sent to the contacts endpoint. 'pageSize' accepts either 25, 50 or 100 and defaults to 25.
         * @param {Function} onSuccess An on success callback which gets WixDataCursor as parameter.
         * @param {Function} onFailure An on failure callback.
         * @return {WixDataCursor} cursor.
         * @example
         * Wix.Contacts.getContacts(function(WixDataCursor), function(errorType));
         */
        getContacts: getContacts,

        /**
         * Gets a specific Contact that has interacted with the current site by its id.
         * @memberof Wix.Contacts
         * @author lior.shefer@wix.com
         * @since 1.27.0
         * @function
         * @param {String} id The id of the Contact to look up.
         * @param {Function} onSuccess A function that receives data about the Contact.
         * @param {Function} onFailure A function called when an error occurs that receives a Wix.Error.
         * @return {Contact}
         */
        getContactById: getContactById,

        /**
         * Reconciles Contact information with that of the WixHive's.
         *
         * Use this when your app has information about a site visitor that may already be registered as a Contact as part of the WixHive. Your app should provide as much information as possible so that we will find the best match for that Contact and return it with the reconciled information. If no match was found, we will create a new Contact.
         *
         * Depending on the type of information, we will either add or dismiss changes. When the information can be added to a list, such as emails or phones, a new item will be added if no similar item exists. When the information cannot be added we dismiss the change, such is the case with name, company and picture. If your wish is to override such data, there are explicit ways to do so using the Contact’s id and our REST API.
         *
         * @memberof Wix.Contacts
         * @author benk@wix.com
         * @since 1.46.0
         * @function
         * @param {Object} contactInfo Contact information that will be passed to the server.
         * @param {Function} [onSuccess] A function that receives reconciliation details.
         * @param {Function} [onFailure] A function called when an error occurs, receives a Wix.Error.
         * @return {ReconcileContactResult} Contains the reconciled Contact and details about the operation.
         */
        reconcileContact: reconcileContact
    };
});
