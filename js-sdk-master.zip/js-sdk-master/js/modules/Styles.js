/**
 * This is the description for the Styles namespace.
 * @memberof Wix
 * @namespace Wix.Styles
 */
define(['privates/postMessage', 'privates/reporter', 'privates/styles', 'privates/utils', 'privates/sharedAPI'], function (postMessage, reporter, styles, utils, sharedAPI) {

    var namespace = 'Styles';

    var EDITOR_PARAM_TYPES = ['color', 'number', 'boolean', 'font'];

    var getDynamicCallback = function (onSuccess, onError) {
        return function (data) {
            if (data && data.onError) {
                if (onError) {
                    onError.apply(this, arguments);
                }
            } else {
                if (onSuccess) {
                    onSuccess.apply(this, arguments);
                }
            }
        };
    };

    var isValidStyleType = function (type) {
        return EDITOR_PARAM_TYPES.indexOf(type) > -1;
    };

    var getNormalizedStyleParamsObj = function (type, key, value) {
        if (!isValidStyleType(type)) {
            reporter.reportSdkError('Invalid editor param type: "' + type + '"');
            return false;
        }
        if (!utils.isString(key)) {
            reporter.reportSdkError('Invalid key name');
            return false;
        }
        if (!utils.isObject(value)) {
            reporter.reportSdkError('Invalid value');
            return false;
        }

        return {
            key: key,
            type: type,
            param: value
        };
    };

    var getStyleParams = function (callback) {
        postMessage.sendMessage(postMessage.MessageTypes.GET_STYLE_PARAMS, namespace);
        return sharedAPI.getStyleParams(callback);
    };

    var setStyleParams = function (styleObjArr, onSuccess, onError) {
        if (!utils.isArray(styleObjArr)) {
            reporter.reportSdkError(styleObjArr + ' is not a valid styles array.');
            return;
        }

        var mappedStyleObjArr = [];
        var styleObj;
        var normalized;
        for (var i = 0; i < styleObjArr.length; i++) {
            styleObj = styleObjArr[i];

            if (!utils.has(styleObj, 'key') ||!utils.has(styleObj, 'type') ||!utils.has(styleObj, 'value')) {
                reporter.reportSdkError('styleObjArr[' + i + '] is not a valid style object.');
                return utils.isFunction(onError) && onError();
            }

            normalized = getNormalizedStyleParamsObj(styleObj.type, styleObj.key, styleObj.value);
            if (!normalized) {
                return utils.isFunction(onError) && onError();
            }
            mappedStyleObjArr.push(normalized);
        }

        var callback = getDynamicCallback(onSuccess, onError);
        postMessage.sendMessage(postMessage.MessageTypes.SET_STYLE_PARAM, namespace, mappedStyleObjArr, callback);
    };

    var setFontParam = function (key, value, onSuccess, onError) {
        sharedAPI.setEditorParam(namespace, 'font', key, value, onSuccess, onError);
    };

    var getEditorFonts = function (callback) {
        postMessage.sendMessage(postMessage.MessageTypes.GET_EDITOR_FONTS, namespace);
        return sharedAPI.getStyle(callback, 'fontsMeta');
    };

    var getSiteTextPresets = function(callback){
        postMessage.sendMessage(postMessage.MessageTypes.GET_SITE_TEXT_PRESETS, namespace);
        return sharedAPI.getStyle(callback, 'siteTextPresets');
    };

    var getFontsSpriteUrl = function (callback){
        postMessage.sendMessage(postMessage.MessageTypes.GET_FONTS_SPRITE_URL, namespace);
        return sharedAPI.getStyle(callback, 'fontsSpriteUrl');
    };

    var getStyleFontByKey = function (fontKey){
        postMessage.sendMessage(postMessage.MessageTypes.GET_STYLE_FONT_BY_KEY, namespace);
        return styles.Cache.mappedFonts && styles.Cache.mappedFonts['style.' + fontKey];
    };

    var getStyleFontByReference = function (fontReference) {
        postMessage.sendMessage(postMessage.MessageTypes.GET_STYLE_FONT_BY_REFERENCE, namespace);
        return  styles.Cache.siteTextPresets && styles.Cache.siteTextPresets[fontReference];
    };

    var getSiteColors = function (callback) {
        postMessage.sendMessage(postMessage.MessageTypes.GET_SITE_COLORS, namespace);
        return sharedAPI.getStyle(callback, 'siteColors');
    };

    var getStyleColorByKey = function (colorKey) {
        postMessage.sendMessage(postMessage.MessageTypes.GET_STYLE_COLOR_BY_KEY, namespace);
        return sharedAPI.getStyleColorByKey(colorKey);
    };

    var getColorByreference = function (colorReference) {
        postMessage.sendMessage(postMessage.MessageTypes.GET_COLOR_BY_REFERENCE, namespace);
        return sharedAPI.getColorByreference(colorReference);
    };

    var setColorParam = function (key, value, onSuccess, onError){
        postMessage.sendMessage(postMessage.MessageTypes.SET_COLOR_PARAM, namespace);
        sharedAPI.setColorParam(namespace, key, value, onSuccess, onError);
    };

    var setNumberParam = function (key, value, onSuccess, onError) {
        postMessage.sendMessage(postMessage.MessageTypes.SET_NUMBER_PARAM, namespace);
        sharedAPI.setEditorParam(namespace, 'number', key, value, onSuccess, onError);
    };

    var setBooleanParam = function (key, value, onSuccess, onError) {
        postMessage.sendMessage(postMessage.MessageTypes.SET_BOOLEAN_PARAM, namespace);
        sharedAPI.setEditorParam(namespace, 'boolean', key, value, onSuccess, onError);
    };

    var openColorPicker = function (params, callback) {
        postMessage.sendMessage(postMessage.MessageTypes.OPEN_COLOR_PICKER, namespace,
            params, callback);
    };

    var openFontPicker = function (params, callback) {
        postMessage.sendMessage(postMessage.MessageTypes.OPEN_FONT_PICKER, namespace,
            params, callback);
    };

    var setUILIBParamValue = function (type, key, value) {
        postMessage.sendMessage(postMessage.MessageTypes.SET_UI_LIB_PARAM_VALUE, namespace);
        styles.Cache.style[type][key] = value;
    };

    var getStyleId = function(callback){
        if (!callback) {
            reporter.reportSdkError('Mandatory arguments - a callback must be specified');
            return;
        } else if (!utils.isFunction(callback)) {
            reporter.reportSdkError('Invalid argument - callback should be of type Function');
            return;
        }
        postMessage.sendMessage(postMessage.MessageTypes.GET_STYLE_ID, namespace, {}, callback);
    };

    var getStyleParamsByStyleId = function(styleId, onSuccess, onFailure){
        if (!styleId || !onSuccess) {
            reporter.reportSdkError('Mandatory arguments - styleId & onSuccess must be specified');
            return;
        }
        if(!utils.isString(styleId)) {
            reporter.reportSdkError('Invalid argument - styleId must be of type string');
            return;
        }
        if (!utils.isFunction(onSuccess)) {
            reporter.reportSdkError('Invalid argument - onSuccess must be of type Function');
            return;
        }
        if (onFailure && !utils.isFunction(onFailure)) {
            reporter.reportSdkError('Invalid argument - onFailure must be of type Function');
            return;
        }

        var callback = function (data) {
            if (data.error) {
                if (onFailure) {
                    onFailure(data.error);
                }
            } else {
                var normalizeData = styles.normalizeColorThemeName(data);
                onSuccess(normalizeData);
            }
        };

        var args = {styleId: styleId};
        postMessage.sendMessage(postMessage.MessageTypes.GET_STYLE_PARAMS_BY_STYLE_ID, namespace, args, callback);
    };

    return {
        /**
         *
         * The getStyleParams method is used to retrieve the style parameters from the hosting Wix Platform.
         * The parameters includes colors numbers, booleans.
         * @function
         * @memberof Wix.Styles
         * @since 1.26.0
         * @param {Function} callback Callback function to retrieve the style values.
         * @example
         *
         * Wix.Styles.getStyleParams( function(styleParams) {
         *    //do something with the style params
         * });
         */
        getStyleParams: getStyleParams,

        /**
         * Sets multiple style parameters in one call.
         * @function
         * @memberof Wix.Styles
         * @private
         * @since 1.61.0
         * @param {Array} an array of objects. Each object describes a style change and must contain a type {String} ('color'/'number'/'boolean'/'font'), key {String} and value {Object}.
         * @param {Function} onSuccess A callback function, returns an object containing the updated styleProperties.
         * @param {Function} onFailure Will be invoked in case of error.
         *
         * @example
         *
         *  var styleChangesArr = [{
         *   "type": "font",
         *   "key": "layout",
         *   "value": {
         *     "value": {
         *       "value": "layout4",
         *       "fontStyleParam": false
         *     }
         *   }
         * }, {
         *   "type": "boolean",
         *   "key": "widgetButtonToggle",
         *   "value": {
         *     "value": true
         *   }
         * }]
         *
         * Wix.Styles.setStyleParams(styleChangesArr, function(styleProperties){console.log('success')}, function(){console.log('failure')})
         * */
        setStyleParams: setStyleParams,

        /**
         * Sets a style font parameter in the Wix site
         *
         * @function
         * @memberof Wix.Styles
         * @private
         * @since 1.47.0
         * @param {String} key a unique key describing a boolean style parameter that was chosen by the developer in the ui-lib component.
         * @param {Object} value to store.
         * @param {Function} onSuccess A callback function, returns on object containing styleProperties.
         * @param {Function} onFailure This will be called in case of error.
         */
        setFontParam: setFontParam,

        /**
         * Returns the list of Wix fonts meta data from the editor
         *
         * @function
         * @memberof Wix.Styles
         * @private
         * @since 1.26.0
         * @param {Function} callback A callback function to pass the Editor's font.
         */
        getEditorFonts: getEditorFonts,

        /**
         *
         * Returns the list of the text presets from the editor
         * @function
         * @memberof Wix.Styles
         * @private
         * @since 1.26.0
         * @param {Function} callback A callback function to pass the text presets.
         */
        getSiteTextPresets: getSiteTextPresets,

        /**
         *
         * Returns the url of the Wix fonts sprite, used to render the font picker.
         *
         * @function
         * @memberof Wix.Styles
         * @private
         * @since 1.26.0
         * @param {Function} callback A callback function to pass the sprite url.
         */
        getFontsSpriteUrl: getFontsSpriteUrl,

        /**
         *
         * Returns style font by a unique key
         *
         * @function
         * @memberof Wix.Styles
         * @private
         * @since 1.26.0
         * @param {String} fontKey The font key that was chosen by the developer in the ui-lib component.
         * @return {Object}
         */
        getStyleFontByKey: getStyleFontByKey,

        /**
         *
         * Returns a style font by it's reference name
         *
         * @private
         * @function
         * @memberof Wix.Styles
         * @since 1.26.0
         * @param {String} fontReference Font reference, e.g., 'Title'.
         * @return {Object}
         */
        getStyleFontByReference: getStyleFontByReference,

        /**
         * Function getSiteColors
         *
         * Returns the currently active site colors
         * @private
         * @function
         * @memberof Wix.Styles
         * @since 1.26.0
         * @param {Function} callback
         */
        getSiteColors: getSiteColors,

        /**
         *
         * Returns the css color value of saved style parameter
         *
         * @private
         * @function
         * @memberof Wix.Styles
         * @since 1.26.0
         * @param {String} colorKey A unique key describing a color style parameter that was chosen by the developer in the ui-lib component.
         * @return {String} css Color string. e.g., "#FFFFFF" or "rgba(0,0,0,0.5)"
         */
        getStyleColorByKey: getStyleColorByKey,

        /**
         *
         * Returns the color object of editor style
         *
         * @private
         * @function
         * @memberof Wix.Styles
         * @since 1.26.0
         * @param {String} colorReference A unique key describing a theme color parameter.
         * @return {Object} data A map describing a Wix style color.
         */
        getColorByreference: getColorByreference,

        /**
         *
         * Sets a style color parameter
         *
         * @private
         * @function
         * @memberof Wix.Styles
         * @since 1.47.0
         * @param {String} key A unique key describing a color style parameter that was chosen by the developer in the ui-lib component.
         * @param {Object} value
         * @param {Function} onSuccess A callback function, returns on object containing styleProperties.
         * @param {Function} onFailure This will be called in case of error.
         */
        setColorParam: setColorParam,

        /**
         * Function setNumberParam
         *
         * Sets a style number parameter
         *
         * @private
         * @function
         * @memberof Wix.Styles
         * @since 1.47.0
         * @param {String} key A unique key describing a number style parameter that was chosen by the developer in the ui-lib component.
         * @param {Object} value
         * @param {Function} onSuccess A callback function, returns on object containing styleProperties.
         * @param {Function} onFailure This will be called in case of error.
         */
        setNumberParam: setNumberParam,

        /**
         * Function setBooleanParam
         *
         * Sets a style boolean parameter
         *
         * @private
         * @function
         * @memberof Wix.Styles
         * @since 1.47.0
         * @param {String} key A unique key describing a boolean style parameter that was chosen by the developer in the ui-lib component.
         * @param {Object} value
         * @param {Function} onSuccess A callback function, returns on object containing styleProperties.
         * @param {Function} onFailure This will be called in case of error.
         */
        setBooleanParam: setBooleanParam,

        /**
         * Function openColorPicker
         * Opens the editor color picker panel
         * @memberof Wix.Styles
         * @private
         * @since 1.61.0
         */
        openColorPicker: openColorPicker,

        /**
         * Function openFontPicker
         * Opens the editor font picker panel
         * @memberof Wix.Styles
         * @private
         * @since 1.61.0
         */
        openFontPicker: openFontPicker,

        /**
         * Function setUILIBParamValue
         * Internal api for use only w/ the ui-lib to sync state between the editor and  both font and color pickers.
         * @memberof Wix.Styles
         * @private
         * @since 1.61.0
         */
        setUILIBParamValue: setUILIBParamValue,

        /**
         * Function getStyleId
         * Returns the styleId of the component
         * @function
         * @memberof Wix.Styles
         * @since 1.65.0
         * @param {Function} callback A callback function that receives the styleId
         * @example
         *
         * Wix.Styles.getStyleId(function(styleId){
         *      //do something with the styleId
         * });
         */
        getStyleId: getStyleId,

        /**
         * retrieves the style parameters of the given styleId from the hosting Wix Platform.
         * The style parameters includes colors numbers, booleans.
         *
         * @function
         * @memberof Wix.Styles
         * @since 1.65.0
         * @param {String} styleId The styleId
         * @param {Function} onSuccess Callback function to retrieve the style values.
         * @param {Function} onFailure Callback function to handle the case that the styleId wasn't found.
         * @example
         * Wix.Styles.getStyleParamsByStyleId('djk32', function(styleParams) {
         *       //do something with the styleParams
         *     }, function(){
         *       //throw error
         * });
         *
         */
        getStyleParamsByStyleId: getStyleParamsByStyleId
    };
});
