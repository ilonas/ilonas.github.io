/**
 * Functions to measure success rate and load time.
 * @memberof Wix
 * @namespace Wix.Performance
 */
define(['privates/performance'], function (performance) {

    var namespace = 'Performance';

    var applicationLoaded = function() {
        performance.applicationLoaded(namespace);
    };

    var applicationLoadingStep = function (stageNumber, stageDescription) {
        performance.applicationLoadingStep(namespace, stageNumber, stageDescription);
    };

    return {

        /**
         * Allows a component app to report that it has been loaded.
         *
         * @function
         * @memberof Wix.Performance
         * @since 1.70.0
         *
         * @example
         * Wix.Performance.applicationLoaded()
         *
         */
        applicationLoaded: applicationLoaded,

        /**
         * Allows a component app to report on a loading step
         *
         * @function
         * @memberof Wix.Performance
         * @since 1.70.0
         * @param {Number} stageNumber Stage number
         * @param {String} [stageDescription] Stage Description
         *
         * @example
         * Wix.Performance.applicationLoadingStep(2, 'loading images')
         *
         */
        applicationLoadingStep: applicationLoadingStep
    };
});
