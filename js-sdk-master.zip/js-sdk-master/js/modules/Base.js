/**
 * This is the description for the Wix namespace.
* @namespace Wix
*/
define(['privates/utils', 'Theme', 'WindowOrigin', 'WindowPlacement', 'privates/reporter', 'privates/postMessage', 'privates/sharedAPI', 'privates/viewMode'],
    function (utils, Theme, WindowOrigin, WindowPlacement, reporter, postMessage, sharedAPI, viewMode) {

    var namespace = 'Wix';

    var openModal = function (url, width, height, onClose, theme) {
        if (viewMode.getViewMode() === "editor") {
            reporter.reportSdkError('Invalid view mode. This function cannot be called in editor mode. Supported view modes are: [preview, site]');
            return;
        }

        var args = {
            url   : url,
            width : width,
            height: height,
            theme: theme || Theme.DEFAULT
        };

        postMessage.sendMessage(postMessage.MessageTypes.OPEN_MODAL, namespace, args, onClose);
    };

    var setHeight = function (height, options) {
        if (!utils.isNumber(height)) {
            reporter.reportSdkError('Mandatory argument - height - should be of type Number');
            return;
        } else if (height < 0) {
            reporter.reportSdkError('height should be a positive integer');
            return;
        }

        var overflow;

        if (options) {
            if(utils.isObject(options) && utils.isBoolean(options.overflow)) {
                overflow = options.overflow;
            } else {
                reporter.reportSdkError('Invalid argument - options should be of type object, containing boolean indicating if to resize this component over other components on the page');
                return;
            }
        }

        postMessage.sendMessage(postMessage.MessageTypes.HEIGHT_CHANGED, namespace, {
            height: height,
            overflow: overflow
        });
    };

    var closeWindow = function (message) {
        var args = {
            message : message
        };
        postMessage.sendMessage(postMessage.MessageTypes.CLOSE_WINDOW, namespace, args);
    };

    var scrollTo = function (x, y) {
        if (viewMode.getViewMode() === 'editor') {
            reporter.reportSdkError('Invalid view mode. This function cannot be called in editor mode. Supported view modes are: [preview, site]');
            return;
        }
        var args = {
            x : x,
            y: y
        };

        postMessage.sendMessage(postMessage.MessageTypes.SCROLL_TO, namespace, args);
    };

    var navigateToComponent = function(compId, options, onFailure) {
        if (viewMode.getViewMode() === 'editor') {
            reporter.reportSdkError('Invalid view mode. This function cannot be called in editor mode. Supported view modes are: [preview, site]');
            return;
        }
        if (!utils.isString(compId)) {
            reporter.reportSdkError('Missing mandatory argument - compId - should be of type String');
            return;
        }

        var args = {
            compId: compId
        };

        if(utils.isFunction(options)) {
            onFailure = options;
        } else if (options) {
            if(utils.isObject(options) && options.pageId) {
                if (options.pageId && utils.isString(options.pageId)) {
                    args.pageId = options.pageId;
                } else {
                    reporter.reportSdkError('Invalid argument - options must contain pageId of type string');
                    return;
                }

                if (options.noPageTransition) {
                    if (utils.isBoolean(options.noPageTransition)) {
                        args.noPageTransition = options.noPageTransition;
                    } else {
                        reporter.reportSdkError('Invalid argument - noPageTransition should be of type boolean');
                        return;
                    }
                }
            } else {
                reporter.reportSdkError('Invalid argument - options should be of type object, containing string representing page id and optionally noPageTransition');
                return;
            }
        }

        postMessage.sendMessage(postMessage.MessageTypes.NAVIGATE_TO_COMPONENT, namespace, args, onFailure);
    };

    var getSiteInfo = function (onSuccess) {
        sharedAPI.getSiteInfo(namespace, onSuccess);
    };

    var getSitePages = function (options, callback) {
        sharedAPI.getSitePages(namespace, options, callback);
    };

    var getSiteMap = function (callback) {
        sharedAPI.getSiteMap(namespace, callback);
    };

    var setPageMetadata = function (options) {
        if (viewMode.getViewMode() !== 'site') {
            reporter.reportSdkError('Invalid view mode. This function cannot be called in editor/preview mode. Supported view mode is: [site]');
            return;
        }
        if (!utils.isObject(options)) {
            reporter.reportSdkError('Missing mandatory argument - options - should be of type Object');
            return;
        }
        if (!options.title && !options.description) {
            reporter.reportSdkError('Invalid argument - options must contain title and/or description of type string');
            return;
        }
        if (options.title && !utils.isString(options.title)) {
            reporter.reportSdkError('Invalid argument - title must be of type string');
            return;
        }
        if (options.description && !utils.isString(options.description)) {
            reporter.reportSdkError('Invalid argument - description must be of type string');
            return;
        }
        if (options.overrideTitle && !utils.isBoolean(options.overrideTitle)) {
            reporter.reportSdkError('Invalid argument - overrideTitle must be of type boolean');
            return;
        }

        var args = {};
        if (options.title) {
            args.title = options.title;
        }
        if (options.description) {
            args.description = options.description;
        }
        if (options.overrideTitle) {
            args.overrideTitle = options.overrideTitle;
        }
        postMessage.sendMessage(postMessage.MessageTypes.SET_PAGE_METADATA, namespace, args);
    };

    var getStyleParams = function (callback) {
        reporter.reportSdkMsg('Wix.getStyleParams is DEPRECATED use Wix.Styles.getStyleParams');
        postMessage.sendMessage(postMessage.MessageTypes.GET_STYLE_PARAMS, namespace);
        return sharedAPI.getStyleParams(callback);
    };

    var reportHeightChange = function () {
        reporter.reportSdkError('Deprecated, use Wix.setHeight instead');
    };

    var pushState = function (state) {
        if (!utils.isString(state)) {
            reporter.reportSdkError('Missing mandatory argument - state - should be of type String');
            return;
        }
        postMessage.sendMessage(postMessage.MessageTypes.APP_STATE_CHANGED, namespace, {
            state: state
        });
    };

    var replaceSectionState = function (state) {
        if (viewMode.getViewMode() === "editor") {
            reporter.reportSdkError('Invalid view mode. This function cannot be called in editor mode. Supported view modes are: [preview, site]');
            return;
        }
        if (!state) {
            reporter.reportSdkError('Missing mandatory argument - state');
            return;
        }
        if (!utils.isString(state)) {
            reporter.reportSdkError('Invalid argument - state should be of type String');
            return;
        }
        postMessage.sendMessage(postMessage.MessageTypes.REPLACE_SECTION_STATE, namespace, {
            state: state
        });
    };

    var getCurrentPageId = function (callback) {
        postMessage.sendMessage(postMessage.MessageTypes.GET_CURRENT_PAGE_ID, namespace, null, callback);
    };

    var getComponentInfo = function(callback) {
        if (!callback || !utils.isFunction(callback)) {
            reporter.reportSdkError('Missing mandatory argument - callback - should be of type Function');
            return;
        }
        postMessage.sendMessage(postMessage.MessageTypes.GET_COMPONENT_INFO, namespace, null, callback);
    };

    var navigateTo = function(linkData, onFailure) {
        if (viewMode.getViewMode() === 'editor') {
            reporter.reportSdkError('Invalid view mode. This function cannot be called in editor mode. Supported view modes are: [preview, site]');
            return;
        }
        if (!utils.isObject(linkData)) {
            reporter.reportSdkError('Missing mandatory argument - linkData of type Object');
            return;
        }
        if (onFailure && !utils.isFunction(onFailure)) {
            reporter.reportSdkError('Invalid argument - onFailure must be of type Function');
            return;
        }

        if (linkData.type === 'ExternalLink') {
            window.open(linkData.url, '_blank'); //done in sdk due to popup blockers
        }
        var args = {link: linkData};
        postMessage.sendMessage(postMessage.MessageTypes.NAVIGATE_TO, namespace, args, onFailure);
    };

    var navigateToPage = function(pageId, options, onFailure) {
        if (!pageId) {
            reporter.reportSdkError('Missing mandatory argument - pageId of type string');
            return;
        }
        if (options && !utils.isObject(options)) {
            reporter.reportSdkError('Invalid argument - options must be of type Object');
            return;
        }
        if (onFailure && !utils.isFunction(onFailure)) {
            reporter.reportSdkError('Invalid argument - onFailure must be of type Function');
            return;
        }

        var args = {pageId: pageId};

        if (options) {
            if (options.anchorId) {
                if (viewMode.getViewMode() === 'editor') {
                    reporter.reportSdkError('Invalid view mode. This function cannot be called with anchorId in editor mode. Supported view modes are: [preview, site]');
                    return;
                }
                args.anchorId = options.anchorId;
            }

            if (options.noTransition) {
                if (!utils.isBoolean(options.noTransition)) {
                    reporter.reportSdkError('Invalid argument - noTransition should be of type boolean');
                    return;
                }
                args.noTransition = options.noTransition;
            }
        }
        postMessage.sendMessage(postMessage.MessageTypes.NAVIGATE_TO_PAGE, namespace, args, onFailure);
    };

    var currentMember = function (onSuccess) {
        sharedAPI.currentMember(namespace, onSuccess);
    };

    var requestLogin = function (options, onSuccess, onCancel) {

		if (viewMode.getViewMode() !== 'site') {
            reporter.reportSdkError('Invalid view mode. This function cannot be called in editor/preview mode. Supported view mode is: [site]');
            return;
        }

        var args = {}, callback = function(){};
        var isCallOnSuccess = false;

        //backwards - support when onSuccess was the first argument
        if (utils.isFunction(options)) {
            if (utils.isFunction(onSuccess)) {
                onCancel = onSuccess;
            } else if (onSuccess) {
                reporter.reportSdkError("Invalid argument - onSuccess must be of type Function");
                return;
            }
            onSuccess = options;
            isCallOnSuccess = true;

        } else if (utils.isObject(options)){
            if (options.mode === 'login'|| options.mode === 'signup') {
                args.mode = options.mode;
            } else if (options.mode) {
                reporter.reportSdkError("Invalid argument - mode can only be 'login' or 'signup'");
                return;
            }

            if (options.language) {
                args.language = options.language;
            }
            if (utils.isFunction(onSuccess)) {
                isCallOnSuccess = true;
            } else if (onSuccess) {
                reporter.reportSdkError("Invalid argument - onSuccess must be of type Function");
                return;
            }
        }

        if (isCallOnSuccess){
            var callOnCancel = utils.isFunction(onCancel);
            args.callOnCancel = callOnCancel;

            callback = function (data) {
                if (data.wasCancelled) {
                    if (callOnCancel) {
                        onCancel(data);
                    }
                } else {
                    onSuccess(data);
                }
            };
        }

        postMessage.sendMessage(postMessage.MessageTypes.SM_REQUEST_LOGIN, namespace, args, callback);
    };

    var logOutCurrentMember = function(options, onError){
        if (viewMode.getViewMode() !== 'site') {
            reporter.reportSdkError('Invalid view mode. This function cannot be called in editor/preview mode. Supported view mode is: [site]');
            return;
        }

        var args = {};
        if (utils.isObject(options)) {
            if (options.language) {
                args.language = options.language;
            }
            if (onError && !utils.isFunction(onError)) {
                reporter.reportSdkError('Invalid argument - onError, must be a function');
                return;
            }
            postMessage.sendMessage(postMessage.MessageTypes.LOG_OUT_CURRENT_MEMBER, namespace, args, onError);
        } else if (utils.isFunction(options)) {
            postMessage.sendMessage(postMessage.MessageTypes.LOG_OUT_CURRENT_MEMBER, namespace, args, options);
        } else if (options) {
            reporter.reportSdkError('Invalid argument - options, must be an object');
        } else {
            postMessage.sendMessage(postMessage.MessageTypes.LOG_OUT_CURRENT_MEMBER, namespace, args);
        }
    };

    var openPopup = function (url, width, height, position, onClose, theme) {
        if (viewMode.getViewMode() === 'editor') {
            reporter.reportSdkError('Invalid view mode. This function cannot be called in editor mode. Supported view modes are: [preview, site]');
            return;
        }

        // in case position was omitted and the last argument is the onClose callback
        if (arguments.length === 4 && utils.isFunction(arguments[3])) {
            position = {};
        }

        position = position || {};
        position.origin = position.origin || WindowOrigin.DEFAULT;
        position.placement = position.placement || WindowPlacement.CENTER;

        var args = {
            url   : url,
            width : width,
            height: height,
            position: position,
            theme: theme || Theme.DEFAULT
        };
        postMessage.sendMessage(postMessage.MessageTypes.OPEN_POPUP, namespace, args, onClose);
    };

    var resizeWindow = function (width, height, onComplete) {
        var args = {
            width : width,
            height: height
        };
        postMessage.sendMessage(postMessage.MessageTypes.RESIZE_WINDOW, namespace, args, onComplete);
    };

    var addEventListener = function (eventName, callBack) {
        return postMessage.addEventListenerInternal(eventName, namespace, callBack, false);
    };

    var removeEventListener = function (eventName, callBackOrId) {
        postMessage.removeEventListenerInternal(eventName, namespace, callBackOrId, false);
    };

    var scrollBy = function (x, y) {
        if (viewMode.getViewMode() === 'editor') {
            reporter.reportSdkError('Invalid view mode. This function cannot be called in editor mode. Supported view modes are: [preview, site]');
            return;
        }
        var args = {
            x : x,
            y: y
        };
        postMessage.sendMessage(postMessage.MessageTypes.SCROLL_BY, namespace, args);
    };

    var getBoundingRectAndOffsets =  function (callback) {
        postMessage.sendMessage(postMessage.MessageTypes.BOUNDING_RECT_AND_OFFSETS, namespace, null, callback);
    };

    var getExternalId = function (onSuccess, onError) {
        if (!onSuccess) {
            reporter.reportSdkError('Mandatory arguments - an onSuccess callback must be specified');
        }

        var callback = function (data) {
            if (data && data.onError) {
                if (onError) {
                    onError.apply(this, arguments);
                }
            } else {
                onSuccess.apply(this, arguments);
            }
        };

        postMessage.sendMessage(postMessage.MessageTypes.GET_EXTERNAL_ID, namespace, undefined, callback);
    };

    var resizeComponent = function(options, onSuccess, onFailure){
        var currentViewMode = viewMode.getViewMode();
        if (currentViewMode !== 'editor') {
            reporter.reportSdkError(currentViewMode + ' is an invalid view mode. This function can only be called in editor mode.');
        } else {
            sharedAPI.resizeComponent(options, namespace, onSuccess, onFailure);
        }
    };

    var revalidateSession = function(onSuccess, onError) {
        sharedAPI.revalidateSession(namespace, onSuccess, onError);
    };

    var navigateToAnchor = function(anchorId, onFailure){
        if (viewMode.getViewMode() === 'editor') {
            reporter.reportSdkError('Invalid view mode. This function cannot be called in editor mode. Supported view modes are: [preview, site]');
            return;
        }
        if (!utils.isString(anchorId)) {
            reporter.reportSdkError('Missing mandatory argument - anchorId - should be of type String');
            return;
        }

        if(onFailure && !utils.isFunction(onFailure)) {
            reporter.reportSdkError('Invalid argument - onFailure, must be a function');
            return;
        }

        var args = {
            anchorId: anchorId
        };

        postMessage.sendMessage(postMessage.MessageTypes.NAVIGATE_TO_ANCHOR, namespace, args, onFailure);
    };

    var getCurrentPageAnchors = function(callback) {
        sharedAPI.getCurrentPageAnchors(namespace, callback);
    };

    var getStateUrl = function(sectionId, state, callback) {
        sharedAPI.getStateUrl(namespace, sectionId, state, callback);
    };

    var getAdsOnPage = function (onSuccess) {
        if (!utils.isFunction(onSuccess)) {
            reporter.reportSdkError('Mandatory argument - onSuccess function must be specified');
            return;
        }
        postMessage.sendMessage(postMessage.MessageTypes.GET_ADS_ON_PAGE, namespace, undefined, onSuccess);
    };

    return {
        /**
         * The openModal method allows an app to open a modal window within the site or preview.
         *
         * A modal is a runtime Widget that is not part of the site structure.
         *
         * The modal window is a singleton (every new modal closes the previous one) and contains a lightbox.
         *
         * A modal can be dismissed by the user if it touches the lightbox, presses the closing button or by the app itself
         * if it calls the Wix.closeWindow from within the modal iframe.
         *
         * The onClose argument can be used to detect modal close.
         * @function
         * @memberof Wix
         * @since 1.16.0
         * @param {String} url Model iframe url.
         * @param {Number} width The modal window width.
         * @param {Number} height The modal window height.
         * @param {Function} [onClose] Onclose callback function.
         * @param {Wix.Theme} [theme] The modal window theme, one of Wix.Theme values. Wix.Theme.DEFAULT is used for regular modal look & feel - border, shadow, close button. Wix.Theme.BARE is used for no decorations at all.
         * @example
         *
         * var onClose = function(message) { console.log("modal closed", message); }
         * Wix.openModal("http://sslstatic.wix.com/services/js-sdk/1.16.0/html/modal.html", 400, 400, onClose);
         *
         */
        openModal: openModal,

        /**
         *
         * @function
         * @memberof Wix
         *
         * @description
         *
         * The openPopup method allows an app to open a popup window within the site or preview.
         *
         * A popup is a runtime Widget that is not part of the site structure.
         *
         * Unlike the modal, a popup is not a singleton and doesn't present a lightbox.
         *
         * A popup can also be positioned by the caller. We currently support a predefined set of
         * positions that can be used when opening a popup.
         *
         * A popup is dismissed by the user if he presses the close button or by the app itself if it calls the Wix.closeWindow from within
         * the popup iframe.
         *
         * The onClose argument can be used to detect modal close.
         *
         * Popup positioning
         * A popup position is determined by two properties, it's position origin and it's position placement.
         * A position origin determines the origin point (x,y) which will be used to apply the position placement.
         * The position origin is defined under [Wix.WindowOrigin](Wix.WindowOrigin) and can have the following values:
         *
         * [Wix.WindowOrigin.DEFAULT](Wix.WindowOrigin.html#DEFAULT)
         *
         * [Wix.WindowOrigin.FIXED](Wix.WindowOrigin.html#FIXED)
         *
         * [Wix.WindowOrigin.RELATIVE]((Wix.WindowOrigin.html#RELATIVE)
         *
         * [Wix.WindowOrigin.ABSOLUTE]((Wix.WindowOrigin.html#ABSOLUTE)
         *
         * A position placement is a predefined set of locations when a popup will be placed.
         * The placement values are valid for Wix.WindowOrigin.FIXED, Wix.WindowOrigin.ABSOLUTE and Wix.WindowOrigin.RELATIVE origins but mapped to a different positions on the screen.
         * The position placement is defined under Wix.WindowPlacement and can have the following values:
         *
         * [Wix.WindowPlacement.TOP_LEFT](Wix.WindowPlacement.html#TOP_LEFT)
         *
         * [Wix.WindowPlacement.TOP_CENTER](Wix.WindowPlacement.html#TOP_CENTER)
         *
         * [Wix.WindowPlacement.TOP_RIGHT](Wix.WindowPlacement.html#TOP_RIGHT)
         *
         * [Wix.WindowPlacement.CENTER_LEFT](Wix.WindowPlacement.html#CENTER_LEFT)
         *
         * [Wix.WindowPlacement.CENTER](Wix.WindowPlacement.html#CENTER)
         *
         * [Wix.WindowPlacement.CENTER_RIGHT](Wix.WindowPlacement.html#CENTER_RIGHT)
         *
         * [Wix.WindowPlacement.BOTTOM_LEFT](Wix.WindowPlacement.html#BOTTOM_LEFT)
         *
         * [Wix.WindowPlacement.BOTTOM_CENTER](Wix.WindowPlacement.html#BOTTOM_CENTER)
         *
         * [Wix.WindowPlacement.BOTTOM_RIGHT](Wix.WindowPlacement.html#BOTTOM_RIGHT)
         *
         * @since 1.17.0
         * @param {String} url Popup iframe's url.
         * @param {Number} width Popup width in pixels.
         * @param {Number} height Popup height in pixels.
         * @param {Object} position
         * @param {Function} [onClose] Callback function.
         * @param {Wix.Theme} [theme] The popup window theme, one of Wix.Theme values. Wix.Theme.DEFAULT is used for regular popup look & feel - border, shadow, close button. Wix.Theme.BARE is used for no decorations at all.
         *
         * Note:
         * In a RELATIVE or ABSOLUTE origin, there is a chance that the requested popup can not fit in the
         * desired position since it's size exceeds the margin between the opening Widget and the screen size.
         * A Widget position is determined by site owners when they build their sites while the Widget
         * is not aware to it's position in the site. When the Wix Platform render popups,
         * it calculates if a popup in the requested size can fit the requested position.
         * If not, the Wix Platform will default the position to {origin: Wix.WindowOrigin.FIXED, placement: Wix.WindowPlacement.CENTER},
         * i.e., the center of the screen.
         *
         *
         * @example
         * // The following call will open a popup window positioned in the center of the screen
         * var position =  {origin: Wix.WindowOrigin.FIXED, placement: Wix.WindowPlacement.CENTER};
         * var onClose = function(message) { console.log("popup closed", message) };
         * Wix.openPopup("http://sslstatic.wix.com/services/js-sdk/1.16.0/html/modal.html", 400, 400, position, onClose);
         * @example
         * // The following call will open a popup window positioned bottom-right to the point (x, y), originated in the top-left corner of the widget
         * var position =  {origin: Wix.WindowOrigin.ABSOLUTE, placement: Wix.WindowPlacement.BOTTOM_RIGHT, x: 20, y: 100};
         * var onClose = function(message) { console.log("popup closed", message) };
         * Wix.openPopup("http://sslstatic.wix.com/services/js-sdk/1.16.0/html/modal.html", 400, 400, position, onClose);
         *
         */
        openPopup: openPopup,

        /**
         * This method requests the hosting Wix platform to change the iframe height inside the site/editor.
         * @function
         * @memberof Wix
         * @since 1.50.0
         * @param {Number} height An integer that represents the desired height in pixels.
         * @param {Object} [Options] options may contain boolean value telling the platform to display and resize this component over other components on the page. By default, other components will be relocated (pushed down) as a result of this operation.
         e.
         * @example
         *
         * Wix.setHeight(height);
         *
         */
        setHeight: setHeight,

        /**
         * The closeWindow method is available only under a modal endpoint (will not have any effect for other endpoints). It allows the modal to close itself programmatically.
         * @function
         * @memberof Wix
         * @since 1.16.0
         * @param {Object} [message] A custom message object to pass to the opener's onClose callback function.
         * @example
         *
         * // The following call will close the modal/popup window and send a the object message to the opener onClose callback
         * var message = {"reason": "button-clicked"};
         * Wix.closeWindow(message);
         *
         */
        closeWindow: closeWindow,

        /**
         * The scrollTo method will perform a scroll to a fixed position in the app's hosting site window exactly as the standard method do.
         * Available in preview and site view modes only.
         * @function
         * @memberof Wix
         * @since 1.19.0
         * @param {Number} x The coordinate to scroll to, along the x-axis.
         * @param {Number} y The coordinate to scroll to, along the y-axis.
         * @example
         *
         * Wix.scrollTo(0, 0);
         *
         */
        scrollTo: scrollTo,

        /**
         * The navigateToComponent method will navigate to a component on the current page, or to a component on a page with the pageId provided.
         * Available in preview and site view modes only.
         * @function
         * @memberof Wix
         * @since 1.65.0
         * @param {String} compId of the component to navigate to
         * @param {Object} [Options] options may contain pageId to navigate to. When pageId is not provided, the method will navigate to a component with the given id on the current page.
         *                           if pageId is provided, options may contain noPageTransition for removing the transition to the page
         * @param {Function} [onFailure] the function will return an object that specifies the error which occurred, it will be invoked in the following scenarios:
         *        1. Current page does not contain the given component (and pageId was not provided).
         *        2. Provided pageId is not valid.
         *        3. PageId is given but the page does not contain a component with the provided component id. Note: The method will first navigate to a page with the provided pageId as an effect of this API call.
         * @example
         *
         * // The following call will scroll to a component with id = comp1, on a page with id = page1
         * Wix.navigateToComponent('comp1', {pageId: 'page1', noPageTransition: true}, function(error) { console.log(error.error)} );
         *
         */
        navigateToComponent: navigateToComponent,

        /**
         * The scrollBy method will perform a scroll by the specified number of pixels in the app's hosting site window exactly as the standard method - http://www.w3schools.com/jsref/met_win_scrollto.asp do.
         * Available in preview and site view modes only.
         * @function
         * @memberof Wix
         * @since 1.19.0
         * @param {Number} x How many pixels to scroll by, along the x-axis (horizontal)
         * @param {Number} y How many pixels to scroll by, along the y-axis (vertical)
         * @example
         *
         * // The following call will scroll to the top of the page
         * Wix.scrollBy(0, 0);
         *
         */
        scrollBy: scrollBy,

        /**
         * The getsiteInfo method is used to retrieve information about the host site in which the app is shown.
         * @function
         * @memberof Wix
         * @since 1.3.0
         * @param callback (Function) a callback function to receive the site pages.
         * @return {Object} data JSON containing the site info. It's properties are:
         *
         *  Name           | Type      | Description
         * ----------------|-----------|------------
         * siteTitle       | `String`  | The title of the site that is used for SEO.
         * pageTitle       | `String`  | The site current page title that is used for SEO.
         * siteDescription | `String`  | The description of the site that is used for SEO
         * siteKeywords    | `String`  | The keywords which were related to the site and are used for SEO.
         * referrer        | `String`  | The referrer header of the http request.
         * url             | `String`  | The full url taken from the location.href, includes internal site state, For example: http://user.wix.com/site-name#!pageTitle/pageId, http://www.domain.com#!pageTitle/pageId. This field is omitted when running in Editor view mode.
         * baseUrl         | `String`  | Base url of the current site, for example: http://user.wix.com/site-name, http://www.domain.com
         *
         * @example
         * Wix.getSiteInfo( function(siteInfo) {
         *      // do something with the siteInfo
         * });
         */
        getSiteInfo: getSiteInfo,

        /**
         * The getSitePages method is used to retrieve the site structure from the hosting Wix Platform. The site structure includes visible and hidden pages as well as sub pages.
         * @function
         * @memberof Wix
         * @since 1.68.0
         * @param  [options] may contain a 'includePagesUrl' property that indicates if to add to the single page description object the property url
         * @param {Function} callback A callback function to receive the site pages.
         * @return {Array} Array containing an ordered set of the site pages. A single page description contains the following properties:
         *
         *  Name             | Type      | Description
         * ------------------|-----------|------------
         * id                | `String`  | The page id.
         * title             | `String`  | The page title.
         * hide              | `Boolean` | A flag indicating if the page is hidden.
         * subPages(optional)| `Array`   | An ordered set of sub pages.
         * url               | `String`  | Url of the page (will be added only if includePagesUrl is given and it's true)
         * @example
         *
         * Wix.getSitePages(function(sitePages) {
         *    // do something with the site pages
         * });
         *
         * Wix.getSitePages({ includePagesUrl: true }, function(sitePages) {
         *    // do something with the site pages
         * });
         */
        getSitePages: getSitePages,

        /**
         * The getSiteMap method is used to retrieve the site structure from the hosting Wix Platform. The site structure includes visible and hidden pages, sub pages, links and menu headers.
         * This method will eventually replace the getSitepages.
         * @function
         * @memberof Wix
         * @since 1.81.0
         * @param {Function} callback A callback function to receive the site pages.
         * @return {Array} Array containing an ordered set of the site pages.
         *
         * @example
         * Wix.getSiteMap(function(siteMap) {
         *    // do something with the site pages
         * });
         *
         */
        getSiteMap: getSiteMap,

        /**
         * Sets metadata for the page component’s internal pages. Search engines display this metadata – the page’s title and/or description – in search results.
         * @function
         * @memberof Wix
         * @since 1.74.0
         * @param {Object} options object which contains the title and/or description properties to be set,
         * options can also contain overrideTitle which indicates to set the full title
         *
         * @example
         * Wix.setPageMetadata({
         *      title: 'new title',
         *      description: 'new description',
         *      overrideTitle: true
         * });
         */
        setPageMetadata: setPageMetadata,

        /**
         * The getBoundingRectAndOffsets method returns the app's component bounding rect and site's offset.
         * @function
         * @memberof Wix
         * @since 1.26.0
         * @param {Function} callback A callback function which passes back the bounding rect and offsets.
         *
         * @example
         * Wix.getBoundingRectAndOffsets(function(data){
         *    // use the offsets and rect details
         * });
         */
        getBoundingRectAndOffsets: getBoundingRectAndOffsets,


        /**
         * The removeEventListener method allows to remove previously assigned event listeners that were specified using Wix.addEventListener.
         * @function
         * @memberof Wix
         * @since 1.25.0
         * @param {Wix.Events} eventName Unique event identifier.
         * @param {Function} callBackOrId A callback function that was used with addEventListener or an id returned by addEventListener.
         *
         * @example
         * var callback = function(){};
         * var id = Wix.addEventListener(Wix.Events.EDIT_MODE_CHANGE, function(data) {
         *     //do something
         * });
         * Wix.addEventListener(Wix.Events.PAGE_NAVIGATION, callback);
         * // remove listener as a callback function
         * Wix.removeEventListener(Wix.Events.PAGE_NAVIGATION, callback);
         * // remove listener as an id
         * Wix.removeEventListener(Wix.Events.EDIT_MODE_CHANGE, id);
         */
        removeEventListener: removeEventListener,


        /**
         * The addEventListener method lets the App listen to events that happens inside the editor/site.
         * @function
         * @memberof Wix
         * @since 1.11.0
         * @param {Wix.Events} eventName Unique event identifier.
         * @param {Function} handler A callback function that will get called by the SDK once an event occur.
         * The events that you can currently listen to are:
         * @see Wix.Events.EDIT_MODE_CHANGE
         * @see Wix.Events.PAGE_NAVIGATION_CHANGE
         * @see Wix.Events.PAGE_NAVIGATION
         * @see Wix.Events.PAGE_NAVIGATION_IN
         * @see Wix.Events.PAGE_NAVIGATION_OUT
         * @see Wix.Events.SCROLL
         * @see Wix.Events.COMPONENT_DELETED
         * @see Wix.Events.SITE_PUBLISHED
         * @see Wix.Events.SETTINGS_UPDATED
         * @see Wix.Events.STATE_CHANGED
         * @see Wix.Events.THEME_CHANGE
         *
         */
        addEventListener: addEventListener,

        /**
         * The resizeWindow method is valid only for fixed position widgets. It re-sizes the widget window.
         * @function
         * @memberof Wix
         * @since 1.19.0
         * @param {Number} width Window width in pixels.
         * @param {Number} height Window height in pixels.
         * @param {Function} onComplete On resize complete callback function.
         * @example
         *
         * // The following call will resize the widget window
         * Wix.resizeWindow(300,300);
         *
         */
        resizeWindow: resizeWindow,

        /**
         *
         * <div style="margin:20px 0;background-color:blue;border-radius: 5px;border-style: solid;border-width: 1px;padding:10px;background-color: #E0EFFF;border-color: #9EB6D4;">
         * This method is part of Wix Site Members feature. To use it a manual provisioning is required by the Wix team, contact apps@wix.com to enable it for your app.
         * </div>
         *
         * This method is relevant for live sites and not from the App Settings. The method requests the current site visitor of the Wix site to log-in or register.
         *
         * After a successful log-in, the Wix site will reload including the app iframe and the new signed-instance parameter will contain the details of the logged in user.
         *
         *
         * The method has an affect only for a published site. If called in the Wix editor, the method has no affect.          *
         *
         * @function
         * @memberof Wix
         * @since 1.69.0
         * @param {Object} [options] may contain:
         *                           a 'mode' property with possible values: 'login' or 'signup'
         *                           language property that define in which language the panel will be displayed in
         * @param {Function} [callback] A callback function to receive the current member details.
         * @param {Function} [onCancel] that will be called if the form was closed without login.
         * @example
         *
         * Wix.requestLogin({mode: 'login', language: 'es'}, function (data) {
         *    //do something with data
         * }, function () {
         *    //do something
         * })
         */
        requestLogin: requestLogin,

        /**
        * This method is part of Wix Site Members feature. It allows the current site visitor to log out in case he was logged in.
        * After a successful log out, iframe will refresh.
        *
        * @function
        * @memberof Wix
        * @since 1.67.0
        * @param {Object} [options] may contain a 'language' property
        * @param {Function} [onError] A callback function to with error details.
        * @example
        *
        * Wix.logOutCurrentMember({}, function (error) {
        *    //do something with error
        * }
        */
        logOutCurrentMember: logOutCurrentMember,

        /**
         *
         * <div style="margin:20px 0;background-color:blue;border-radius: 5px;border-style: solid;border-width: 1px;padding:10px;background-color: #E0EFFF;border-color: #9EB6D4;">
         * This method is part of Wix Site Members feature. To use it a manual provisioning is required by the Wix team, contact apps@wix.com to enable it for your app.
         * </div>
         *
         * This method is relevant for live sites and not from the App Settings.
         *
         * @function
         * @memberof Wix
         * @since 1.6.0
         * @param {Function} callback A callback function to receive the current member details.
         * @returns {Object} JSON Containing the user's details.
         *
         * This method returns the details of the current site visitor that is logged into the Wix site, using the Wix site member options.
         *
         * Name              | Type       | Value
         * ------------------|-----------|------------
         * name  | 'String'  | The current member's name
         * email | 'String'  | The current member's email
         * id    | 'String'  | The current member's id
         * owner | 'Boolean' | Indicates if the user is the owner of the site
         *
         * @example
         *
         * Wix.currentMember(function(memberDetails) {
         *   // save memberDetails
         * }
         *
         *
         */
        currentMember: currentMember,

        /**
         * Navigate to link objects returned from Setting.openLinkPanel or Wix.getSiteMap sdk functions.
         *
         * @function
         * @memberof Wix
         * @since 1.81.0
         * @param {object} linkData An object returned from 'openLinkPanel' containing link data relevant for navigating.
         * @param {function} [onFailure] - onFailure message when an error in navigation occurs
         *
         * @example
         *
         * Wix.navigateTo({
         *  "type": "PageLink",
            "pageId": "#c1dmp"
            }, function() {...});
         */
        navigateTo: navigateTo,

        /**
         * Navigate to a specific page inside the editor/preview/site.
         * The function accepts a single argument, page id, which is retrieved by using the method Wix.getSitePages().
         *
         * @function
         * @memberof Wix
         * @since 1.68.0
         * @param {String} pageId A string representing the page id target.
         * @param {Object} [Options] options may contain:
         *                           noTransition for removing the transition when navigate to the page
         *                           anchorId of the anchor to navigate to in the page
         * @param {function} [onFailure] - onFailure message when options is provided but the anchorId is not valid
         *
         *
         * @example
         *
         * Wix.navigateToPage(PAGE_ID, {noTransition: true});
         */
        navigateToPage: navigateToPage,

        /**
         * The getCurrentPageId method returns the page id of the app hosting page.
         *
         * @function
         * @memberof Wix
         * @since 1.31.0
         * @author lior.shefer@wix.com
         * @example
         *
         * // The following call will return the page id of the app hosting page.
         * Wix.getCurrentPageId(function(pageId) {
         *     //store the site pageId
         * }
         */
        getCurrentPageId: getCurrentPageId,

        /**
         * This method enable AJAX style Page apps to inform the Wix platform about a change in the app internal state. The new state will be reflected in the site/page URL.
         * Once you call the pushState method, the browser top window URL will change the 'app-state' path part to the new state you provide with the pushState
         * method (similar to the browser history API - https://developer.mozilla.org/en-US/docs/Web/Guide/API/DOM/Manipulating_the_browser_history).
         * For a full explanation of how deep-linking works with AJAX style apps, see Deep Linking for AJAX Style Apps - http://dev.wix.com/docs/display/DRAF/Developing+a+Page+App.
         * @function
         * @memberof Wix
         * @since 1.8.0
         * @param {String} state New app's state to push into the editor history stack.
         * @example
         *
         * Wix.pushState("app-state");
         *
         */
        pushState: pushState,

        /**
         * This method requests the hosting Wix platform to change the iframe height inside the site/editor.
         * @function
         * @memberof Wix
         * @since 1.8.0
         * @deprecated
         * @see Wix.setHeight
         * @param {Number} height An integer that represents the desired height in pixels.
         *
         * @example
         *
         * Wix.reportHeightChange(height);
         *
         */
        reportHeightChange: reportHeightChange,

        /**
         * The getStyleParams method is used to retrieve the style parameters from the hosting Wix Platform. The parameters includes colors numbers, booleans.
         * @function
         * @memberof Wix
         * @since 1.22.0
         * @deprecated
         * @see Wix.Styles.getStyleParams
         * @param {function} callback A callback function to receive the style parameters.
         *
         * @example
         *
         * Wix.getStyleParams( function(styleParams) {
         *  // do something with the style params
         * });
         *
         */
        getStyleParams: getStyleParams,

        /**
         * Call this method to get the GUID corresponding to the calling component, if one exists. If one does not exist, undefined will be returned.
         * @function
         * @author lior.shefer@wix.com
         * @param {function} onSuccess - the GUID value, if one exists. If one does not exist, undefined will be returned.
         * @param {function} [onFailure] - onError message
         * @memberof Wix
         * @since 1.45.0
         * @example
         *
         *
         * Wix.getExternalId(function (value) {
         *   // do something w/ the value
         * });
         */
        getExternalId: getExternalId,

        /**
         * Sets the width of the given component. Works for both pages and widgets.
         * Available in editor view mode only.
         * @function
         * @author lior.shefer@wix.com
         * @memberof Wix
         * @since 1.47.0
         * @param {Object} options - options object w/ width and/or height
         * @param {function} onSuccess - onSuccess message
         * @param {function} [onFailure] - onError message
         * @experimental
         * @example
         *
         *
         * Wix.resizeComponent({
         *    width: 400,
         *    height:600
         * });
         */
        resizeComponent: resizeComponent,

        /**
         * The getCurrentPageAnchors method is used to retrieve the anchors found on the current page in the editor/preview/site view modes.
         * By default the method will return the top page anchor on the current page.
         * @function
         * @memberof Wix
         * @since 1.62.0
         * @param {function} callback - a callback function which receives an array of anchors.
         * @example
         *
         * Wix.getCurrentPageAnchors(function(anchors) {
         *      // do something with anchors
         * });
         */
        getCurrentPageAnchors: getCurrentPageAnchors,

        /**
         * The navigateToAnchor method will navigate to an anchor on the current page.
         * Available in preview and site view modes only.
         * @function
         * @memberof Wix
         * @since 1.62.0
         * @param {String} anchorId of the anchor to navigate to
         * @param {Function} [onFailure] the function will return an object that specifies the error which occurred, it will be invoked when the current page does not contain the given anchor.
         * @example
         *
         * // The following call will navigate to anchor with id = anchor1
         * Wix.navigateToAnchor('anchor1', function(error) { console.log(error.error)} );
         *
         */
        navigateToAnchor: navigateToAnchor,

        /**
         *
         * Retrieves information about the current component. For example, you’ll be able to know if a widget is shown on all pages.
         *
         * Available from Editor, Preview and Viewer, only in components and settings (not is modal, popups and etc..)
         *
         * @function
         * @memberof Wix
         * @since 1.63.0
         * @param {Function} callback -  a callback function which returns an object w/ information about the component.
         * @return {Object} A JSON object containing the component info:
         *
         *  Name           | Type      | Description
         * ----------------|-----------|------------
         * compId          | `String`  | The unique ID of this component in the Wix site
         * pageId          | `String`  | ID of the page that contains the component.
         *                 |           | Returns null if the component is a widget that’s set to show on all pages.
         * showOnAllPages  | `Boolean` | True if the user set the widget to show on all pages.
         *                 |           | False if the component is a page, or if the widget is not set to show on all pages.
         * tpaWidgetId     | `String`  | ID of the widget component, as specified in the Dev Center.
         *                 |           | Returns null if the component is a page, or if you’re using this method in the live site.
         * appPageId       | `String`  | ID of the page component, as specified in the Dev Center.
         *                 |           | Returns null if the component is a widget, or if you’re using this method in the live site.
         *
         * @example
         * Wix.getComponentInfo(function(componentInfo) {
         *      // do something with the componentInfo
         * });
         */
        getComponentInfo: getComponentInfo,

        /**
         * This method is like pushState method except that this method will not push the new url to the browser's history, but replace it instead.
         * @function
         * @memberof Wix
         * @since 1.65.0
         * @param {String} state New app's state to push url.
         * @example
         *
         * Wix.replaceSectionState("app-state");
         */
        replaceSectionState: replaceSectionState,

        /**
         * Gets a URL for a given deep-linked state in a given sectionIdentifier. In the editor, gets the public URL for the address.
         *
         * Available from Editor, Preview and Viewer
         *
         * @function
         * @memberOf Wix
         * @since 1.69.0
         * @param {String} sectionId - the sectionId of the page to deep-link
         * @param {String} state - the deep-linked state
         * @returns {Object} The section url for the given sectionId
         * @example
         *
         * Wix.getStateUrl("cd1mp", "internal/app/state", function (url) {
         *      // do something with the URL for the state
         * });
         */
        getStateUrl,

        /**
         * The getAdsOnPage method will call the onSuccess callback with the width & height of the visible ads on the page.
         *
         * Available in viewer and preview view modes.
         * @function
         * @memberof Wix
         * @since 1.77.0
         * @param {Function} onSuccess - callback to be called with an object containing ads width & height
         *
         * @example
         *
         * Wix.getAdsOnPage(onSuccess);
         *
         * in case adds exist, the onSuccess callback will be called with an object like:
         * {
         *      top: {
         *          height: 26,
         *          width: 155
         *      },
         *      bottom: {
         *          height: 40,
         *          width: 684
         *      }
         * }
         */
        getAdsOnPage: getAdsOnPage,


        /**
         * Before showing sensitive information or making an action which requires a secure session,
         * an app should verify that a secure session exists.
         * Get a newly signed app instance by calling Wix.revalidateSession.
         * @function
         * @memberof Wix
         * @since 1.75.0
         * @param {Function} onSuccess Receives a newly signed and encoded app instance.
         * @param {Function} onFailure
         * @example
         *
         *
         * Wix.revalidateSession(function(instanceData){
         *  //handle success use-case
         * }, function(error){
         *    //Handle error use-case
         * });
         */
        revalidateSession: revalidateSession
    };
});
