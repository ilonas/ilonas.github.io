/**
 * This is the description for the PubSub namespace.
 * @memberof Wix
 * @namespace Wix.PubSub
 */
define(['privates/pubSub'], function (pubSub) {

    var namespace = 'PubSub';

    var unsubscribe = function (eventName, callBackOrId) {
        pubSub.unsubscribe(namespace, eventName, callBackOrId);
    };

    var subscribe = function (eventName, callBack, receivePastEvents) {
        return pubSub.subscribe(namespace, eventName, callBack, receivePastEvents);
    };

    var publish = function (eventName, data, isPersistent) {
        pubSub.publish(namespace, eventName, data, isPersistent);
    };

    return {
        /**
         * Unsubscribes from receiving further events. The id from the initial subscribe call is used to unsubscribe from furthers notifications.
         * @memberof Wix.PubSub
         * @since 1.25.0
         * @function
         * @param {String} eventName The name of the event to unsubscribe from.
         * @param {Number} subscription Id returned by Wix.PubSub.subscribe.
         * @example
         * //subscribe and then unsubscribe to "my_event_name" event
         * var id = Wix.PubSub.subscribe("my_event_name", function(event) { });
         * Wix.PubSub.unsubscribe("my_event_name", id);
         */
        unsubscribe: unsubscribe,

        /**
         * Subscribes to events from other app parts of a multi-widget TPA.  If the components span multiple pages, they will be notified once they are rendered.
         * It is also possible to receive all notifications prior to rendering by specifying a flag when subscribing to events.
         * If the flag is set, the widget will be notified immediately of any prior events of the type it is registered to receive.
         * @memberof Wix.PubSub
         * @since 1.25.0
         * @function
         * @param {String} eventName The name of the event to subscribe to.
         * @param {Function} callBack function that will respond to events sent from other components of the broadcasting app. it will be given the event object itself and the source of the event.
         * @param {Boolean} [receivePastEvents] a flag to indicate that all past instances of the registered event should be sent to registered listener. This will happen immediately upon registration.
         * @returns {Number} subscription id.
         * @example
         * //subscribe and then unsubscribe to "my_event_name" event
         * Wix.PubSub.subscribe("my_event_name", function(event) {
         *  //process the event which has the following format :
         *  // {
         *  //    name:eventName,
         *  //    data: eventData,
         *  //    origin: compId
         *  // }
         * });
         * // subscribe to "my_event_name" event, events which also happened before this component was rendered will send
         * Wix.PubSub.subscribe("my_event_name", function(event) { }, true);
         */
        subscribe: subscribe,

        /**
         * Broadcasts an event to other extensions of a multi-widget TPA.
         * If the app extensions (Widget, Fixed Positioned Widget, Page) span multiple pages, they will be notified when they are rendered.
         * @memberof Wix.PubSub
         * @since 1.25.0
         * @function
         * @param {String} eventName The name of the event to publish.
         * @param {Object} data Data the object to send to subscribers for this event type.
         * @param {Boolean} [isPersistent] Indicates whether this event is persisted for event subscribers who have not yet subscribed.
         * @example
         * // The following call will publish an app event that can be consumed by all app parts.
         * Wix.PubSub.publish("my_event_name", {value:"this is my message"});
         */
        publish: publish
    };
});