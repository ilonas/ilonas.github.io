define([
    'superApps/Settings',
    'superApps/privates/core',
    'superApps/Base',
    'superApps/Dashboard',
    'superApps/OnBoarding',
    'superApps/Billing',
    'superApps/Mobile',
    'superApps/Editor'
], function (
    Settings,
    core,
    Base,
    Dashboard,
    OnBoarding,
    Billing,
    Mobile,
    Editor
) {
    'use strict';

    core.initSettings();

    return {
        Settings: Settings,
        Dashboard: Dashboard,
        OnBoarding: OnBoarding,
        Billing: Billing,
        Mobile: Mobile,
        Editor: Editor,
        getInstalledInstance: Base.getInstalledInstance,
        getCtToken: Base.getCtToken
    };
});
