/**
 * This is the description for the Worker namespace.
 * @memberof Wix
 * @namespace Wix.Worker
 */
define(['Data', 'privates/sharedAPI', 'privates/postMessage', 'privates/pubSub', 'privates/data', 'privates/analytics', 'privates/performance'], function (Data, sharedAPI, postMessage, pubSub, data, analytics, performance) {

    var namespace = 'Worker';

    var getSiteInfo =  function (onSuccess) {
        sharedAPI.getSiteInfo(namespace, onSuccess);
    };

    var getSitePages = function (options, callback) {
        sharedAPI.getSitePages(namespace, options, callback);
    };

    var getSiteMap = function (callback) {
        sharedAPI.getSiteMap(namespace, callback);
    };

    var addEventListener = function (eventName, callBack) {
        return postMessage.addEventListenerInternal(eventName, namespace, callBack, false);
    };

    var removeEventListener = function (eventName, callBackOrId) {
        postMessage.removeEventListenerInternal(eventName, namespace, callBackOrId, false);
    };

    var currentMember = function (onSuccess) {
        return sharedAPI.currentMember(namespace, onSuccess);
    };

    var pubSubNamespace = `${namespace}.PubSub`;

    var publish = function (eventKey, data, isPersistent) {
        return pubSub.publish(pubSubNamespace, eventKey, data, isPersistent);
    };

    var subscribe = function(eventKey, callBack, receivePastEvents) {
        return pubSub.subscribe(pubSubNamespace, eventKey, callBack, receivePastEvents);
    };

    var unsubscribe = function (eventKey, callBackOrId) {
        return pubSub.unsubscribe(pubSubNamespace, eventKey, callBackOrId);
    };

    var utilsNamespace = `${namespace}.Utils`;

    var getViewMode = function () {
        return sharedAPI.getViewMode(utilsNamespace);
    };

    var getDeviceType = function () {
        return sharedAPI.getDeviceType(utilsNamespace);
    };

    var getLocale = function () {
        return sharedAPI.getLocale(utilsNamespace);
    };

    var getInstanceId = function () {
        return sharedAPI.getInstanceId(utilsNamespace);
    };

    var getIpAndPort = function () {
        return sharedAPI.getIpAndPort(utilsNamespace);
    };

    var navigateToSection = function () {
        sharedAPI.navigateToSection(utilsNamespace, ...arguments);
    };

    var dataPublicNamespace = `${namespace}.Data.Public`;

    var getValue = function (key, onSuccess, onFailure) {
        data.get(dataPublicNamespace, key, { scope: Data.SCOPE.APP }, onSuccess, onFailure);
    };

    var getValues = function (keys, onSuccess, onFailure) {
        data.getMulti(dataPublicNamespace, keys,  { scope: Data.SCOPE.APP }, onSuccess, onFailure);
    };

    var workerPublicNamespace = `${namespace}.Analytics`;

    var registerCampaignPixel = function (pixelType, pixelId){
        analytics.registerCampaignPixel(workerPublicNamespace, pixelType, pixelId);
    };

    var reportCampaignEvent = function(eventType, data){
        analytics.reportCampaignEvent(workerPublicNamespace, eventType, data);
    };

	var workerPerformanceNamespace = `${namespace}.Performance`;

    var applicationLoaded = function() {
        performance.applicationLoaded(workerPerformanceNamespace);
    };

    var applicationLoadingStep = function (stageNumber, stageDescription) {
        performance.applicationLoadingStep(workerPerformanceNamespace, stageNumber, stageDescription);
    };

    return {
        /**
         * @memberof Wix.Worker
         * @since 1.30.0
         * @see Wix.getSiteInfo
         */
        getSiteInfo: getSiteInfo,

        /**
         * @memberof Wix.Worker
         * @since 1.68.0
         * @see Wix.getSitePages
         */
        getSitePages: getSitePages,

        /**
         * @memberof Wix.Worker
         * @since 1.81.0
         * @see Wix.getSiteMap
         */
        getSiteMap: getSiteMap,

        /**
         * @memberof Wix.Worker
         * @since 1.30.0
         * @see Wix.addEventListener
         */
        addEventListener: addEventListener,

        /**
         * @memberof Wix.Worker
         * @since 1.30.0
         * @see Wix.removeEventListener
         */
        removeEventListener: removeEventListener,

        /**
         * @memberof Wix.Worker
         * @since 1.30.0
         * @see Wix.currentMember
         */
        currentMember: currentMember,

        /**
         * @memberof Wix.Worker
         * @since 1.74.0
         * @namespace Wix.Worker.Analytics
         */
        Analytics: {
            /**
             * @since 1.74.0
             * @enum
             * @memberof Wix.Worker.Analytics
             * @see Wix.Analytics.PixelType
             */
            PixelType: analytics.PIXEL_TYPES,

            /**
             * @since 1.74.0
             * @enum
             * @memberof Wix.Worker.Analytics
             * @see Wix.Analytics.PixelEventType
             */
            PixelEventType: analytics.EVENT_TYPES,

            /**
             * @since 1.74.0
             * @memberof Wix.Worker.Analytics
             * @see Wix.Analytics.registerCampaignPixel
             */
            registerCampaignPixel: registerCampaignPixel,

            /**
             * @since 1.74.0
             * @memberof Wix.Worker.Analytics
             * @see Wix.Analytics.reportCampaignEvent
             */
            reportCampaignEvent: reportCampaignEvent
        },

        /**
         * This is the description for the PubSub namespace.
         * @memberof Wix.Worker
         * @namespace Wix.Worker.PubSub
         */
        PubSub: {

            /**
             * @since 1.30.0
             * @memberof Wix.Worker.PubSub
             * @see Wix.PubSub.publish
             */
            publish:publish,

            /**
             * @since 1.30.0
             * @memberof Wix.Worker.PubSub
             * @see Wix.PubSub.subscribe
             */
            subscribe:subscribe,

            /**
             * @since 1.30.0
             * @memberof Wix.Worker.PubSub
             * @see Wix.PubSub.unsubscribe
             */
            unsubscribe:unsubscribe
        },

        /**
         * @memberof Wix.Worker
         * @namespace Wix.Worker.Utils
         */
        Utils: {
            /**
             * @since 1.30.0
             * @memberof Wix.Worker.Utils
             * @see Wix.Utils.getViewMode
             */
            getViewMode:getViewMode,

            /**
             * @since 1.30.0
             * @memberof Wix.Worker.Utils
             * @see Wix.Utils.getDeviceType
             */
            getDeviceType:getDeviceType,

            /**
             * @since 1.30.0
             * @memberof Wix.Worker.Utils
             * @see Wix.Utils.getLocale
             */
            getLocale:getLocale,

            /**
             * @since 1.30.0
             * @memberof Wix.Worker.Utils
             * @see Wix.Utils.getInstanceId
             */
            getInstanceId:getInstanceId,

            /**
             * @since 1.30.0
             * @memberof Wix.Worker.Utils
             * @see Wix.Utils.getDeviceType
             */
            getIpAndPort:getIpAndPort,

            /**
             * @since 1.39.0
             * @memberof Wix.Worker.Utils
             * @author lior.shefer@wix.com
             * @see Wix.Utils.navigateToSection
             */
            navigateToSection:navigateToSection
        },

        /**
         * @memberof Wix.Worker
         * @namespace Wix.Worker.Data
         */
        Data: {
            /**
             * @memberof Wix.Worker.Data
             * @namespace Wix.Worker.Data.Public
             */
            Public: {
                /**
                 * Get value only from APP Scope
                 *
                 * @since 1.62.0
                 * @memberof Wix.Worker.Data.Public
                 * @author mayah@wix.com
                 * @see Wix.Data.Public.get
                 */
                get: getValue,

                /**
                 * Get values only from APP Scope
                 *
                 * @since 1.62.0
                 * @memberof Wix.Worker.Data.Public
                 * @author mayah@wix.com
                 * @see Wix.Data.Public.getMulti
                 */
                getMulti: getValues

            }
        },
        /**
         * @memberof Wix.Worker
         * @namespace Wix.Worker.Performance
         */
        Performance: {
            /**
             * Allows a component app to report that it has been loaded.
             *
             * @function
             * @memberof Wix.Worker.Performance
             * @since 1.70.0
             *
             * @example
             * Wix.Worker.Performance.applicationLoaded()
             *
             */
            applicationLoaded: applicationLoaded,

            /**
             * Allows a component app to report on a loading step
             *
             * @function
             * @memberof Wix.Worker.Performance
             * @since 1.70.0
             * @param {Number} stageNumber Stage number
             * @param {String} [stageDescription] Stage Description
             *
             * @example
             * Wix.Worker.Performance.applicationLoadingStep(2, 'loading images')
             *
             */
            applicationLoadingStep: applicationLoadingStep
        }
    };
});
