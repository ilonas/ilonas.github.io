/**
 * This is the description for the Utils namespace.
 * @memberof Wix
 * @namespace Wix.Utils
 */
define(['privates/core', 'Media', 'privates/utils', 'privates/reporter', 'privates/urlUtils', 'privates/postMessage', 'privates/sharedAPI'],
    function (core, Media, utils, reporter, urlUtils, postMessage, sharedAPI) {

    var namespace = 'Utils';

    var getViewMode =  function () {
        return sharedAPI.getViewMode(namespace);
    };

    var toWixDate = function (date) {
        postMessage.sendMessage(postMessage.MessageTypes.TO_WIX_DATE, namespace);
        return date.toISOString();
    };

    var getCompId = function () {
        postMessage.sendMessage(postMessage.MessageTypes.GET_COMP_ID, namespace);
        return urlUtils.getQueryParameter("compId");
    };

    var getOrigCompId =  function () {
        postMessage.sendMessage(postMessage.MessageTypes.GET_ORIG_COMP_ID, namespace);
        return urlUtils.getQueryParameter("origCompId");
    };

    var getWidth = function () {
        postMessage.sendMessage(postMessage.MessageTypes.GET_WIDTH, namespace);
        return urlUtils.getQueryParameter("width");
    };

    var getLocale = function () {
        return sharedAPI.getLocale(namespace);
    };

    var getCacheKiller = function () {
        postMessage.sendMessage(postMessage.MessageTypes.GET_CACHE_KILLER, namespace);
        return urlUtils.getQueryParameter("cacheKiller");
    };

    var getTarget = function () {
        postMessage.sendMessage(postMessage.MessageTypes.GET_TARGET, namespace);
        return urlUtils.getQueryParameter("target");
    };

    var getSectionUrl = function (sectionIdentifier, callback) {
        if (utils.isObject(sectionIdentifier)) {
            if (utils.isFunction(callback)) {
                if (sectionIdentifier.sectionId) {
                    var args = {
                        sectionIdentifier: sectionIdentifier.sectionId
                    };
                    postMessage.sendMessage(postMessage.MessageTypes.GET_SECTION_URL, namespace, args, callback);
                } else {
                    reporter.reportSdkError('Wrong arguments - an Object with sectionId must be provided');
                }
            } else {
                reporter.reportSdkError('Mandatory arguments - callback must be specified');
            }
        } else {
            var sectionUrl = urlUtils.getQueryParameter("section-url");
            return (sectionUrl && sectionUrl.replace(/\?$/, ""));
        }
    };

    var getInstanceId = function () {
        return sharedAPI.getInstanceId(namespace);
    };

    var getSignDate = function () {
        postMessage.sendMessage(postMessage.MessageTypes.GET_SIGN_DATE, namespace);
        return core.getInstanceValue("signDate");
    };

    var getUid = function () {
        postMessage.sendMessage(postMessage.MessageTypes.GET_UID, namespace);
        return core.getInstanceValue("uid");
    };

    var getPermissions = function (){
        postMessage.sendMessage(postMessage.MessageTypes.GET_PERMISSIONS, namespace);
        return core.getInstanceValue("permissions");
    };

    var getIpAndPort = function () {
        return sharedAPI.getIpAndPort(namespace);
    };

    var getDemoMode = function () {
        postMessage.sendMessage(postMessage.MessageTypes.GET_DEMO_MODE, namespace);
        var mode = core.getInstanceValue("demoMode");
        mode = (mode === null) ? false : mode;

        return mode;
    };

    var getDeviceType = function () {
        return sharedAPI.getDeviceType(namespace);
    };

    var getInstanceValue = function (key) {
        postMessage.sendMessage(postMessage.MessageTypes.GET_INSTANCE_VALUE, namespace);
        return core.getInstanceValue(key);
    };

    var getSiteOwnerId = function () {
        postMessage.sendMessage(postMessage.MessageTypes.GET_SITE_OWNER_ID, namespace);
        return core.getInstanceValue('siteOwnerId');
    };

    var navigateToSection = function() {
        sharedAPI.navigateToSection(namespace, ...arguments);
    };

    return {
        /**
         * This method returns a String which represents the current view mode.
         * @function
         * @memberof Wix.Utils
         * @since 1.12.0
         * @returns {String} The current view mode (editor/preview/site/standalone).
         * @example
         *
         * //viewMode will get a value like 'editor/preview/site'
         * var viewMode = Wix.Utils.getViewMode();
         */
        getViewMode: getViewMode,

        /**
         * Converts a JavaScript Date object into the correct format, ISO 8601, used by Wix APIs when dealing with dates.
         * It follows the same example provided by Mozilla as a polyfill for non-ECMA 262, 5th edition browsers.
         * @function
         * @memberof Wix.Utils
         * @since 1.28.0
         * @param {Date}
         * @return {String} Represents the given date formatted in ISO 8601.
         */
        toWixDate: toWixDate,

        /**
         * This method returns a String which represents the Widget/Page/Settings iframe's component id.
         * @function
         * @memberof Wix.Utils
         * @since 1.12.0
         * @returns {String} The Widget/Page/Settings iframe's component id.
         * @example
         *
         * //compId will get a value like 'TPWdgt-d88e26c-217b-505f-196d-2f6d87f1c2db'
         * var compId = Wix.Utils.getCompId();
         */
        getCompId:getCompId,

        /**
         * This method returns for valid endpoints a String which represents the Widget/Page iframe's component id which opened the App Settings panel.
         * @function
         * @memberof Wix.Utils
         * @since 1.12.0
         * @returns {String} The Widget/Page iframe's component id which opened the App Settings panel, popup or modal. If not exist returns null.
         * @example
         *
         * //origCompId will get a value like 'TPWdgt-d88e26c-217b-505f-196d-2f6d87f1c2db'
         * var origCompId = Wix.Utils.getOrigCompId();
         */
        getOrigCompId:getOrigCompId,

        /**
         * This method returns a Number which represents the Widget/Page/Settings iframe's width.
         * @function
         * @memberof Wix.Utils
         * @since 1.12.0
         * @returns {Number} The Widget/Page/Settings iframe's width.
         * @example
         *
         * // width will get a value like 300
         * var width = Wix.Utils.getWidth();
         */
        getWidth:getWidth,

        /**
         * This method for valid endpoints (Widget/Page/Settings) returns a String which represents the current locale of the site/editor. A locale is an abbreviated language tag that defines the user's language, country and any special variant preference of the user interface (e.g. Number format, Date format, etc.).
         * @function
         * @memberof Wix.Utils
         * @since 1.14.0
         * @return {String} A standard IETF language tag - en (English), es (Spanish), fr (Franch), it (Italian), etc.
         * @example
         *
         * //locale will get a value like 'en', 'es', etc.
         * var locale = Wix.Utils.getLocale()
         */
        getLocale:getLocale,

        /**
         * This method for valid endpoints (Widget/Page) returns a String which is the cacheKiller query parameter.
         * @function
         * @memberof Wix.Utils
         * @since 1.12.0
         * @returns {String} The cacheKiller query parameter, if not exist returns null.
         * @example
         *
         * //cacheKiller will get a value of a random string - 1359996970511
         *var cacheKiller = Wix.Utils.getCacheKiller();
         */
        getCacheKiller:getCacheKiller,

        /**
         * This method for valid endpoints (Widget/Page) returns a String which is the target query parameter (for the section-url).
         * @function
         * @memberof Wix.Utils
         * @since 1.12.0
         * @returns {String} The target query parameter, if not exist returns null.
         * @example
         *
         * //target will get a value like '_top' or '_self'
         * var target = Wix.Utils.getTarget();
         */
        getTarget:getTarget,

        /**
         * This method when no sectionId is given is valid for Page endpoint only.
         *
         * When a sectionId is not provided this method returns a string which is the section-url query parameter.
         *
         * When a sectionId and a callback function are provided this method returns the page app Url for the given sectionId.
         *
         * Please note: The parameter "section-url" here refers to the Page app URL.
         * @function
         * @memberof Wix.Utils
         * @since 1.37.0
         * @param {Object} [sectionId] App pageId defined in dev.wix.com
         * @param {Function} [callback] A callback function that returns the section's URL - this is mandatory if sectionId was provided.
         *
         * @returns {String} The section-url query parameter, if not exist returns null.
         * @returns {Object} The section url for the given sectionId
         *
         * @example
         *
         * //url will get a value of a valid url like 'http://user.wix.com/site#!page/ch6q'
         * var url = Wix.Utils.getSectionUrl()
         *
         * var url = Wix.Utils.getSectionUrl({sectionId: 'mySectionId'}, function(data) {
         *      //do something with data.url
         * })
         */
        getSectionUrl:getSectionUrl,

        /**
         * This method returns a String which represents the app instance Id.
         * @function
         * @memberof Wix.Utils
         * @since 1.12.0
         * @returns {String} An app instance id - a GUID like value (decoded property of the instance query parameter)
         * @example
         *
         * //instanceId will get a GUID like value - e.g. '12de5bae-01e7-eaab-325f-436462858228'
         * var instanceId = Wix.Utils.getInstanceId();
         */
        getInstanceId:getInstanceId,

        /**
         * This method returns a String which represents the app instance signDate.
         * @function
         * @memberof Wix.Utils
         * @deprecated 1.13.0
         * @returns {String} An app instance signDate (property of the decoded instance query parameter).
         * @example
         *
         * //date will get a value like '2013-01-04T02:45:35.302-06:00'
         * var date = Wix.Utils.getSignDate();
         */
        getSignDate:getSignDate,

        /**
         * This method returns a String which represents the user identifier.
         * @function
         * @memberof Wix.Utils
         * @since 1.12.0
         * @returns {String} A user identifier (decoded property of the instance query parameter).
         * @example
         *
         * var uid = Wix.Utils.getUid();
         */
        getUid:getUid,

        /**
         * This method returns a String which represents the user's permissions (decoded property of the instance query parameter).
         * @function
         * @memberof Wix.Utils
         * @since 1.12.0
         * @returns {String} User's permissions (decoded property of the instance query parameter) - permissions can get the value of 'OWNER' for the site owner otherwise it will be null.
         * @example
         *
         * var permissions = Wix.Utils.getPermissions();
         */
        getPermissions:getPermissions,

        /**
         * This method returns a String which represents the app IP and port.
         * @function
         * @memberof Wix.Utils
         * @since 1.13.0
         * @returns {String} An app IP and port (decoded property of the instance query parameter).
         * @example
         *
         * //ipAndPort will get a value like '91.199.119.254/61308'
         * var ipAndPort = Wix.Utils.getIpAndPort();
         */
        getIpAndPort:getIpAndPort,

        /**
         * This method returns a Boolean which represents the app instance demo mode state.
         * @function
         * @memberof Wix.Utils
         * @since 1.12.0
         * @returns {Boolean} An app instance demo mode state (decoded property of the instance query parameter).
         * @example
         *
         * // demoMode will get a value like true/false
         * var demoMode = Wix.Utils.getDemoMode();
         */
        getDemoMode:getDemoMode,

        /**
         * This method returns a String which represents the current device type.
         * @function
         * @memberof Wix.Utils
         * @since 1.20.0
         * @returns {String} The current device type. One of the following: * desktop *mobile
         * @example
         *
         * // deviceType will get a value of 'desktop' or 'mobile'
         * var deviceType = Wix.Worker.Utils.getDeviceType();
         */
        getDeviceType: getDeviceType,

        /**
         * Gets a value contained within the instance by key. If the key does not exist, null is returned
         * @function
         * @memberof Wix.Utils
         * @since 1.44.0
         * @returns {*} The current value of the requested key. If the key does not exist, null is returned.
         * @example
         *
         * // demoMode will get a value of true or false
         * var demoMode = Wix.Utils.getInstanceValue('demoMode');
         */
        getInstanceValue: getInstanceValue,

        /**
         * Navigates to the callers section page in the hosted site.
         * @function
         * @memberof Wix.Utils
         * @since 1.65.0
         * @param {Object} [sectionIdenfitier] App page id defined in dev.wix.com {sectionId : 'sectionId'} can contain noTransition, boolean indicating cancel transition to page.
         * @param {String} [state] New app's state to push into the editor history stack.
         * @param {Function} onFailure This will be called if the hosting site does not include the section app, or if the caller's application does not include a section.
         * @example
         *
         *
         * Wix.Utils.navigateToSection({ sectionId : 'sectionId', noTransition: true }, 'myState', function(error){
         *    //Handle error use-case
         * });
         */
        navigateToSection: navigateToSection,

        /**
         * This method returns a String which represents the site owner's identifier.
         * @function
         * @memberof Wix.Utils
         * @since 1.52.0
         * @returns {String} A site owner identifier.
         * @example
         *
         * var siteOwnerId = Wix.Utils.getSiteOwnerId();
         */
        getSiteOwnerId: getSiteOwnerId,

        Media: Media
    };
});