/**
 * @private
 */
define(['privates/postMessage'], function (postMessage) {

    var namespace = 'WixDataCursor';

    var _callService = function (onSuccess, onFailure, cursorId) {
        var that = this;
        var onComplete = function onComplete(response) {
            if (response.error) {
                onFailure(response);
            } else {
                that._nextCursor = response.data.nextCursor;
                that._previousCursor = response.data.previousCursor;
                that._data = response.data.results;
                onSuccess(response.data.results);
            }
        };

        var args = {
            cursorId: cursorId,
            options: this._options
        };

        postMessage.sendMessage(this._serviceMessageType, namespace, args, onComplete);
    };

    function WixDataCursor(serviceMessageType, data, total, pageSize) {
        if (typeof serviceMessageType !== 'string') {
            throw new TypeError('Mandatory parameters are missing.');
        }

        this._serviceMessageType = serviceMessageType;
        this._data = data || [];
        this._nextCursor = null;
        this._previousCursor = null;
        this._total = total;
        this._pageSize = pageSize;
        this._options = {};
    }

    /**
     * @returns {boolean} If WixDataCursor has more data.
     */
    WixDataCursor.prototype.hasNext = function hasNext() {
        return !!this._nextCursor;
    };

    /**
     * @returns {boolean} If WixDataCursor has previous data.
     */
    WixDataCursor.prototype.hasPrevious = function hasPrevious() {
        return !!this._previousCursor;
    };


    /**
     * @param onSuccess
     * @param onFailure
     * @returns {boolean} The next WixDataCursor object.
     */
    WixDataCursor.prototype.next = function next(onSuccess, onFailure) {
        if(this.hasNext()){
            _callService.call(this, onSuccess, onFailure, this._nextCursor);
        } else {
            onSuccess([]);
        }
    };

    /**
     * @param onSuccess
     * @param onFailure
     * @returns {boolean} The previous WixDataCursor object.
     */
    WixDataCursor.prototype.previous = function previous(onSuccess, onFailure) {
        if(this.hasPrevious()){
            _callService.call(this, onSuccess, onFailure, this._previousCursor);
        } else {
            onSuccess([]);
        }
    };

    /**
     * @param {Object} data
     */
    WixDataCursor.prototype.setData = function setData(data) {
        this._data = data;
    };

    /**
     * @returns {WixDataCursor[]}
     */
    WixDataCursor.prototype.getData = function getData() {
        return this._data;
    };

    /**
     * @param {WixDataCursor} cursor
     */
    WixDataCursor.prototype.setNextCursor = function setNextCursor(cursor) {
        this._nextCursor = cursor;
    };

    /**
     * @param {WixDataCursor} cursor
     */
    WixDataCursor.prototype.setPreviousCursor = function setPreviousCursor(cursor) {
        this._previousCursor = cursor;
    };


    /**
     * @returns {Number} The total number of Object in the cursor.
     */
    WixDataCursor.prototype.getTotal = function getTotal() {
        return this._total;
    };

    /**
     * @returns {Number} The number of the cursor page size.
     */
    WixDataCursor.prototype.getPageSize = function getPageSize() {
        return this._pageSize;
    };

    /**
     * @param {Object} options
     * @returns Sets the cursor options object.
     */
    WixDataCursor.prototype.setOptions = function setOptions(options) {
        this._options = options;
    };

    return WixDataCursor;
});