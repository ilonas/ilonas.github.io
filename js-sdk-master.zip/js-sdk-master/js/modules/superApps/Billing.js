/**
 * A private namespace for the Billing of supperApps.
 * @memberof Wix
 * @namespace Wix.Billing
 */
define(['privates/utils', 'privates/reporter', 'privates/sharedAPI'],
    function (utils, reporter, sharedAPI) {

    var namespace = 'SuperApps.Billing';

    var getProducts = function (options, onSuccess, onError) {
        sharedAPI.getProducts(namespace, options, onSuccess, onError);
    };

    return {
    /**
     * Returns an Array of objects containing product and pricing info.
     * @function
     * @memberof Wix.Billing
     * @since 1.76.0
     * @param {Object} [options] An object that can contain 'appDefinitionId' of the app to get the products for and 'currency' which defines the currency of the returned products
     * @param {Function} onSuccess A callback function to receive the products.
     * @param {Function} [onError] A callback error function.
     *
     * @example
     * var onError = function () {
     *  //handle the error
     * };
     * var onSuccess = function (data) {
     *  //handle onSuccess
     *  //sample data schema:
     *  [{
     *     "id": <vendorProductId>,
     *     "name": "App Premium Package",
     *     "price": "4.95",
     *     "is_active": true,
     *     "freeMonth": true,
     *     "currencyCode": "USD",
     *     "currencySymbol": "US$"
     *     "monthly": {
     *          "price": "4.95",
     *          "url": "https://premium.wix.com/wix/api/tpaPriceQuote?appInstanceId=aaa-bbb&appDefinitionId=aa-bb&paymentCycle=MONTHLY&vendorProductId=1234"
     *     },
     *     "yearly": {
     *          "price": "3.97",
     *          "url": "https://premium.wix.com/wix/api/tpaPriceQuote?appInstanceId=aaa-bbb&appDefinitionId=aa-bb&paymentCycle=YEARLY&vendorProductId=1234"
     *     },
     *     "oneTime": {
     *          "price": "5.99",
     *          "url": "https://premium.wix.com/wix/api/tpaPriceQuote?appInstanceId=aaa-bbb&appDefinitionId=aa-bb&paymentCycle=ONE_TIME&vendorProductId=1234"
     *     },
     *     "bestSellingFeature": "",
     *      "discountPercent": 20
     *     ]
     *  }]
     *
     * };
     * Wix.Billing.getProducts({appDefinitionId: 'appDefId', currency: 'USD'}, onSuccess, onError);
     */
      getProducts: getProducts
    };
});
