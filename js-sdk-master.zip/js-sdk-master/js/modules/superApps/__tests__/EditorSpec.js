define(['superApps/Editor', 'privates/reporter', 'privates/postMessage', 'privates/viewMode'], function (Editor, reporter, postMessage, viewMode) {
    'use strict';

    describe('Editor', function () {

        var namespace = 'SuperApps.Editor';

        beforeEach(function () {
            spyOn(reporter, 'reportSdkError');
            spyOn(postMessage, 'sendMessage');
            spyOn(viewMode, 'getViewMode').and.returnValue('editor');
        });

        describe('addApplication', function () {

            beforeEach(function () {
                this.onSuccessSpy = jasmine.createSpy('onSuccess');
                this.onErrorSpy = jasmine.createSpy('onError');
            });

            it('should reprot an error if appDefinitionId is not passed', function () {
                Editor.addApplication();

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - appDefinitionId - should be of type String');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should reprot an error if appDefinitionId is not a string', function () {
                Editor.addApplication(1);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - appDefinitionId - should be of type String');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should send post message if appDefId is valid', function () {
                Editor.addApplication('appDefId');

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.ADD_APPLICATION, namespace, {
                    appDefinitionId: 'appDefId'
                }, jasmine.any(Function));
            });

            it('should reprot an error if second param is not a function or object', function(){
                Editor.addApplication('appDefId', 1);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - second argument should be of type Object or Function');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            describe('when second param is an object', function () {

                it('should reprot an error if onSuccess is not a function', function () {
                    Editor.addApplication('appDefId', {}, 1);

                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - onSuccess - should be of type Function');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should reprot an error if onError is not a function', function () {
                    Editor.addApplication('appDefId', {}, this.onSuccessSpy, 1);

                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - onError - should be of type Function');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should send post message if all params are valid', function () {
                    Editor.addApplication('appDefId', {}, this.onSuccessSpy, this.onErrorSpy);

                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.ADD_APPLICATION, namespace, {
                        appDefinitionId: 'appDefId'
                    }, jasmine.any(Function));
                });
            });

            describe('when second param is a function', function(){

                it('should reprot an error if onError is not a function', function () {
                    Editor.addApplication('appDefId', this.onSuccessSpy, 1);

                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - onError - should be of type Function');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should send post message if all params are valid', function () {
                    Editor.addApplication('appDefId', this.onSuccessSpy, this.onErrorSpy);

                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.ADD_APPLICATION, namespace, {
                        appDefinitionId: 'appDefId'
                    }, jasmine.any(Function));
                });
            });
        });
    });
});
