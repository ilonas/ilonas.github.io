define(['privates/reporter', 'privates/postMessage', 'Utils', 'superApps/Billing', 'privates/sharedAPI'],
    function (reporter, postMessage, Utils, Billing, sharedAPI) {
    'use strict';

    describe('SuperApps Billing', function () {

        beforeEach(function () {
            spyOn(reporter, 'reportSdkError');
            spyOn(postMessage, 'sendMessage');
            this.onSuccessSpy = jasmine.createSpy('onSuccess');
            this.onErrorSpy = jasmine.createSpy('onError');
        });

        describe('getProducts', function () {

            beforeEach(function () {
                spyOn(sharedAPI, 'getProducts').and.callThrough();
            });

            it('should call sharedAPI.getProducts with all params', function () {
                Billing.getProducts({appDefinitionId: '1'}, this.onSuccessSpy, this.onErrorSpy);

                expect(sharedAPI.getProducts).toHaveBeenCalledWith('SuperApps.Billing', {appDefinitionId: '1'}, this.onSuccessSpy, this.onErrorSpy);
            });
        });
    });
});
