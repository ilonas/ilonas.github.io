define(['privates/postMessage', 'superApps/privates/core', 'superApps/Settings', 'privates/sharedAPI', 'privates/reporter', 'privates/viewMode'],
    function (postMessage, SuperAppsCore, SuperAppsSettings, sharedAPI, reporter, viewMode) {
    'use strict';

    describe('SuperApps Settings', () => {
        var postMessageSpy;

        beforeEach(function(){
            spyOn(reporter, 'reportSdkError');
            spyOn(postMessage, 'sendMessage');
        });

        describe('openBillingPage', () => {
            let mockUpgradeUrl;
            beforeEach(() => {
                spyOn(SuperAppsCore, 'getWixUpgradeUrl').and.returnValue(mockUpgradeUrl);
                spyOn(window, 'open');
                mockUpgradeUrl = 'https://premium.wix.com/wix/api/premiumStart?appDefId=1380b703-ce81-ff05-f115-39571d94dfcd&referralAdditionalInfo&siteGuid=76af8c6f-3fb4-46c6-aa58-7109f8216011';
            });

            describe('when upgrade url is not defined', function () {

                beforeEach(function () {
                    SuperAppsCore.getWixUpgradeUrl.and.returnValue(null);
                });

                it('should send openBillingPage message with referrer when passed as string', () => {
                    SuperAppsSettings.openBillingPage('referrer');
                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.OPEN_BILLING_PAGE, 'SuperApps.Settings', {referrer: 'referrer'});
                });

                it('should send openBillingPage message without parameters', () => {
                    SuperAppsSettings.openBillingPage();
                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.OPEN_BILLING_PAGE, 'SuperApps.Settings', {});
                });

                it('should send openBillingPage message when empty object was passed', () => {
                    SuperAppsSettings.openBillingPage({});
                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.OPEN_BILLING_PAGE, 'SuperApps.Settings', {});
                });

                it('should send openBillingPage message with referrer when passed in object', () => {
                    SuperAppsSettings.openBillingPage({referrer: 'referrer'});
                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.OPEN_BILLING_PAGE, 'SuperApps.Settings', {referrer: 'referrer'});
                });

                it('should send openBillingPage message with premiumIntent when passed', () => {
                    SuperAppsSettings.openBillingPage({premiumIntent: 'FREE'});
                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.OPEN_BILLING_PAGE, 'SuperApps.Settings', {premiumIntent: 'FREE'});
                });

                it('should report error if options.premiumIntent is not a string', () => {
                    SuperAppsSettings.openBillingPage({premiumIntent: 123});
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Unsupported premiumIntent - 123 - should be one of Wix.Settings.PremiumIntent');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should report error if options.premiumIntent is not a one of the enum options', () => {
                    SuperAppsSettings.openBillingPage({premiumIntent: 'unknown'});
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Unsupported premiumIntent - unknown - should be one of Wix.Settings.PremiumIntent');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should send openBillingPage message with premiumIntent and referrer when passed', () => {
                    SuperAppsSettings.openBillingPage({premiumIntent: 'FREE', referrer: 'referrer'});
                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.OPEN_BILLING_PAGE, 'SuperApps.Settings', {premiumIntent: 'FREE', referrer: 'referrer'});
                });
            });

            describe('when upgrade url is defined', function () {

                it('should open external window when no parameters passed and send message to track app upgrade', () => {
                    SuperAppsSettings.openBillingPage();
                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(window.open).toHaveBeenCalledWith(mockUpgradeUrl);
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.TRACK_APP_UPGRADE, 'SuperApps.Settings');
                });

                it('should open external window when empty object passed and send message to track app upgrade', () => {
                    SuperAppsSettings.openBillingPage({});
                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(window.open).toHaveBeenCalledWith(mockUpgradeUrl);
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.TRACK_APP_UPGRADE, 'SuperApps.Settings');
                });

                it('should add referralAdditionalInfo to the url when referrer is passed as string', () => {
                    SuperAppsSettings.openBillingPage('test_referrer');
                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    var expectedUpgradeUrl = 'https://premium.wix.com/wix/api/premiumStart?appDefId=1380b703-ce81-ff05-f115-39571d94dfcd&referralAdditionalInfo=test_referrer&siteGuid=76af8c6f-3fb4-46c6-aa58-7109f8216011';
                    expect(window.open).toHaveBeenCalledWith(expectedUpgradeUrl);
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.TRACK_APP_UPGRADE, 'SuperApps.Settings');
                });

                it('should add referralAdditionalInfo to the url when referrer is passed in object', () => {
                    SuperAppsSettings.openBillingPage({referrer: 'test_referrer'});
                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    var expectedUpgradeUrl = 'https://premium.wix.com/wix/api/premiumStart?appDefId=1380b703-ce81-ff05-f115-39571d94dfcd&referralAdditionalInfo=test_referrer&siteGuid=76af8c6f-3fb4-46c6-aa58-7109f8216011';
                    expect(window.open).toHaveBeenCalledWith(expectedUpgradeUrl);
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.TRACK_APP_UPGRADE, 'SuperApps.Settings');
                });

                it('should add premiumIntent to the url when passed', () => {
                    SuperAppsSettings.openBillingPage({premiumIntent: 'FREE'});
                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    var expectedUpgradeUrl = 'https://premium.wix.com/wix/api/premiumStart?appDefId=1380b703-ce81-ff05-f115-39571d94dfcd&referralAdditionalInfo&siteGuid=76af8c6f-3fb4-46c6-aa58-7109f8216011&premiumIntent=FREE'
                    expect(window.open).toHaveBeenCalledWith(expectedUpgradeUrl);
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.TRACK_APP_UPGRADE, 'SuperApps.Settings');
                });

                it('should report error if options.premiumIntent is not a string', () => {
                    SuperAppsSettings.openBillingPage({premiumIntent: 123});
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Unsupported premiumIntent - 123 - should be one of Wix.Settings.PremiumIntent');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should report error if options.premiumIntent is not a one of the enum options', () => {
                    SuperAppsSettings.openBillingPage({premiumIntent: 'unknown'});
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Unsupported premiumIntent - unknown - should be one of Wix.Settings.PremiumIntent');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should add premiumIntent and referralAdditionalInfo to the url when passed', () => {
                    SuperAppsSettings.openBillingPage({premiumIntent: 'FREE', referrer: 'test_referrer'});
                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    var expectedUpgradeUrl = 'https://premium.wix.com/wix/api/premiumStart?appDefId=1380b703-ce81-ff05-f115-39571d94dfcd&referralAdditionalInfo=test_referrer&siteGuid=76af8c6f-3fb4-46c6-aa58-7109f8216011&premiumIntent=FREE';
                    expect(window.open).toHaveBeenCalledWith(expectedUpgradeUrl);
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.TRACK_APP_UPGRADE, 'SuperApps.Settings');
                });
            });
        });

        describe('openMediaDialog', () => {
            it('should call the shared api openMediaDialog function with correct message', function () {
                spyOn(sharedAPI, 'openMediaDialog');
                var success = jasmine.createSpy('success');

                SuperAppsSettings.openMediaDialog(SuperAppsSettings.MediaType.SECURE_MUSIC, false, success);

                expect(sharedAPI.openMediaDialog.calls.argsFor(0)[0]).toEqual(postMessage.MessageTypes.OPEN_MEDIA_DIALOG);
            });

            it('should call the shared api openMediaDialog function with correct supported media types', function () {
                spyOn(sharedAPI, 'openMediaDialog');
                var success = jasmine.createSpy('success');

                SuperAppsSettings.openMediaDialog(SuperAppsSettings.MediaType.SECURE_MUSIC, false, success);

                expect(sharedAPI.openMediaDialog.calls.argsFor(0)[0]).toEqual(postMessage.MessageTypes.OPEN_MEDIA_DIALOG);
                expect(sharedAPI.openMediaDialog.calls.argsFor(0)[2]).toEqual(SuperAppsSettings.MediaType);
            });
        });

        describe('open modal', () => {
           it('should call shared api open modal', () => {
               spyOn(sharedAPI, 'openModal');
               let options = {
                   padding: false,
                   transparent: true,
                   overlay: 'rbga(0,0,0,0)',
                   background: 'rbga(0,0,0,0)'
               };
               SuperAppsSettings.openModal('http://www.haxs0r.com', 100, 100, 'Testing title in modal', true, options);
               expect(sharedAPI.openModal).toHaveBeenCalledWith('SuperApps.Settings', 'http://www.haxs0r.com', 100, 100, 'Testing title in modal', true, options, undefined);
            });
        });

        describe('setHelpArticle', function () {

            it('should report an error if articleId is not passed', function(){
                SuperAppsSettings.setHelpArticle();

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory arguments - articleId must be a string');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report an error if articleId is not a string', function(){
                SuperAppsSettings.setHelpArticle(1);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory arguments - articleId must be a string');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should send post message if articleId is valid', function(){
                SuperAppsSettings.setHelpArticle('id');

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SET_HELP_ARTICLE, 'SuperApps.Settings', {
                    articleId: 'id',
                    type: undefined
                });
            });

            it('should report an error if options is not an object', function(){
                SuperAppsSettings.setHelpArticle('id',1);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - options must be of type object');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report an error if type is not \'SETTINGS\' or \'MODAL\'', function(){
                SuperAppsSettings.setHelpArticle('id', {type: 'test'});

                expect(reporter.reportSdkError).toHaveBeenCalledWith("Invalid argument - type can only be 'SETTINGS' or 'MODAL'");
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should send post message if type is SETTINGS', function(){
                SuperAppsSettings.setHelpArticle('id', {type: 'SETTINGS'});

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SET_HELP_ARTICLE, 'SuperApps.Settings', {
                    articleId: 'id',
                    type: 'SETTINGS'
                });
            });

            it('should send post message if type is MODAL', function(){
                SuperAppsSettings.setHelpArticle('id', {type: 'MODAL'});

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SET_HELP_ARTICLE, 'SuperApps.Settings', {
                    articleId: 'id',
                    type: 'MODAL'
                });
            });
        });

        describe('addApplication', function () {

            var namespace = 'SuperApps.Settings';

            beforeEach(function () {
                spyOn(viewMode, 'getViewMode').and.returnValue('editor');
                this.onSuccessSpy = jasmine.createSpy('onSuccess');
                this.onErrorSpy = jasmine.createSpy('onError');
            });

            it('should reprot an error if appDefinitionId is not passed', function () {
                SuperAppsSettings.addApplication();

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - appDefinitionId - should be of type String');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should reprot an error if appDefinitionId is not a string', function () {
                SuperAppsSettings.addApplication(1);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - appDefinitionId - should be of type String');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should send post message if appDefId is valid', function () {
                SuperAppsSettings.addApplication('appDefId');

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.ADD_APPLICATION, namespace, {
                    appDefinitionId: 'appDefId'
                }, jasmine.any(Function));
            });

            it('should reprot an error if second param is not a function or object', function () {
                SuperAppsSettings.addApplication('appDefId', 1);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - second argument should be of type Object or Function');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            describe('when second param is an object', function () {

                it('should reprot an error if onSuccess is not a function', function () {
                    SuperAppsSettings.addApplication('appDefId', {}, 1);

                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - onSuccess - should be of type Function');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should reprot an error if onError is not a function', function () {
                    SuperAppsSettings.addApplication('appDefId', {}, this.onSuccessSpy, 1);

                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - onError - should be of type Function');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should send post message if all params are valid', function () {
                    SuperAppsSettings.addApplication('appDefId', {}, this.onSuccessSpy, this.onErrorSpy);

                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.ADD_APPLICATION, namespace, {
                        appDefinitionId: 'appDefId'
                    }, jasmine.any(Function));
                });
            });

            describe('when second param is a function', function () {

                it('should reprot an error if onError is not a function', function () {
                    SuperAppsSettings.addApplication('appDefId', this.onSuccessSpy, 1);

                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - onError - should be of type Function');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should send post message if all params are valid', function () {
                    SuperAppsSettings.addApplication('appDefId', this.onSuccessSpy, this.onErrorSpy);

                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.ADD_APPLICATION, namespace, {
                        appDefinitionId: 'appDefId'
                    }, jasmine.any(Function));
                });
            });
        });

    });
});
