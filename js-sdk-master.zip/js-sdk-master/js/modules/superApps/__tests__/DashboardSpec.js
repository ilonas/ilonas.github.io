define(['privates/postMessage', 'superApps/Dashboard'], function (postMessage, SuperAppsDashboard) {
    'use strict';

    describe('SuperApps Dashboard', function(){
        beforeEach(function() {
            spyOn(postMessage, 'sendMessage');
        });

        describe('showHeader', function() {
            it('should send show header message when showHeader is called', function(){
                SuperAppsDashboard.showHeader();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SHOW_DASHBOARD_HEADER, 'SuperApps.Dashboard');
            });
        });

        describe('hideHeader', function () {
            it('should send hide header message when hideHeader is called', function(){
                SuperAppsDashboard.hideHeader();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.HIDE_DASHBOARD_HEADER, 'SuperApps.Dashboard');
            });
        });
    });
});
