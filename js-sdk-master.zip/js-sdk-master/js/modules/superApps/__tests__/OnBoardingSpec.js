define(['superApps/OnBoarding', 'privates/postMessage'], function (OnBoarding, postMessage) {
    'use strict';

    describe('SuperApps OnBoarding', function(){
        beforeEach(function() {
            spyOn(postMessage, 'sendMessage');
        });

        describe('getStyleByCompId', function() {
            it('should send get style by comp id message when Settings.getStyleByCompId is called', function(){
                var callback = _.noop();
                OnBoarding.Settings.getStyleByCompId('compId');
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_STYLE_BY_COMP_ID, 'SuperApps.OnBoarding', {}, callback);
            });
        });
    });
});