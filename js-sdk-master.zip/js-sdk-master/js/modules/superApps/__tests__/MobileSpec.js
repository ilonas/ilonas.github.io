define(['privates/sharedAPI',
        'privates/reporter',
        'privates/postMessage',
        'superApps/Mobile'], function(sharedAPI, reporter, postMessage, Mobile) {

    'use strict';

    describe('Mobile', function() {

     beforeEach(function() {
            this.expectedNameSpace = 'SuperApps.Mobile';
            spyOn(reporter, 'reportSdkError');
            spyOn(postMessage, 'sendMessage');
        });

        describe('when in mobile mode', function() {

            beforeEach(function() {
                spyOn(sharedAPI, 'getDeviceType').and.returnValue('mobile');
            });

            describe('showFullscreen & hideFullscreen', function() {
                describe('showFullscreen - when entering full screen mode', function() {
                    it('should call postMessage with "isFullScreen" eq "true" and passed callback', function() {
                        Mobile.showFullscreen();

                        expect(postMessage.sendMessage).toHaveBeenCalledWith('setFullScreenMobile', this.expectedNameSpace, {
                            isFullScreen: true
                        }, jasmine.any(Function));
                    });
                });

                describe('hideFullscreen - when leaving full screen mode', function() {
                    it('should call postMessage with "isFullScreen" eq "false" and passed callback', function() {
                        Mobile.hideFullscreen();

                        expect(postMessage.sendMessage).toHaveBeenCalledWith('setFullScreenMobile', this.expectedNameSpace, {
                            isFullScreen: false
                        }, jasmine.any(Function));
                    });
                });
            });

            describe('setMobileActionBarButton', function() {

                beforeEach(function() {
                    this.onSuccess = jasmine.createSpy();
                    this.onFail = jasmine.createSpy();
                });

                describe('when passing options param without "visibility" or "notifications" properties', function() {
                    it('should not call postMessage', function() {
                        Mobile.setMobileActionBarButton({foo: 'bar', numb: 'ear', ab: '10'}, this.onSuccess, this.onFail);

                        expect(postMessage.sendMessage).not.toHaveBeenCalled();
                        expect(reporter.reportSdkError).toHaveBeenCalledWith('"options"{object} param must contain "visible"{boolean} or "notifications"{boolean} properties');
                    });
                });

                describe('when updating visibility of app button in QUAB', function() {
                    it('should call postMessage with "setMobileActionBarButton" and the "visible" property from the options', function() {
                        var options = {visible: true, foo: 'bar'};
                        Mobile.setMobileActionBarButton(options, this.onSuccess, this.onFail);

                        expect(reporter.reportSdkError).not.toHaveBeenCalled();
                        expect(postMessage.sendMessage).toHaveBeenCalledWith('setMobileActionBarButton',
                            this.expectedNameSpace, {visible: true}, jasmine.any(Function));
                    });
                });

                describe('when updating notifications of app button in QUAB', function() {
                    it('should call postMessage with "setMobileActionBarButton" and the "notifications" property from the options', function() {
                        Mobile.setMobileActionBarButton({notifications: false, bar: 'foo'}, this.onSuccess, this.onFail);

                        expect(reporter.reportSdkError).not.toHaveBeenCalled();
                        expect(postMessage.sendMessage).toHaveBeenCalledWith('setMobileActionBarButton',
                            this.expectedNameSpace, {notifications: false}, jasmine.any(Function));
                    });
                });

                describe('callbacks', function() {
                    it('should call the onSuccess with a "data" argument when invocation was successful', function() {
                        postMessage.sendMessage.and.callFake(function(msgType, namespace, params, callback) {
                            var data = 'success';
                            callback(data);
                        });

                        Mobile.setMobileActionBarButton({notifications: true}, this.onSuccess, this.onFail);

                        expect(this.onSuccess).toHaveBeenCalledWith('success');
                    });

                    it('should call the onFail with an error parameter when invocation failed', function() {
                        var data = {
                            error: 'truthy value'
                        };
                        postMessage.sendMessage.and.callFake(function(msgType, namespace, params, callback) {
                            callback(data);
                        });

                        Mobile.setMobileActionBarButton({notifications: true}, this.onSuccess, this.onFail);

                        expect(this.onFail).toHaveBeenCalledWith(data);
                    });
                });
            });
        });

        describe('when NOT in mobile mode', function() {

            beforeEach(function() {
                spyOn(sharedAPI, 'getDeviceType').and.returnValue('notMobileMode');
            });

            describe('showFullscreen & hideFullscreen', function() {
                it('should report an error, that you need to switch to Mobile mode in order to use the API', function() {
                    Mobile.hideFullscreen();
                    Mobile.showFullscreen();

                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('You must switch to Mobile mode in order to use the Mobile API');
                });
            });

            describe('setMobileActionBarButton', function() {

                it('should report an error, that you need to switch to Mobile mode in order to use the API', function() {
                    let onSuccess = jasmine.createSpy();
                    let onFail = jasmine.createSpy();

                    Mobile.setMobileActionBarButton({foo: 'bar', numb: 'ear', ab: '10'}, onSuccess, onFail);

                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('You must switch to Mobile mode in order to use the Mobile API');
                });
            });
        });
    });
});