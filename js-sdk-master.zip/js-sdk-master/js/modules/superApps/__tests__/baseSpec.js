define(['privates/reporter', 'superApps/Base', 'privates/postMessage', 'privates/viewMode'],
    function (reporter, SuperAppsBase, postMessage, viewMode) {
    'use strict';

    describe('SuperApps Base', function(){
        describe('getInstalledInstance', function() {
            var mockFunc;

            beforeEach(function(){
                mockFunc = jasmine.createSpy('mockFunction');
                spyOn(reporter, 'reportSdkError');
                spyOn(viewMode, 'getViewMode').and.returnValue('editor');
            });

            it('should report error if appDefinitionId argument is invalid', function(){
                SuperAppsBase.getInstalledInstance(1, mockFunc);
                expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - appDefinitionId must be a string');
            });

            it('should report error if onSuccess argument is invalid', function(){
                SuperAppsBase.getInstalledInstance('appDefId', 2);
                expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - onSuccess must be a function');
            });

            it('should report error if onFailure argument is are invalid', function(){
                SuperAppsBase.getInstalledInstance('appDefId', mockFunc, 3);
                expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - onFailure must be a function');
            });

            it('should report error if appDefinitionId argument is missing', function(){
                SuperAppsBase.getInstalledInstance(undefined, mockFunc);
                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory arguments - appDefinitionId & onSuccess must be specified');
            });

            it('should report error if onSuccess argument is missing', function(){
                SuperAppsBase.getInstalledInstance('apDefId');
                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory arguments - appDefinitionId & onSuccess must be specified');
            });

            it('should report error if called in site view mode', function(){
                viewMode.getViewMode.and.returnValue('site');
                SuperAppsBase.getInstalledInstance('appDefId', mockFunc);
                expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid view mode. This function cannot be called in site mode. Supported view modes are: [editor, preview]');
            });

        });

        describe('getCtToken', function() {
            beforeEach(function() {
                spyOn(reporter, 'reportSdkError');
                spyOn(postMessage, 'sendMessage');
            });

            it('should report error if called without onSuccess', function () {
                SuperAppsBase.getCtToken();
                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory argument - onSuccess function must be specified');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error if called with onSuccess which is not a function', function () {
                SuperAppsBase.getCtToken({});
                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory argument - onSuccess function must be specified');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should send message in case onSuccess function is supplied', function () {

                var onSuccess = jasmine.createSpy('onSuccess');
                SuperAppsBase.getCtToken(onSuccess);
                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_CT_TOKEN, 'SuperApps', undefined, onSuccess);
            });

        });
    });
});
