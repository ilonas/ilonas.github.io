/**
 * A private namespace for the Settings of supperApps.
 * @memberof Wix
 * @namespace Wix.Settings
 */
define(['Settings', 'privates/postMessage', 'superApps/privates/core', 'superApps/privates/sharedAPI', 'privates/sharedAPI', 'privates/reporter', 'privates/utils'],
    function (Settings, postMessage, superAppsCore, superAppsSharedAPI, sharedAPI, reporter, utils) {
    'use strict';

    var namespace = 'SuperApps.Settings';

    var openBillingPage = function (referrer) {
        var options = {};
        if (utils.isString(referrer)){
            options.referrer = referrer;
        } else if (utils.isObject(referrer)){
            options = referrer;
        }

        var args = sharedAPI.validateParamsForOpenBillingPage(Settings.PremiumIntent, options);
        if (args){
            var wixUpgradeUrl = superAppsCore.getWixUpgradeUrl();
            if (wixUpgradeUrl){
                if (args.referrer){
                    wixUpgradeUrl = wixUpgradeUrl.replace('referralAdditionalInfo', 'referralAdditionalInfo=' + args.referrer);
                }
                if (args.premiumIntent){
                    wixUpgradeUrl = wixUpgradeUrl.concat('&premiumIntent=' + args.premiumIntent);
                }
                window.open(wixUpgradeUrl);
                postMessage.sendMessage(postMessage.MessageTypes.TRACK_APP_UPGRADE, namespace);

            } else {
                postMessage.sendMessage(postMessage.MessageTypes.OPEN_BILLING_PAGE, namespace, args);
            }
        }
    };

    var openMediaDialog = function (mediaType, multipleSelection, onSuccess, onCancel) {
        sharedAPI.openMediaDialog(postMessage.MessageTypes.OPEN_MEDIA_DIALOG, namespace, this.MediaType, mediaType, multipleSelection, onSuccess, onCancel);
    };

    var openModal = function (url, width, height, title, onClose, bareUI, options) {
        sharedAPI.openModal(namespace, url, width, height, title, onClose, bareUI, options);
    };

    var getMediaTypes = function () {
        var mediaTypes = cloneObject(Settings.MediaType);
        mediaTypes.VIDEO = 'video';
        mediaTypes.SHAPE = 'shape';
        mediaTypes.MUSIC = 'music';
        mediaTypes.CLIPART = 'clipart';
        mediaTypes.BG_VIDEO = 'bg_video';
        mediaTypes.ICON_DOCUMENT = 'icon_document';
        mediaTypes.ICON_SOCIAL = 'bg_social';
        mediaTypes.ICON_FAVICON = 'bg_favicon';
        mediaTypes.MUSIC_PRO = 'secure_music';
        mediaTypes.IMAGE_PRO = 'secure_picture';
        mediaTypes.FLASH = 'swf';
        mediaTypes.BG_IMAGE = 'backgrounds';
        return mediaTypes;
    };

    var cloneObject = function (obj) {
        var clone = {};
        for(var i in obj) {
            if(typeof(obj[i]) === "object" && obj[i] !== null) {
                clone[i] = cloneObject(obj[i]);
            } else {
                clone[i] = obj[i];
            }
        }
        return clone;
    };

    var setHelpArticle = function (articleId, options) {
        if (!utils.isString(articleId)) {
            reporter.reportSdkError('Mandatory arguments - articleId must be a string');
            return;
        }
        if (options && !utils.isObject(options)) {
            reporter.reportSdkError('Invalid argument - options must be of type object');
            return;
        }
        if (options && options.type && (options.type !== 'SETTINGS' && options.type !== 'MODAL')) {
            reporter.reportSdkError("Invalid argument - type can only be 'SETTINGS' or 'MODAL'");
            return;
        }

        var args = {
            articleId: articleId,
            type: options && options.type
        };
        postMessage.sendMessage(postMessage.MessageTypes.SET_HELP_ARTICLE, namespace, args);
    };

    var getInstalledInstance = function(appDefinitionId, onSuccess, onFailure) {
        superAppsSharedAPI.getInstalledInstance(appDefinitionId, namespace, onSuccess, onFailure, namespace);
    };

    var addApplication = function (appDefinitionId, options, onSuccess, onError) {
        sharedAPI.addApplication(namespace, appDefinitionId, options, onSuccess, onError);
    };

    return {
        /**
         * @enum
         * @memberof Wix.Settings
         * @since 1.40.0
         */
        MediaType: getMediaTypes(),
        /**
         * The Wix.Setting.openBillingPage method enables the app to offer a premium package from within the app settings.
         * If a bundle package exists for the app, the Wix Premium package picker will be opened in a new tab.
         * Otherwise, it will open the Wix billing system page in a modal window.
         * @function
         * @memberof Wix.Settings
         * @since 1.78.0
         * @param {Object} options may contain: a 'premiumIntent' property with possible values: Wix.Settings.PremiumIntent. When used, premiumIntent will be added to the premium url
         *                                      a 'referrer' property - when used, a "referralAdditionalInfo" will be added to the premium url.
         * @example
         *
         * Wix.Settings.openBillingPage({referrer: 'referrer', premiumIntent: Wix.Settings.PremiumIntent.FREE});
         */
        openBillingPage: openBillingPage,

        /**
         * The getInstalledInstance method will call the onSuccess callback
         * if the app is installed in the site, otherwise it will call the onFailure callback.
         * The onSuccess callback will be called with an object containing the app instanceId.
         * @function
         * @memberof Wix.Settings
         * @since 1.50.0
         * @param {String} appDefinitionId - the appDefinition Id of the app
         * @param {Function} onSuccess - callback to be called with the app info if the app is installed in the site
         * @param {Function} [onFailure] - callback to be called if the app is not installed in the site
         *
         * @example
         *
         * Wix.Utils.getInstalledInstance('appDefinitionId', onSuccess, onFailure);
         *
         * in case the app is installed the onSuccess callback will be called with object like:
         * {
         *      instanceId: "13cc8929-93a3-45fb-0e68-bb04489f4e8d"
         * }
         *
         * else, if the app is not installed the onFailure callback will be called without any data
         */
        getInstalledInstance: getInstalledInstance,

        /**
         * This method opens the Wix media dialog inside the WIx Editor, and let's the site owner choose a an existing file from the Wix media galleries,
         * or upload a new file instead. When completed a callback function returns the meta data of the selected item/s.
         * This method returns the full meta data descriptor for a selected media item. To access the media item from your code you will need to construct a
         * full URL using that descriptor. Since the media items URLs format is set by Wix and might changed in the future,
         * we are requiring that the URL construction will be done using the SDK. Use one of the Wix.Utils.Media.get* methods to get the desired media item URL.
         * @function
         * @memberof Wix.Settings
         * @since 1.61.0
         * @param {Wix.Settings.MediaType} mediaType Media gallery to choose from - image, background, audio, swf and secure music.
         * @param {Boolean} multiSelect selection mode, single (false) or multiple (true) item to choose from.
         * @param {Function} onSuccess callback function, passing the media item/s meta data.
         * @param {Function} [onCancel] callback function called when user cancels.
         * @return This is an asynchronous function, the returned value is passed in the onSuccess callback function.
         * An object (single selection) or Array of objects (multiple selection). The object describes the meta data of the selected media item.
         *
         * @example
         *
         * Wix.Settings.openMediaDialog(Wix.Settings.MediaType.IMAGE, false, function(data) {
         *    // save image data
         * });
         */
        openMediaDialog: openMediaDialog,

        /**
         * @function
         * @memberof Wix.Settings
         * @since 1.64.0
         * @param {String} url Model iframe url.
         * @param {Number} width The modal window width (can be a string for percent, i.e., '90%', or an integer for pixels, i.e., 90).
         * @param {Number} height The modal window height (can be a string for percent, i.e., '90%', or an integer for pixels, i.e., 90).
         * @param {String} [title] Title of the modal.
         * @param {Function} [onClose] onClose callback function.
         * @param {Boolean} [bareUI] Opens the modal in a bare mode without the modal title, help and close buttons.
         * @param {Object} [options]
         * @example
         * Wix.Settings.openModal('http://www.example.com', '100%','100%', 'title', _.noop, true, {
         *          margin: false,
         *          overlay: 'rgba(0,0,0,0)',
         *          background: 'rgba(0,0,0,0)'
         *      });
         */
        openModal: openModal,

        /**
         * Allow apps to change their settings panel/modal help button based on their context.
         * @function
         * @memberof Wix.Settings
         * @since 1.66.0
         * @param {String} articleID id of the help article (required).
         * @param {Object} options object that can contain a 'type' property with the value 'SETTINGS' or 'MODAL' (if not passed, default is 'SETTINGS').
         * @example
         * Wix.Settings.setHelpArticle('pa423jhc', {
         *          type: 'MODAL'
         *     });
         */
        setHelpArticle: setHelpArticle,

        /**
         * Adds the selected application to the site if it's not already installed.
         * If the application is not published it will only be added if "&appDefinitionId=[APP_DEF_ID]" is added to the site url
         *
         * @function
         * @memberOf Wix.Settings
         * @since 1.83.0
         * @param {string} appDefinitionId the id of the app to be installed
         * @param {object} [options] can contain pageId (string) and shouldNavigate (boolean) properties
         * @param {function} [onSuccess] called after the app was installed successfully
         *   callback signature: function() {}
         * @param {function} [onError] called if there was an error during installation with the error
         * @example
         *
         * Wix.Settings.addApplication(
         *          '1380b703-ce81-ff05-f115-39571d94dfcd',
         *          {pageId: 'c1dmp', shouldNavigate: true},
         *          function(){console.log('app was installed successfully')},
         *          function(data){console.log(data.error)}
         * );
         */
        addApplication: addApplication
    };
});
