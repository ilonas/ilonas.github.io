/**
 * A private namespace for the Dashboard of supperApps.
 * @memberof Wix
 * @namespace Wix.Dashboard
 */

define(['privates/postMessage', 'privates/utils', 'privates/reporter', 'privates/sharedAPI', 'superApps/Settings'], function (postMessage, utils, reporter, sharedAPI, superAppsSettings) {
    'use strict';

    var namespace = 'SuperApps.Dashboard';

    var showHeader = function () {
        postMessage.sendMessage(postMessage.MessageTypes.SHOW_DASHBOARD_HEADER, namespace);
    };

    var hideHeader = function () {
        postMessage.sendMessage(postMessage.MessageTypes.HIDE_DASHBOARD_HEADER, namespace);
    };

    var setHelpArticle = function setHelpArticle(articleId) {
        if (!utils.isString(articleId)) {
            reporter.reportSdkError('Mandatory arguments - articleId must be a string');
            return;
        }

        var args = {
            articleId: articleId
        };
        postMessage.sendMessage(postMessage.MessageTypes.SET_HELP_ARTICLE, namespace, args);
    };

    var getProducts = function (options, onSuccess, onError) {
        if (utils.isObject(options)) {
            sharedAPI.getProducts(namespace, options, onSuccess, onError);
        } else if (utils.isFunction(options)) {
            sharedAPI.getProducts(namespace, {}, options, onSuccess);
        } else {
            reporter.reportSdkError('Invalid argument - options must be an object');
        }
    };

    var openMediaDialog = function (mediaType, multipleSelection, onSuccess, onCancel) {
        sharedAPI.openMediaDialog(postMessage.MessageTypes.SUPER_APPS_OPEN_MEDIA_DIALOG, namespace, superAppsSettings.MediaType, mediaType, multipleSelection, onSuccess, onCancel);
    };

    return {
        /**
         * The Wix.Dashboard.showHeader should be used by super-apps to hide the top my-account header whenever in creation mode such as creating a new shoutout, new album editing a wix-touch application. Going back from editing mode, the super-app must call showHeader again.
         * @function
         * @memberof Wix.Dashboard
         * @since 1.62.0
         * @example
         *
         * Wix.Dashboard.showHeader();
         */
        showHeader: showHeader,

        /**
         * The Wix.Dashboard.hideHeader should be used by super-apps when going back from editing mode to show the my-account header again. The my account header let the user go back to the dashboard, switch apps and view their notifications, so it must be shown again.
         * @function
         * @memberof Wix.Dashboard
         * @since 1.62.0
         * @example
         *
         * Wix.Dashboard.hideHeader();
         */
        hideHeader: hideHeader,

        /**
         * Allow apps to change their  help button based on their context.
         *
         * @since 1.69.0
         * @memberof Wix.Dashboard
         * @param {String} articleID id of the help article (required).
         * @example
         * Wix.Dashboard.setHelpArticle('pa423jhc');
         */
        setHelpArticle: setHelpArticle,

        /**
         * Returns an Array of objects containing product and pricing info.
         * @function
         * @memberof Wix.Dashboard
         * @since 1.71.0
         * @param {Object} options An object that can contain 'appDefinitionId' of the app to get the packages for
         * @param {Function} onSuccess A callback function to receive the products.
         * @param {Function} [onError] A callback error function.
         *
         * @example
         * var onError = function () {
         *  //handle the error
         * };
         * var onSuccess = function (data) {
         *  //handle onSuccess
         *  //sample data schema:
         *  [{
         *     "id": <vendorProductId>,
         *     "name": "App Premium Package",
         *     "price": "4.95",
         *     "is_active": true,
         *     "freeMonth": true,
         *     "currencyCode": "USD",
         *     "currencySymbol": "US$"
         *     "monthly": {
         *          "price": "4.95",
         *          "url": "https://premium.wix.com/wix/api/tpaPriceQuote?appInstanceId=aaa-bbb&appDefinitionId=aa-bb&paymentCycle=MONTHLY&vendorProductId=1234"
         *     },
         *     "yearly:: {
         *          "price": "3.97",
         *          "url": "https://premium.wix.com/wix/api/tpaPriceQuote?appInstanceId=aaa-bbb&appDefinitionId=aa-bb&paymentCycle=YEARLY&vendorProductId=1234"
         *     },
         *     "oneTime": {
         *          "price": "5.99",
         *          "url": "https://premium.wix.com/wix/api/tpaPriceQuote?appInstanceId=aaa-bbb&appDefinitionId=aa-bb&paymentCycle=ONE_TIME&vendorProductId=1234"
         *     },
         *     "bestSellingFeature": "",
         *      "discountPercent": 20
         *     ]
         *  }]
         *
         * };
         * Wix.Dashboard.getProducts(options, onSuccess, onError);
         */
        getProducts: getProducts,

        /**
         * This method opens the Wix media dialog inside the WIx Editor, and let's the site owner choose a an existing file from the Wix media galleries,
         * or upload a new file instead. When completed a callback function returns the meta data of the selected item/s.
         * This method returns the full meta data descriptor for a selected media item. To access the media item from your code you will need to construct a
         * full URL using that descriptor. Since the media items URLs format is set by Wix and might changed in the future,
         * we are requiring that the URL construction will be done using the SDK. Use one of the Wix.Utils.Media.get* methods to get the desired media item URL.
         * @function
         * @memberof Wix.Dashboard
         * @since 1.72.0
         * @param {Wix.Settings.MediaType} mediaType Media gallery to choose from - image, background, audio, swf and secure music.
         * @param {Boolean} multiSelect selection mode, single (false) or multiple (true) item to choose from.
         * @param {Function} onSuccess callback function, passing the media item/s meta data.
         * @param {Function} [onCancel] callback function called when user cancels.
         * @return This is an asynchronous function, the returned value is passed in the onSuccess callback function.
         * An object (single selection) or Array of objects (multiple selection). The object describes the meta data of the selected media item.
         *
         * @example
         *
         * Wix.Dashboard.openMediaDialog(Wix.Settings.MediaType.IMAGE, false, function(data) {
         *    // save image data
         * });
         */
        openMediaDialog: openMediaDialog
    };
});
