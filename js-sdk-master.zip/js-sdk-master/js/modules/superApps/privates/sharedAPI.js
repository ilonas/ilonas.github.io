define(['privates/postMessage', 'privates/reporter', 'privates/utils'], function (postMessage, reporter, utils) {
    'use strict';

    var getInstalledInstance = function(appDefinitionId, namespace, onSuccess, onFailure){
        if (!appDefinitionId || !onSuccess) {
            reporter.reportSdkError('Mandatory arguments - appDefinitionId & onSuccess must be specified');
            return;
        }
        if (!utils.isString(appDefinitionId)) {
            reporter.reportSdkError('Invalid argument - appDefinitionId must be a string');
            return;
        }
        if (!utils.isFunction(onSuccess)) {
            reporter.reportSdkError('Invalid argument - onSuccess must be a function');
            return;
        }
        if (onFailure && !utils.isFunction(onFailure)) {
            reporter.reportSdkError('Invalid argument - onFailure must be a function');
            return;
        }
        var callback = function (data) {
            if (data.onError) {
                if (onFailure) {
                    onFailure();
                }
            } else {
                onSuccess.apply(this, arguments);
            }
        };

        var args = {appDefinitionId: appDefinitionId};
        postMessage.sendMessage(postMessage.MessageTypes.GET_INSTALLED_INSTANCE, namespace, args, callback);
    };

    return {
        getInstalledInstance: getInstalledInstance
    };
});