define(['superApps/privates/core', 'privates/postMessage'], function (SuperAppsCore, postMessage) {
    'use strict';

    describe('SuperApps core', function(){
        var mockUpgradeUrl = 'mockUrl.com';

        beforeEach(function(){
            spyOn(postMessage, 'sendMessage').and.callFake(function(messageType, namespace, args, callback){
                callback(mockUpgradeUrl);
            });
        });

        it('should send post message on loading to get the upgrade url', function(){
            SuperAppsCore.initSettings();
            expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_WIX_UPGRADE_URL, undefined, null, jasmine.any(Function));
            expect(SuperAppsCore.getWixUpgradeUrl()).toEqual(mockUpgradeUrl);
        });
    });
});
