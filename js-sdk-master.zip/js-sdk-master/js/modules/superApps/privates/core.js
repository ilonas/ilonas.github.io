var postMessage = require('privates/postMessage');

var wixUpgradeUrl;

var initSettings = () => {
    postMessage.sendMessage(postMessage.MessageTypes.GET_WIX_UPGRADE_URL, undefined, null, (url) => { wixUpgradeUrl = url; });
};

var getWixUpgradeUrl = () => {
    return wixUpgradeUrl;
};

module.exports = {
    initSettings: initSettings,
    getWixUpgradeUrl: getWixUpgradeUrl
};
