/**
 * Mobile namespace.
 * @memberof Wix
 * @namespace Wix.Mobile
 */
define(['privates/utils',
        'privates/sharedAPI',
        'privates/reporter',
        'privates/postMessage'], function(utils, sharedAPI, reporter, postMessage) {
    'use strict';

    const NAMESPACE = 'SuperApps.Mobile';

    const isMobileDevice = namespace => {
        return sharedAPI.getDeviceType(namespace) === "mobile";
    };

    const showFullScreenInMobile = (isFullScreen, callback) => {
        postMessage.sendMessage(postMessage.MessageTypes.SET_FULL_SCREEN_MOBILE, NAMESPACE, {
            'isFullScreen': isFullScreen
        }, callback);
    };

    const showFullscreen = (onSuccess, onFail) => {
        showFullScreenInMobile(true, createCallbackHandlingError(onSuccess, onFail));
    };

    const hideFullscreen = (onSuccess, onFail) => {
        showFullScreenInMobile(false, createCallbackHandlingError(onSuccess, onFail));
    };

    const setMobileActionBarButton = (options, onSuccess, onFail) => {
        if (options) {
            const params = getMobileActionsBarParams(options);
            if (Object.keys(params).length > 0) {
                postMessage.sendMessage(postMessage.MessageTypes.SET_MOBILE_ACTION_BAR_BUTTON, NAMESPACE, params, createCallbackHandlingError(onSuccess, onFail));
            } else {
                reporter.reportSdkError('"options"{object} param must contain "visible"{boolean} or "notifications"{boolean} properties');
            }
        }
    };

    const getMobileActionsBarParams = options => {
        var params = {};
        if (utils.isBoolean(options.visible)) {
            params.visible = options.visible;
        }

        if (utils.isBoolean(options.notifications)) {
            params.notifications = options.notifications;
        }
        return params;
    };

    const createCallbackHandlingError = (onSuccess, onFail) => {
        return (data) => {
            if (data && data.error) {
                if (onFail) {
                    onFail(data);
                }
            } else if (onSuccess) {
                onSuccess(data);
            }
        };
    };

    let publicMobileAPI = {

        showFullscreen,

        hideFullscreen,

        setMobileActionBarButton
    };

    const protectByMobile = (func) => {
        return function() {
            if (isMobileDevice(NAMESPACE)) {
                return func.apply(null, arguments);
            }
            reporter.reportSdkError('You must switch to Mobile mode in order to use the Mobile API');
        };
    };

    return utils.mapValues(publicMobileAPI, protectByMobile);
});
