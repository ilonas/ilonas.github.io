/**
 * @memberof Wix
 * @namespace Wix.Editor
 */
define(['privates/sharedAPI'], function (sharedAPI) {

    var namespace = 'SuperApps.Editor';

    var addApplication = function(appDefinitionId, options, onSuccess, onError) {
        sharedAPI.addApplication(namespace, appDefinitionId, options, onSuccess, onError);
    };

    return {
        /**
         * Adds the selected application to the site if it's not already installed.
         * If the application is not published it will only be added if "&appDefinitionId=[APP_DEF_ID]" is added to the site url
         *
         * @function
         * @memberOf Wix.Editor
         * @since 1.83.0
         * @param {string} appDefinitionId the id of the app to be installed
         * @param {object} [options] can contain pageId (string) and shouldNavigate (boolean) properties
         * @param {function} [onSuccess] called after the app was installed successfully
         *   callback signature: function() {}
         * @param {function} [onError] called if there was an error during installation with the error
         * @example
         *
         * Wix.Editor.addApplication(
         *          '1380b703-ce81-ff05-f115-39571d94dfcd',
         *          {pageId: 'c1dmp', shouldNavigate: true},
         *          function(){console.log('app was installed successfully')},
         *          function(data){console.log(data.error)}
         * );
         */
        addApplication
    };
});
