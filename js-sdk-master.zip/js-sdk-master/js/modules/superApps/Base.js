/**
 * This is the description for the Wix namespace for superApps.
 * @namespace Wix
 */
define(['privates/sharedAPI', 'superApps/privates/sharedAPI', 'privates/reporter', 'privates/viewMode', 'privates/postMessage', 'privates/utils'],
    function (sharedAPI, superAppsSharedAPI, reporter, viewMode, postMessage, utils) {
        'use strict';

        var namespace = 'SuperApps';

        var getInstalledInstance = function (appDefinitionId, onSuccess, onFailure) {
            if (viewMode.getViewMode() === 'site') {
                reporter.reportSdkError('Invalid view mode. This function cannot be called in site mode. Supported view modes are: [editor, preview]');
            }
            else {
                superAppsSharedAPI.getInstalledInstance(appDefinitionId, namespace, onSuccess, onFailure);
            }
        };

        var getCtToken = function (onSuccess) {
            if (!utils.isFunction(onSuccess)) {
                reporter.reportSdkError('Mandatory argument - onSuccess function must be specified');
                return;
            }
            postMessage.sendMessage(postMessage.MessageTypes.GET_CT_TOKEN, namespace, undefined, onSuccess);
        };

        return {
            /**
             * The getInstalledInstance method will call the onSuccess callback
             * if the app is installed in the site, otherwise it will call the onFailure callback.
             * The onSuccess callback will be called with an object containing the app instanceId.
             *
             * Available in editor and preview view modes only.
             * @function
             * @memberof Wix
             * @since 1.50.0
             * @param {String} appDefinitionId - the appDefinition Id of the app
             * @param {Function} onSuccess - callback to be called with the app info if the app is installed in the site
             * @param {Function} [onFailure] - callback to be called if the app is not installed in the site
             *
             * @example
             *
             * Wix.getInstalledInstance('appDefinitionId', onSuccess, onFailure);
             *
             * in case the app is installed the onSuccess callback will be called with object like:
             * {
         *      instanceId: "13cc8929-93a3-45fb-0e68-bb04489f4e8d"
         * }
             *
             * else, if the app is not installed the onFailure callback will be called without any data
             */
            getInstalledInstance: getInstalledInstance,

            /**
             * The getCtToken method will call the onSuccess callback with the ctToken .
             *
             * Available in editor, preview view modes.
             * @function
             * @memberof Wix
             * @since 1.68.0
             * @param {Function} onSuccess - callback to be called with the ctToken
             *
             * @example
             *
             * Wix.getCtToken(onSuccess);
             */
            getCtToken: getCtToken
        };
    });
