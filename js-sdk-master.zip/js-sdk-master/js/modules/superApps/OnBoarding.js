/**
 * A private namespace for the Settings of onBoarding.
 * @memberof Wix
 * @namespace Wix.OnBoarding
 */
define(['privates/postMessage'], function (postMessage) {
    'use strict';

    var getStyleByCompId = function (compId, callback) {
        postMessage.sendMessage(postMessage.MessageTypes.GET_STYLE_BY_COMP_ID, 'SuperApps.OnBoarding', {}, callback);
    };

    return {

        /**
         * @memberof Wix.OnBoarding
         * @namespace Wix.OnBoarding.Settings
         */
        Settings: {
            /**
             * @function
             * @memberof Wix.OnBoarding.Settings
             * @since 1.65.0
             * @param {String} compId
             * @example
             * Wix.OnBoarding.Settings.getStyleByCompId('compId', (styles)=> { '//do something w/ the given style' });
             * });
             */
            getStyleByCompId: getStyleByCompId
        }

    };
});
