/**
 * Represents a predefined values to position a Wix popup windows without the hassle of figuring out the position yourself.
 * Can be used to position the window relatively (to the calling widget) or absolutely (to the view port).
 *
 * @memberof Wix
 * @namespace Wix.WindowPlacement
 */
define(function () {
    return {
        /**
         * Top left placement.
         * @memberof Wix.WindowPlacement
         * @since 1.17.0
         */
        TOP_LEFT: 'TOP_LEFT',

        /**
         * Top right placement.
         * @memberof Wix.WindowPlacement
         * @since 1.17.0
         */
        TOP_RIGHT: 'TOP_RIGHT',

        /**
         * Bottom right placement.
         * @memberof Wix.WindowPlacement
         * @since 1.17.0
         */
        BOTTOM_RIGHT: 'BOTTOM_RIGHT',

        /**
         * Bottom left placement.
         * @memberof Wix.WindowPlacement
         * @since 1.17.0
         */
        BOTTOM_LEFT: 'BOTTOM_LEFT',

        /**
         * Top center placement.
         * @memberof Wix.WindowPlacement
         * @since 1.17.0
         */
        TOP_CENTER: 'TOP_CENTER',

        /**
         * Center right placement.
         * @memberof Wix.WindowPlacement
         * @since 1.17.0
         */
        CENTER_RIGHT: 'CENTER_RIGHT',

        /**
         * Bottom center placement.
         * @memberof Wix.WindowPlacement
         * @since 1.17.0
         */
        BOTTOM_CENTER: 'BOTTOM_CENTER',

        /**
         * Center left placement.
         * @memberof Wix.WindowPlacement
         * @since 1.17.0
         */
        CENTER_LEFT: 'CENTER_LEFT',

        /**
         * (FIXED origin only) center of the screen.
         * @memberof Wix.WindowPlacement
         * @since 1.17.0
         * @deprecated
         */
        CENTER: 'CENTER'
    };
});