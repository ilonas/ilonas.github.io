/**
 * Represents a Wix popup window origin. A window can be positioned where it is origin is the view port (0,0) or
 * where the origin is another widget (x,y).
 * @memberof Wix
 * @namespace Wix.WindowOrigin
 */
define(function () {
    return {
        /**
         * Default position. The popup will be placed inside the browser viewport.
         * @see WindowOrigin.FIXED
         * @memberof Wix.WindowOrigin
         * @since 1.17.0
         */
        DEFAULT: 'FIXED',

        /**
         * Fixed position. The popup will be placed inside the browser viewport.
         * @memberof Wix.WindowOrigin
         * @since 1.17.0
         */
        FIXED: 'FIXED',

        /**
         * Relative position. The popup will be placed relative to the opening widget (Not supported for Page).
         * @memberof Wix.WindowOrigin
         * @since 1.17.0
         */
        RELATIVE: 'RELATIVE',

        /**
         * Absolute position. The popup will be placed relative to a given x,y coordinates that their origin is the top-left corner of the widget.
         * @memberof Wix.WindowOrigin
         * @author mayah@wix.com
         * @since 1.28.0
         */
        ABSOLUTE: 'ABSOLUTE'
    };
});