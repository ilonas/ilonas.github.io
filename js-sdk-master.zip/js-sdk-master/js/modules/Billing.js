/**
 * Functions and objects relating to the purchasing and billing process. To define products for purchase within your app, go to the Features section of the Wix Developer app registration <a href="http://dev.wix.com" target="_blank">dev.wix.com</a>.
 * @memberof Wix
 * @namespace Wix.Billing
 */
define(['privates/postMessage', 'privates/utils', 'privates/responseHandlers', 'privates/reporter', 'privates/sharedAPI'], function (postMessage, utils, responseHandlers, reporter, sharedAPI) {

    var namespace = 'Billing';

    var openBillingPageForProduct = function (vendorProductId, cycle, onError) {
        if (!utils.isString(vendorProductId)) {
            reporter.reportSdkError('Missing mandatory argument - vendorProductId must be a string');
            return;
        }
        if (!utils.has(this.Cycle, cycle)) {
            reporter.reportSdkError('Missing mandatory argument - cycle must be one of Wix.Billing.Cycle');
            return;
        }

        var args = {
            vendorProductId: vendorProductId,
            cycle: cycle
        };

        postMessage.sendMessage(postMessage.MessageTypes.OPEN_BILLING_PAGE_FOR_PRODUCT, namespace, args, onError);
    };

    var getBillingPageForProduct = function (vendorProductId, cycle, onSuccess, onError) {
        if (!utils.isString(vendorProductId)) {
            reporter.reportSdkError('Missing mandatory argument - vendorProductId must be a string');
            return;
        }
        if (!utils.has(this.Cycle, cycle)) {
            reporter.reportSdkError('Missing mandatory argument - cycle must be one of Wix.Billing.Cycle');
            return;
        }

        if (!utils.isFunction(onSuccess)) {
            reporter.reportSdkError('Missing mandatory argument - onSuccess must be a function');
            return;
        }

        var args = {
            vendorProductId: vendorProductId,
            cycle: cycle
        };

        var onComplete = function onComplete(result) {
            responseHandlers.handleDataResponse(result, onSuccess, onError);
        };

        postMessage.sendMessage(postMessage.MessageTypes.GET_BILLING_PAGE_FOR_PRODUCT, namespace, args, onComplete);
    };

    var getBillingPackages = function (vendorProductIds, onSuccess, onError) {
        if (utils.isFunction(vendorProductIds)) {
            onSuccess = vendorProductIds;
            vendorProductIds = undefined;
        }

        if (!utils.isFunction(onSuccess)) {
            reporter.reportSdkError('Missing mandatory argument - onSuccess must be a function');
            return;
        }

        var args = {
            vendorProductIds: vendorProductIds
        };

        var onComplete = function onComplete(result) {
            responseHandlers.handleDataResponse(result, onSuccess, onError);
        };

        postMessage.sendMessage(postMessage.MessageTypes.GET_BILLING_PACKAGES, namespace, args, onComplete);
    };

    var getProducts = function (options, onSuccess, onError) {
        sharedAPI.getProducts(namespace, options, onSuccess, onError);
    };

    return {
        /**
         * @enum
         * @memberof Wix.Billing
         * @since 1.37.0
         */
        Cycle: {
            MONTHLY: 'MONTHLY',
            YEARLY: 'YEARLY',
            ONE_TIME: 'ONE_TIME'
        },

        /**
         * Opens the Wix billing page in a new window with information about the product and cycle requested. This API is internal and works with the Upgrade button component found in the <a href="http://wix.github.io/wix-ui-lib/#Upgrade-entry" target="_blank">UI Lib.</a>
         *
         * @function
         * @memberof Wix.Billing
         * @author lior.shefer@wix.com
         * @since 1.37.0
         * @private
         * @param {String} vendorProductId The vendor product id associated with the initiated purchase.
         * @param {Wix.Billing.Cycle} cycle The billing cycle.
         * @param {Function} [onError] A callback error function. An error might be a result of a wrong cycle, missing cycle or bad vendor product Id.
         * missing cycle or bad productId.
         *
         * @example
         * Wix.Billing.openBillingPageForProduct('vendorProductId', Wix.Billing.Cycle.MONTHLY, function () {
         *      //handle error
         * });
         *
         */
        openBillingPageForProduct: openBillingPageForProduct,

        /**
         * Returns a link to Wix Billing page with information about the product and cycle requested.
         *
         * @function
         * @memberof Wix.Billing
         * @author lior.shefer@wix.com
         * @since 1.37.0
         * @private
         * @param {String} vendorProductId Vendor product id as detailed in the Features section of the Wix Developer App Registration <a href="http://dev.wix.com" target="_blank">dev.wix.com</a>
         * @param {Wix.Billing.Cycle} cycle The billing cycle.
         * @param {Function} onSuccess A callback function, returns a link the Wix billing page with information about the product and cycle requested.
         * @param {Function} [onError] A callback error function, Error is wrong cycle,
         * missing cycle or bad productId.
         *
         * @example
         * var onError = function () {
         *  //handle the error
         * };
         * Wix.Billing.getBillingPageForProduct('vendorProductId', Wix.Billing.Cycle.MONTHLY, function () {
         *      //handle return value i.e., //https://premium.wix.com/...
         * }, onError);
         *
         */
        getBillingPageForProduct: getBillingPageForProduct,

        /**
         * Returns an Array of objects containing product and pricing info. As is defined in the Features section of the Wix Developer App Registration <a href="http://dev.wix.com" target="_blank">dev.wix.com</a>
         *
         * @function
         * @memberof Wix.Billing
         * @author lior.shefer@wix.com
         * @since 1.37.0
         * @param {Array} [vendorProductIds] A list of vendor product ids (each representing a billing package), as detailed in the Features section of the Wix Developer App Registration <a href="http://dev.wix.com" target="_blank">dev.wix.com</a>
         * @param {Function} onSuccess A callback function to receive the product info.
         * @param {Function} [onError] A callback error function.
         *
         * @return {Array} Array of Objects containing the product info:
         *
         *  Name         | Type                 | Description
         * --------------|----------------------|------------
         * prices        | `Array`              | -
         * price         | `Object`             | Name           | Type      | Description
         * -             |  -                   | value          |`String`   | The product price.
         * -             |  -                   | currencyCode   |`String`   | The product payment currency code.
         * -             |  -                   | currencySymbol |`String`   | The product payment currency symbol.
         * -             |  -                   | cycle          |[Wix.Billing.Cycle](Wix.Billing.html#Cycle)  | The product payment cycle
         *
         * @example
         * var onError = function () {
         *  //handle the error
         * };
         * var onSuccess = function (data) {
         *  //handle onSuccess
         *  //sample data schema:
         *  [{
         *     id: <vendorProductId>,
         *     prices: [
         *     {
		 *       value : '3.99',
		 *       currencyCode: 'USD',
         *       currencySymbol: '&#36;',
         *       cycle: 'MONTHLY'
         *     }]
         *  }]
         *
         * };
         * Wix.Billing.getBillingPackages(onSuccess, onError);
         *
         */

        getBillingPackages: getBillingPackages,

        /**
         *  Returns an Array of objects containing product and pricing info.
         *
         * @function
         * @memberof Wix.Billing
         * @since 1.76.0
         * @param {Object} [options] An object that can contain a 'currency' parameter which defines the currency of the returned products
         * @param {Function} onSuccess A callback function to receive the products.
         * @param {Function} [onError] A callback error function.
         *
         * @example
         * var onError = function () {
         *  //handle the error
         * };
         * var onSuccess = function (data) {
         *  //handle onSuccess
         *  //sample data schema:
         *  [{
         *     "id": <vendorProductId>,
         *     "name": "App Premium Package",
         *     "price": "4.95",
         *     "is_active": true,
         *     "freeMonth": true,
         *     "currencyCode": "USD",
         *     "currencySymbol": "US$"
         *     "monthly": {
         *          "price": "4.95",
         *          "url": "https://premium.wix.com/wix/api/tpaPriceQuote?appInstanceId=aaa-bbb&appDefinitionId=aa-bb&paymentCycle=MONTHLY&vendorProductId=1234"
         *     },
         *     "yearly:: {
         *          "price": "3.97",
         *          "url": "https://premium.wix.com/wix/api/tpaPriceQuote?appInstanceId=aaa-bbb&appDefinitionId=aa-bb&paymentCycle=YEARLY&vendorProductId=1234"
         *     },
         *     "oneTime": {
         *          "price": "5.99",
         *          "url": "https://premium.wix.com/wix/api/tpaPriceQuote?appInstanceId=aaa-bbb&appDefinitionId=aa-bb&paymentCycle=ONE_TIME&vendorProductId=1234"
         *     },
         *     "bestSellingFeature": "",
         *      "discountPercent": 20
         *     ]
         *  }]
         *
         * };
         * Wix.Billing.getProducts({currency: 'USD'}, onSuccess, onError);
         */
        getProducts: getProducts
    };
});
