/**
 * This is the description for the Preview namespace.
 * @memberof Wix
 * @namespace Wix.Preview
 */
define(['privates/postMessage'], function (postMessage) {

    var openSettingsDialog = function (options, failure) {
        postMessage.sendMessage(postMessage.MessageTypes.OPEN_SETTINGS_DIALOG, 'Preview', options, failure);
    };

    return {
        /**
         * Available only from Preview.
         * Ends Preview and opens the Settings Dialog for a given component, potentially navigating the user to a different page in the editor.
         * When called with no options, uses the widget or page that called the function.
         * @memberof Wix.Preview
         * @since 1.45.0
         * @experimental
         * @function
         * @param {Object} [options] options may contain compId to open the settings panel for. If the provided component id is incorrect, the failure callback will be invoked.
         * @param {Function} [failure] The callback is invoked either when the user cancels opening the settings panel, or if the specified component information is incorrect.
         * @example
         * Wix.Preview.openSettingsDialog(
         *  {compId: 'comp-iey3wfy7'},
         *  function(error){
         *      console.log('Oh no!');
         *   }
         *  );
         */
        openSettingsDialog: openSettingsDialog
    };

});