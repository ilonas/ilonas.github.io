/**
 * @memberof Wix
 * @namespace Wix.Features
 */
define(['privates/utils', 'privates/reporter', 'privates/postMessage'], function(utils, reporter, postMessage) {
   'use strict';

    var Types = {
        PREVIEW_TO_SETTINGS: 'PREVIEW_TO_SETTINGS',
        ADD_COMPONENT: 'ADD_COMPONENT',
        RESIZE_COMPONENT: 'RESIZE_COMPONENT'
    };

    var namespace = 'Features';

    var isValidFeatureName = function(featureName) {
        return  featureName === Types.PREVIEW_TO_SETTINGS ||
                featureName === Types.ADD_COMPONENT ||
                featureName === Types.RESIZE_COMPONENT;
    };

    var isSupported = function(featureName, callback) {
        if (featureName) {
            if (utils.isFunction(featureName)) {
                reporter.reportSdkError('Mandatory argument - feature name must be supplied.');
                return;
            }
            if (!callback) {
                reporter.reportSdkError('Mandatory argument - callback must be supplied.');
                return;
            }
            if (!utils.isFunction(callback)) {
                reporter.reportSdkError('Mandatory argument - callback must be a function.');
                return;
            }
            if(!isValidFeatureName(featureName)) {
                reporter.reportSdkError('Mandatory argument - feature must be one of Wix.Features.Types.');
                return;
            }

            var featureData = {
                name: featureName
            };
            postMessage.sendMessage(postMessage.MessageTypes.IS_SUPPORTED, namespace, featureData, callback);

        } else {
            reporter.reportSdkError('Mandatory arguments - feature name and callback must be supplied.');
        }
    };

    return {
        /**
         * @enum
         * @memberof Wix.Features
         * @since 1.45.0
         */
        Types: {
            /**
             * See {@link Wix.Preview.openSettingsDialog}
             * @memberof Wix.Features.Types
             * @since 1.45.0
             */
            PREVIEW_TO_SETTINGS: Types.PREVIEW_TO_SETTINGS,

            /**
             * See {@link Wix.Settings.addComponent}
             * @memberof Wix.Features.Types
             * @see Wix.Settings.addComponent
             * @since 1.45.0
             */
            ADD_COMPONENT: Types.ADD_COMPONENT,

            /**
             * See {@link Wix.Settings.resizeComponent}
             * @memberof Wix.Features.Types
             * Wix.Settings.resizeComponent
             * @since 1.45.0
             */
            RESIZE_COMPONENT: Types.RESIZE_COMPONENT
        },

        /**
         * Returns true via callback if the feature whose name was given is available for use.
         * The feature name provided must be one of Wix.Features.Types.
         * @function
         * @memberof Wix.Features
         * @since 1.45.0
         * @param {Wix.Features.Types} feature name
         * @param {Function} callback
         */
        isSupported: isSupported
    };
});