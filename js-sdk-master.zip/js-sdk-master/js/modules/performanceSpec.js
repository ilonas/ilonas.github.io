define(['Performance', 'privates/reporter', 'privates/postMessage'],
    function (Performance, reporter, postMessage) {
        describe('Performance', function () {
            beforeEach(function () {
                spyOn(postMessage, 'sendMessage');
                spyOn(reporter, 'reportSdkError');
            });
            describe('applicationLoaded', function() {
                it('should send post message', function() {
                    Performance.applicationLoaded();

                    expect(postMessage.sendMessage).shouldHaveBeenCalledWith(postMessage.MessageTypes.APPLICATION_LOADED, 'Performance');
                });
            });

            describe('applicationLoadingStep', function() {
                it('should send post message', function() {
                    Performance.applicationLoadingStep(5, 'loading');

                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.APPLICATION_LOADED_STEP, 'Performance', {
                        stage: 'loading',
                        stageNum: 5
                    });
                });

                it('should send post message in case stageDescription is not given', function() {
                    Performance.applicationLoadingStep(5);

                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.APPLICATION_LOADED_STEP, 'Performance', {
                        stage: 'loading',
                        stageNum: undefined
                    });
                });

                it('should throw error in case no stage is not given', function() {
                    Performance.applicationLoadingStep();

                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - stageNumber - should be of type Number');
                });

                it('should throw error in case stage is of type string', function() {
                    Performance.applicationLoadingStep();

                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - stageNumber - should be of type Number');
                });

                it('should throw error in case stageDescription is of type number', function() {
                    Performance.applicationLoadingStep();

                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('stageDescription should be of type String');
                });
            });
        });
    });
