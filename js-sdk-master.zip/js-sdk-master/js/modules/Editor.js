/**
 * @memberof Wix
 * @namespace Wix.Editor
 */
define(['privates/sharedAPI'], function (sharedAPI) {

    var namespace = 'Editor';

    var isApplicationInstalled = function(appDefinitionId, callback) {
        sharedAPI.isApplicationInstalled(namespace, appDefinitionId, callback);
    };

    return {
        /**
         * Checks if at least one of the application components was added to the site
         *
         * @function
         * @memberOf Wix.Editor
         * @since 1.83.0
         * @param {string} appDefinitionId the id of the app
         * @param {function} callback called with the boolean result
         *   callback signature: function(isInstalled) {}
         * @example
         *
         * Wix.Editor.isApplicationInstalled(
         *          '1380b703-ce81-ff05-f115-39571d94dfcd',
         *          function(isInstalled){console.log(isInstalled)}
         * );
         */
        isApplicationInstalled
    };
});
