/**
 * A theme for a popup window.
 * @memberof Wix
 * @namespace Wix.Theme
 */
define([], function () {
    return {
        /**
         * Default theme is used for regular popup look & feel - border, shadow, close button.
         * @memberof Wix.Theme
         * @since 1.17.0
         */
        DEFAULT:'DEFAULT',

        /**
         * Bare theme is used for no decorations at all.
         * @memberof Wix.Theme
         * @since 1.17.0
         */
        BARE:'BARE'
    };
});