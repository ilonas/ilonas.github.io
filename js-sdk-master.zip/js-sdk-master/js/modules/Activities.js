/**
 * @memberof Wix
 * @namespace Wix.Activities
 */
define(['privates/postMessage', 'privates/responseHandlers', 'privates/sharedAPI', 'privates/reporter', 'privates/viewMode'], function (postMessage, responseHandlers, sharedAPI, reporter, viewMode) {

    var namespace = 'Activities';

    var postActivity = function(activity, onSuccess, onFailure) {
        if (viewMode.getViewMode() !== "site") {
            reporter.reportSdkError('Invalid view mode. This function cannot be called in editor/preview mode. Supported view mode is: [site]');
            return;
        }
        var args = {
            activity:activity
        };

        var onComplete = null;
        if (onSuccess || onFailure) {
            onComplete = function(result) {
                if(result.status && onSuccess) {
                    onSuccess(result.response);
                } else if (onFailure) {
                    onFailure(result.response);
                }
            };
        }
        postMessage.sendMessage(postMessage.MessageTypes.POST_ACTIVITY, namespace, args, onComplete);
    };

    var getActivities = function (onSuccess, onFailure, query) {
        if (typeof onSuccess !== 'function') {
            reporter.reportSdkError('Missing mandatory argument - onSuccess, must be a function');
            return;
        }

        if (typeof onFailure !== 'function') {
            reporter.reportSdkError('Missing mandatory argument - onFailure, must be a function');
            return;
        }

        var args = {
            query: query
        };

        var onComplete = function onComplete(response) {
            responseHandlers.handleCursorResponse(response, onSuccess, onFailure, postMessage.MessageTypes.GET_ACTIVITIES);
        };

        postMessage.sendMessage(postMessage.MessageTypes.GET_ACTIVITIES, namespace, args, onComplete);
    };

    var getActivityById = function (id, onSuccess, onFailure) {
        if (typeof id !== 'string') {
            reporter.reportSdkError('Missing mandatory argument - id, must be a string');
            return;
        }
        if (typeof onSuccess !== 'function') {
            reporter.reportSdkError('Missing mandatory argument - onSuccess, must be a function');
            return;
        }
        if (typeof onFailure !== 'function') {
            reporter.reportSdkError('Missing mandatory argument - onFailure, must be a function');
            return;
        }

        var args = {
            id: id
        };

        var onComplete = function onComplete(result) {
            responseHandlers.handleDataResponse(result, onSuccess, onFailure);
        };

        postMessage.sendMessage(postMessage.MessageTypes.GET_ACTIVITY_BY_ID, namespace, args, onComplete);
    };

    var getUserSessionToken = function (callback) {
        postMessage.sendMessage(postMessage.MessageTypes.GET_USER_SESSION, namespace, null, callback);
    };
    return {

        /**
         * A collection of ActivityType objects
         * @enum
         * @memberof Wix.Activities
         * @readonly
         * @since 1.25.0
         */
        Type: {
            /**
             * Indicates a contact form was filled out.
             * @constant
             */
            CONTACT_CONTACT_FORM: 'contact/contact-form',
            /**
             * indicates a subscription form was filled
             * @constant
             */
            SUBSCRIPTION_FORM: 'contact/subscription-form',
            /**
             * A schema for creating a contact
             * @constant
             */
            CONTACT_CREATE : 'contacts/create',
            /**
             * Indicates a conversion with a contact was completed.
             * @constant
             */
            CONVERSION_COMPLETE: 'conversion/complete',
            /**
             * indicates a download from the site
             * @constant
             */
            DOWNLOADS_DOWNLOADED : 'downloads/downloaded',
            /**
             * indicates an event has been created, updated
             * @constant
             */
            EVENTS_EVENT_UPDATE: 'events/event-update',
            /**
             * indicates an item was added to a cart through ecommerce
             * @constant
             */
            ECOMMERCE_CART_ADD: 'e_commerce/cart-add',
            /**
             * indicates an item was removed from the cart through ecommerce
             * @constant
             */
            ECOMMERCE_CART_REMOVE : 'e_commerce/cart-remove',
            /**
             * indicates a cart was checked out through ecommerce
             * @constant
             */
            ECOMMERCE_CART_CHECKOUT : 'e_commerce/cart-checkout',
            /**
             * indicates a cart has been abandoned through ecommerce
             * @constant
             */
            ECOMMERCE_CART_ABANDON : 'e_commerce/cart-abandon',
            /**
             * Indicates a purchase was made through ecommerce.
             * @constant
             */
            ECOMMERCE_PURCHASE: 'e_commerce/purchase',
            /**
             * Indicates a message was sent to a contact.
             * @constant
             */
            SEND_MESSAGE: 'messaging/send',
            /**
             * Indicates a contact liked an album of music.
             * @constant
             */
            ALBUM_FAN: 'music/album-fan',
            /**
             * Indicates a contact shared an album of music.
             * @constant
             */
            ALBUM_SHARE: 'music/album-share',
            /**
             * indicates a contact played an album to completion.
             * @constant
             */
             ALBUM_PLAYED : 'music/album-played',
            /**
             * Indicates a contact viewed the lyrics of a song.
             * @constant
             */
            TRACK_LYRICS: 'music/track-lyrics',
            /**
             * Indicates a contact begun to play a track.
             * @constant
             */
            TRACK_PLAY: 'music/track-play',
            /**
             * Indicates a contact played a track to completion.
             * @constant
             */
            TRACK_PLAYED: 'music/track-played',
            /**
             *  Indicates a contact shared a track.
             *  @constant
             */
            TRACK_SHARE: 'music/track-share',
            /**
             * Indicates a contact skipped a track.
             * @constant
             */
            TRACK_SKIP: 'music/track-skip',
            /**
             * indicates a hotel reservation has been made (but not yet confirmed)
             * @constant
             */
            HOTELS_RESERVATION: 'hotels/reservation',
            /**
             * Indicates a hotel reservation has been cancelled.
             * @constant
             */
            HOTELS_CANCEL: 'hotels/cancel',
            /**
             * Indicates a hotel reservation has been confirmed.
             * @constant
             */
            HOTELS_CONFIRMATION: 'hotels/confirmation',
            /**
             * Indicates a hotel purchase has been made.
             * @constant
             */
            HOTELS_PURCHASE: 'hotels/purchase',
            /**
             * Indicates a hotel purchase has failed.
             * @constant
             */
            HOTELS_PURCHASE_FAILED: 'hotels/purchase-failed',
            /**
             * indicates an appointment has been confirmed
             * @constant
             */
            SCHEDULER_CONFIRMATION: 'scheduler/confirmation',
            /**
             * indicates an appointment has been cancelled
             * @constant
             */
            SCHEDULER_CANCEL: 'scheduler/cancel',
            /**
             * Indicates an appointment has been scheduled.
             * @constant
             */
            SCHEDULER_APPOINTMENT: 'scheduler/appointment',
            /**
             * indicates a shipment was made
             * @constant
             */
            SHIPPING_SHIPPED: 'shipping/shipped',
            /**
             * indicates a shipment was delivered
             * @constant
             */
            SHIPPING_DELIVERED: 'shipping/delivered',
            /**
             * indicates a shipment status update
             * @constant
             */
            SHIPPING_STATUS_CHANGE: 'shipping/status-change',
            /**
             * indicates a comment was written on the site
             * @constant
             */
            SOCIAL_COMMENT: 'social/comment',
            /**
             * indicates an item was shared from the site
             * @constant
             */
            SOCIAL_SHARE_URL: 'social/share-url',
            /**
             * indicates a user is tracking activity on the site (Like, Follow, Subscribe, etc)
             * @constant
             */
            SOCIAL_TRACK: 'social/track',
            /**
             * Indicates a contact form was filled out.
             * @constant
             * @since 1.69.0
             */
            FORM_CONTACT_FORM: 'form/contact-form',
            /**
             * Indicates a subscription form was filled.
             * @constant
             * @since 1.69.0
             */
            FORM_SUBSCRIPTION_FORM: 'form/subscription-form',
            /**
             * Indicates a form was filled.
             * @constant
             * @since 1.69.0
             */
            FORM_FORM: 'form/form',
            /**
             * Indicates a chat message was sent to a contact..
             * @constant
             * @since 1.69.0
             */
            MESSAGE_IM: 'Messaging/im',

            /**
             * Indicates a new order placed in a restaurant
             * @constant
             * @since 1.77.0
             */
            RESTAURANTS_ORDER: 'restaurants/order',

            /**
             * Indicates a new RSVP to events created by Wix users
             * @constant
             * @since 1.77.0
             */
            EVENTS_RSVP: 'events/rsvp'

        },

        /**
         * @enum
         * @memberof Wix.Activities
         * @since 1.25.0
         */
        Error: {
            BAD_DATES: 'BAD_DATES',
            ACTIVITY_NOT_FOUND: 'ACTIVITY_NOT_FOUND',
            WRONG_PERMISSIONS: 'WRONG_PERMISSIONS'
        },

        /**
         * This method posts an Activity to the current site.  An Activity is an action performed by a site viewer on the installed site.
         * By reporting Activities, your application better integrates with the Wix ecosystem. Each Activity conforms to a specific schema predefined by Wix.
         * When the Activity is successfully created, the id of the activity will be returned. If schema validation fails, or other errors occur, an error will be returned.
         *
         *
         * @function
         * @memberof Wix.Activities
         * @since 1.25.0
         * @param {Object} activity An activity descriptor, must follow specific type/schema pattern:
         *  Name         | Type      | Description |||
         * --------------|-----------|------------
         * type          | `String`  | The Activity Type. [Wix.Activities.ActivityType](Wix.Activities.html#toc4) |||
         * info          | `Object`  | The Activity information, specified by the Activity type. |||
         * details       | `Object`  | Name               | Type      | Description
         * -             |  -        | additionalInfoUrl  |`String`   | URL for additional information about this Activity.
         * -             |  -        | summary            |`String`   | Additional information about this Activity.
         * contactUpdate | `Object`  | Additional Contact information relevant to this Activity. |||
         *
         * @param {Function} [onSuccess] Success callback function.
         * @param {Function} [onFailure] Failure callback function.
         *
         * @example
         * var activity = {
         *      type:Wix.Activities.Type.CONTACT_CONTACT_FORM,
         *      info:{"fields":[{"name":"email","value":"email@email.com"},{"name":"message","value":"messageValue"}]},
         *      details:{additionalInfoUrl:null, summary:"testing tpa contact form"},
         *      contactUpdate:{}
         * };
         *
         * Wix.Activities.postActivity(activity, onSuccess, onFailure);
         *
         */
        postActivity: postActivity,

        /**
         * Gets a list of all activities that have been performed by users on the current site, optionally bound by date ranges, activity types and scope (app/site).
         * The results are returned through a callback that delivers a WixDataCursor object, with the results being in descending order by date.
         * @function
         * @memberof Wix.Activities
         * @since 1.28.0
         * @param {Function} onSuccess A function that receives a WixDataCursor object.
         * @param {Function} onFailure A function that receives an error object in case of invalid input.
         * @param {Object} [query] An Object containing params to restrict our results.
         * @returns {WixDataCursor}
         * @example
         * var query = {
         *      from: < ISO 8601 timestamp>,
         *      until: < ISO 8601 timestamp>,
         *      scope: <'app' 'scope'>,
         *      activityTypes: [ 'type1', 'type2', ...]
         * };
         *
         * Wix.Activities.getActivities(onSuccess, onFailure, query);
         *
         */
        getActivities: getActivities,

        /**
         * Gets a specific Activity that occurred on the current site.
         * @function
         * @memberof Wix.Activities
         * @since 1.28.0
         * @param {String} id The id of the Activity to look up.
         * @param {Function} onSuccess Callback triggered when data about the Activity is returned from Wix.
         * @param {Function} onFailure Callback triggered if the data could not be returned successfully.
         * @returns {Activity}
         * @example
         *
         * Wix.Activities.getActivityById(id, onSuccess, onFailure)
         *
         */
        getActivityById: getActivityById,

        /**
         * Returns a session token which can be used to make AJAX calls to Wix RESTful API.
         * @function
         * @memberof Wix.Activities
         * @since 1.25.0
         * @param {Function} callback a callback function to receive the token.
         * @example
         *
         * Wix.Activities.getUserSessionToken(callback);
         *
         */
        getUserSessionToken: getUserSessionToken
    };
});


