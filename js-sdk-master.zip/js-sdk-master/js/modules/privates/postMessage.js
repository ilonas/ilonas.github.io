var urlUtils = require('privates/urlUtils');
var utils = require('privates/utils');
var Events = require('Events');
var reporter = require('privates/reporter');

var MessageTypes = {
    REFRESH_APP: 'refreshApp',
    APP_IS_ALIVE: 'appIsAlive',
    APP_STATE_CHANGED: 'appStateChanged',
    CLOSE_WINDOW: 'closeWindow',
    RESIZE_WINDOW: 'resizeWindow',
    SET_WINDOW_PLACEMENT: 'setWindowPlacement',
    GET_WINDOW_PLACEMENT: 'getWindowPlacement',
    OPEN_POPUP: 'openPopup',
    OPEN_MODAL: 'openModal',
    OPEN_MEDIA_DIALOG: 'openMediaDialog',
    OPEN_SITE_MEMBERS_SETTINGS_DIALOG: 'openSiteMembersSettingsDialog',
    OPEN_BILLING_PAGE: 'openBillingPage',
    SET_FULL_SCREEN_MOBILE: 'setFullScreenMobile',
    GET_SITE_PAGES: 'getSitePages',
    GET_SITE_MAP: 'getSiteMap',
    SET_PAGE_METADATA: 'setPageMetadata',
    GET_SITE_COLORS: 'getSiteColors',
    GET_USER_SESSION: 'getUserSession',
    NAVIGATE_TO_PAGE: 'navigateToPage',
    POST_MESSAGE: 'postMessage',
    HEIGHT_CHANGED: 'heightChanged',
    NAVIGATE_TO_STATE: 'navigateToState',
    SM_REQUEST_LOGIN: 'smRequestLogin',
    LOG_OUT_CURRENT_MEMBER: 'logOutCurrentMember',
    SM_CURRENT_MEMBER: 'smCurrentMember',
    SITE_INFO: 'siteInfo',
    BOUNDING_RECT_AND_OFFSETS: 'boundingRectAndOffsets',
    SCROLL_TO: 'scrollTo',
    SCROLL_BY: 'scrollBy',
    SET_STYLE_PARAM: 'setStyleParam',
    GET_STYLE_PARAMS: 'getStyleParams',
    REGISTER_EVENT_LISTENER: 'registerEventListener',
    REMOVE_EVENT_LISTENER: 'removeEventListener',
    PUBLISH: 'publish',
    GET_CONTACT_BY_ID: 'getContactById',
    GET_CONTACTS: 'getContacts',
    CREATE_CONTACT: 'createContact',
    GET_ACTIVITY_BY_ID: 'getActivityById',
    GET_ACTIVITIES: 'getActivities',
    POST_ACTIVITY: 'postActivity',
    NAVIGATE_TO_SECTION_PAGE: 'navigateToSectionPage',
    GET_CURRENT_PAGE_ID: 'getCurrentPageId',
    GET_DASHBOARD_APP_URL: 'getDashboardAppUrl',
    GET_EDITOR_URL: 'getEditorUrl',
    SETTINGS_OPEN_MODAL: 'settingsOpenModal',
    GET_SECTION_URL: 'getSectionUrl',
    OPEN_BILLING_PAGE_FOR_PRODUCT: 'openBillingPageForProduct',
    GET_BILLING_PAGE_FOR_PRODUCT: 'getBillingPageForProduct',
    GET_BILLING_PACKAGES: 'getBillingPackages',
    ADD_COMPONENT: 'addComponent',
    RESIZE_COMPONENT: 'resizeComponent',
    OPEN_SETTINGS_DIALOG: 'openSettingsDialog',
    IS_SUPPORTED: 'isSupported',
    SET_EXTERNAL_ID: 'setExternalId',
    GET_EXTERNAL_ID: 'getExternalId',
    NAVIGATE_TO_COMPONENT: 'navigateToComponent',
    GET_WIX_UPGRADE_URL: 'getWixUpgradeUrl',
    TRACK_APP_UPGRADE: 'trackAppUpgrade',
    RECONCILE_CONTACT: 'reconcileContact',
    GET_INSTALLED_INSTANCE: 'getInstalledInstance',
    GET_VIEW_MODE: 'getViewMode',
    REVALIDATE_SESSION: 'revalidateSession',
    SET_VALUE: 'setValue',
    GET_VALUE: 'getValue',
    REMOVE_VALUE: 'removeValue',
    GET_VALUES: 'getValues',
    OPEN_COLOR_PICKER: 'openColorPicker',
    OPEN_FONT_PICKER: 'openFontPicker',
    GET_CURRENT_PAGE_ANCHORS: 'getCurrentPageAnchors',
    NAVIGATE_TO_ANCHOR: 'navigateToAnchor',
    GET_COMPONENT_INFO: 'getComponentInfo',
    SHOW_DASHBOARD_HEADER: 'showHeader',
    HIDE_DASHBOARD_HEADER: 'hideHeader',
    STYLE_PARAMS_READY: 'stylesReady',
    GET_STYLE_ID: 'getStyleId',
    REPLACE_SECTION_STATE: 'replaceSectionState',
    GET_STYLE_PARAMS_BY_STYLE_ID: 'getStyleParamsByStyleId',
    SET_FULL_WIDTH: 'setFullWidth',
    IS_FULL_WIDTH: 'isFullWidth',
    GET_STYLE_BY_COMP_ID: 'getStyleByCompId',
    OPEN_REVIEW_INFO: 'openReviewInfo',
    TO_WIX_DATE: 'toWixDate',
    GET_COMP_ID: 'getCompId',
    GET_ORIG_COMP_ID: 'getOrigCompId',
    GET_WIDTH: 'getWidth',
    GET_LOCALE: 'getLocale',
    GET_CACHE_KILLER: 'getCacheKiller',
    GET_TARGET: 'getTarget',
    GET_INSTANCE_ID: 'getInstanceId',
    GET_SIGN_DATE: 'getSignDate',
    GET_UID: 'getUid',
    GET_PERMISSIONS: 'getPermissions',
    GET_IP_AND_PORT: 'getIpAndPort',
    GET_DEMO_MODE: 'getDemoMode',
    GET_DEVICE_TYPE: 'getDeviceType',
    GET_INSTANCE_VALUE: 'getInstanceValue',
    GET_SITE_OWNER_ID: 'getSiteOwnerId',
    GET_IMAGE_URL: 'getImageUrl',
    GET_RESIZED_IMAGE_URL: 'getResizedImageUrl',
    GET_AUDIO_URL: 'getAudioUrl',
    GET_DOCUMENT_URL: 'getDocumentUrl',
    GET_SWF_URL: 'getSwfUrl',
    GET_PREVIEW_SECURE_MUSIC_URL: 'getPreviewSecureMusicUrl',
    GET_VIEW_MODE_INTERNAL: 'getViewModeInternal',
    GET_STYLE_COLOR_BY_KEY: 'getStyleColorByKey',
    GET_COLOR_BY_REFERENCE: 'getColorByreference',
    GET_EDITOR_FONTS: 'getEditorFonts',
    SET_COLOR_PARAM: 'setColorParam',
    SET_NUMBER_PARAM: 'setNumberParam',
    SET_BOOLEAN_PARAM: 'setBooleanParam',
    GET_SITE_TEXT_PRESETS: 'getSiteTextPresets',
    GET_FONTS_SPRITE_URL: 'getFontsSpriteUrl',
    GET_STYLE_FONT_BY_KEY: 'getStyleFontByKey',
    GET_STYLE_FONT_BY_REFERENCE: 'getStyleFontByReference',
    SET_UI_LIB_PARAM_VALUE: 'setUILIBParamValue',
    SET_HELP_ARTICLE: 'setHelpArticle',
    GET_CT_TOKEN: 'getCtToken',
    REGISTER_CAMPAIGN_PIXEL: 'registerCampaignPixel',
    APP_ENGAGED: 'appEngaged',
    REPORT_CAMPAIGN_EVENT: 'reportCampaignEvent',
    GET_PRODUCTS: 'getProducts',
	GET_STATE_URL: 'getStateUrl',
    APPLICATION_LOADED: 'applicationLoaded',
    APPLICATION_LOADED_STEP: 'applicationLoadingStep',
    SUPER_APPS_OPEN_MEDIA_DIALOG: 'superAppsOpenMediaDialog',
    IS_COMPONENT_INSTALLED: 'isComponentInstalled',
    GET_SITE_VIEW_URL: 'getSiteViewUrl',
    OPEN_LINK_PANEL: 'openLinkPanel',
    NAVIGATE_TO: 'navigateTo',
    GET_ADS_ON_PAGE: 'getAdsOnPage',
    SET_MOBILE_ACTION_BAR_BUTTON: 'setMobileActionBarButton',
    ADD_APPLICATION: 'addApplication',
    IS_APPLICATION_INSTALLED: 'isApplicationInstalled'
};

var callId = 1;

var callbacks = {};

var compId, deviceType;

var EventsCallbacks = {};

var version;

var sendMessage = function (msgType, namespace, params, callback) {
    if (!msgType) {
        return;
    }
    if (params === null) {
        params = undefined;
    }
    var blob = getBlob(msgType, namespace, params, callback);

    var target = parent.postMessage ? parent : (parent.document.postMessage ? parent.document : undefined);
    if (target && typeof target !== "undefined") {
        target.postMessage(JSON.stringify(blob), "*");
    }
};

var init = function (_version) {
    // get our comp id
    version = _version;
    compId = urlUtils.getQueryParameter('compId') || '[UNKNOWN]';
    deviceType = urlUtils.getQueryParameter('deviceType') || 'desktop';
    addPostMessageCallback(receiver);
};

var addPostMessageCallback = function (callback) {
    window.addEventListener('message', callback, false);
};

var receiver = function (event) {
    if (!event || !event.data) {
        return;
    }

    var data = {};
    try {
        data = JSON.parse(event.data);
    } catch(e) {
        return;
    }

    switch(data.intent) {
        case 'TPA_RESPONSE':
            if (data.callId && callbacks[data.callId]) {
                callbacks[data.callId](data.res);
                delete callbacks[data.callId];
            }
            break;

        case 'addEventListener':
            callEventListeners(data);
            break;

        case 'UI_LIB_RESPONSE':
            if (data.callId && callbacks[data.callId]) {
                callbacks[data.callId](data.res);
            }
            break;
    }
};

var callEventListeners = function(data, typeOfCall) {
    if (EventsCallbacks[data.eventType]) {
        EventsCallbacks[data.eventType].forEach(function (callbackHandler) {
            callbackHandler.callback.call(this, data.params, typeOfCall);
        });
    }
};

var addEventListenerInternal = function (eventKey, namespace, callBack, skipValidation, params) {
    if (!skipValidation && (!eventKey || !Events.hasOwnProperty(eventKey))) {
        reporter.reportSdkError('Unsupported event name, ' + eventKey);
        return;
    }
    var id = getCallId();

    EventsCallbacks[eventKey] = EventsCallbacks[eventKey] || [];
    EventsCallbacks[eventKey].push({
        callback: callBack,
        id: id
    });

    //params can be used as override params for the event to add more functionality
    params = params || {};
    params.eventKey = eventKey;

    sendMessage(MessageTypes.REGISTER_EVENT_LISTENER, namespace, params, handleAddEventListenerResponse.bind(null, callBack));
    return id;
};

var handleAddEventListenerResponse = function (callback, event) {
    if(event.drain){
        event.data.forEach(function(data){
            callback(data);
        }, null);
    }
};

var getBlob = function (type, namespace, data = {}, onResponseCallback = function(){}) {
    if (!utils.isObject(data)) {
        reporter.reportSdkMsg('Expecting params to be of type Object, ' + typeof data + " given");
    }

    var blob = {
        intent: "TPA2",
        callId: getCallId(),
        type,
        compId,
        deviceType,
        namespace,
        version,
        data
    };

    if (onResponseCallback) {
        callbacks[blob.callId] = onResponseCallback;
    }

    return blob;
};

var getCallId = function() {
    return callId++;
};

var removeEventListenerInternal = function (eventName, namespace, callBackOrId, skipValidation) {
    if (!skipValidation && (!eventName || !Events.hasOwnProperty(eventName))) {
        reporter.reportSdkError('Unsupported event name, ' + eventName);
        return;
    }
    var i = -1;
    var eventCallbacks = EventsCallbacks[eventName];
    if(eventCallbacks){
        for(var y = 0; y < eventCallbacks.length; y++){
            if(eventCallbacks[y].callback === callBackOrId || eventCallbacks[y].id === callBackOrId){
                i = y;
                break;
            }
        }
        if(i !== -1){
            eventCallbacks.splice(i, 1);
        }
    }

    if(i >= 0 && eventCallbacks.length === 0) {
        sendMessage(MessageTypes.REMOVE_EVENT_LISTENER, namespace, {
            eventKey: eventName
        });
    }
};

module.exports = {
    init: init,
    sendMessage: sendMessage,
    MessageTypes: MessageTypes,
    getCallId: getCallId,
    addEventListenerInternal: addEventListenerInternal,
    removeEventListenerInternal: removeEventListenerInternal,
    callEventListeners: callEventListeners
};
