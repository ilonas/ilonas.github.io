define(['privates/postMessage', 'privates/utils', 'Events', 'privates/templateUtils'], function(postMessage, utils, Events, templateUtils) {

    var styles = {
        siteColors: null,
        siteTextPresets: null,
        style: null,
        fontsMeta: null,
        fontsSpriteUrl: null,
        mappedColors: null,
        mappedFonts: null
    };

    var getFirstOrFallbackStyleParamValue = function (match, p1, offset, fullString) {
        var optionsOrder = p1.trim().split(' ');
        for (var i = 0; i < optionsOrder.length; i++) {
            if (utils.isObject(styles.mappedFonts[optionsOrder[i]]) &&
                utils.isString(styles.mappedFonts[optionsOrder[i]].value)) {
                return styles.mappedFonts[optionsOrder[i]].value;
            }

            if (utils.isObject(styles.mappedColors[optionsOrder[i]]) &&
                utils.isString(styles.mappedColors[optionsOrder[i]].value)) {
                return styles.mappedColors[optionsOrder[i]].value;
            }

            if (typeof styles.mappedNumbers[optionsOrder[i]] !== 'undefined') {
                return styles.mappedNumbers[optionsOrder[i]];
            }

            if (utils.isObject(styles.siteTextPresets && styles.siteTextPresets[optionsOrder[i]]) &&
                utils.isString(styles.siteTextPresets[optionsOrder[i]].value)) {
                return styles.siteTextPresets[optionsOrder[i]].value;
            }

            if (i === (optionsOrder.length - 1)) {
                return optionsOrder[i];
            }
        }
        return p1;
    };


    var updateCache = function(style) {
        if (style.style && style.style.googleFontsCssUrl) {
            templateUtils.appendOrUpdateGoogleFontsLink(style.style.googleFontsCssUrl);
        }

        if (style.style && style.style.uploadFontFaces) {
            templateUtils.appendOrUpdateUploadedFontFaces(style.style.uploadFontFaces);
        }

        templateUtils.appendFontsLinks(style);
        mapSiteStyles(style);
    };

    var normalizeColorThemeName = function (styles) {
        for (var color in styles.colors) {
            if (styles.colors.hasOwnProperty(color) && styles.colors[color].hasOwnProperty('themeName')) {
                styles.colors[color].themeName = templateUtils.getColorReferenceByColorName(styles.colors[color].themeName);
            }
        }
        return styles;
    };

    var mapSiteStyleData = function(newStyle) {
        styles.mappedColors  = templateUtils.mapColors(styles.siteColors, newStyle.colors);
        styles.mappedFonts   = templateUtils.mapFonts(newStyle.fonts);
        styles.mappedNumbers = templateUtils.mapNumbers(newStyle.numbers);
        return styles;
    };

    var mapSiteStyles = function (appStyle) {
        styles.siteColors = appStyle.siteColors ? appStyle.siteColors : styles.siteColors;
        styles.siteTextPresets = appStyle.siteTextPresets ? appStyle.siteTextPresets : styles.siteTextPresets;
        styles.fontsMeta = (appStyle.fonts && appStyle.fonts.fontsMeta) ? appStyle.fonts.fontsMeta : styles.fontsMeta;
        styles.fontsSpriteUrl = (appStyle.fonts && appStyle.fonts.imageSpriteUrl) ? appStyle.fonts.imageSpriteUrl : styles.fontsSpriteUrl;
        styles.style = appStyle.style ? normalizeColorThemeName(appStyle.style) : normalizeColorThemeName(appStyle);
        return mapSiteStyleData(appStyle.style || appStyle);
    };

    var onThemeChange = function (style) {
        updateCache(style);
        postMessage.callEventListeners({
            params: styles.style,
            eventType: Events.STYLE_PARAMS_CHANGE
        }, 'internal');
    };

    var onStyleParamChange = function(style, typeOfCall) {
        if(typeOfCall !== 'internal') {
            updateCache(style);
        }
        templateUtils.evalWixStyleTemplates(getFirstOrFallbackStyleParamValue);
    };

    var init = function(onReady, style) {
        utils.onDocumentReady(function () {
            templateUtils.insertStyleReset();
            injectAccessiblityStyles(style.isVisualFocusEnabled);
            postMessage.addEventListenerInternal(Events.THEME_CHANGE, undefined, onThemeChange);
            postMessage.addEventListenerInternal(Events.STYLE_PARAMS_CHANGE, undefined, onStyleParamChange);
            onThemeChange(style);
            onReady(style);
        });
    };

    var injectAccessiblityStyles = function(isVisualFocusEnabled) {
        if (isVisualFocusEnabled === true) {
            var inlineA11YStyle = document.createElement('style');
            inlineA11YStyle.innerText = ':focus { box-shadow: inset 0 0 0 1px rgba(255,255,255,0.9), 0 0 1px 2px #3899EC; }';
            document.getElementsByTagName('head')[0].appendChild(inlineA11YStyle);
        }
    };

    return {
        init: init,
        onThemeChange: onThemeChange,
        onStyleParamChange: onStyleParamChange,
        updateStylesCache: updateCache,
        mapSiteStyles: mapSiteStyles,
        getFirstOrFallbackStyleParamValue: getFirstOrFallbackStyleParamValue,
        Cache: styles,
        normalizeColorThemeName: normalizeColorThemeName
    };
});
