define(['Error', 'WixDataCursor'], function (Error, WixDataCursor) {

    var getWixError = function (errorCode) {
        var wixErrorMessage = Error.WIX_ERROR;

        switch (errorCode) {
            case 404:
                wixErrorMessage = Error.NOT_FOUND;
                break;
            case 400:
                wixErrorMessage = Error.BAD_REQUEST;
                break;
            case 'INVALID_SCHEMA':
                wixErrorMessage = Error.INVALID_SCHEMA;
                break;
        }

        return wixErrorMessage;
    };

    var handleDataResponse = function (response, onSuccess, onFailure) {
        if (response.error) {
            var wixErrorMessage = this.getWixError(response.error.errorCode);
            if (onFailure) {
                onFailure(wixErrorMessage);
            }
        } else {
            onSuccess(response.data);
        }
    };

    var handleCursorResponse = function (response, onSuccess, onFailure, messageType, options) {
        if (!response.error) {
            var cursor = new WixDataCursor(messageType, response.data.results, response.data.total, response.data.pageSize);
            cursor.setNextCursor(response.data.nextCursor);
            cursor.setPreviousCursor(response.data.previousCursor);
            cursor.setOptions(options);
            onSuccess(cursor);
        } else {
            var wixErrorMessage = this.getWixError(response.error.errorCode);
            if (onFailure) {
                onFailure(wixErrorMessage);
            }
        }
    };

    return {
        getWixError: getWixError,
        handleDataResponse: handleDataResponse,
        handleCursorResponse: handleCursorResponse
    };
});