var reportSdkError = function (errorMessage) {
    var error = new TypeError('Wix SDK: ' + errorMessage);
    throw error.stack;
};

var reportSdkMsg = function(message) {
    log(new TypeError('Wix SDK: ' + message));
};

var log = function (text) {
    if (window.console && window.console.log) {
        window.console.log(text);
    }
};

module.exports = {
    reportSdkError: reportSdkError,
    reportSdkMsg: reportSdkMsg
};