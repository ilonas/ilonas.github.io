define(function () {
    'use strict';

    const isNull = val => (val === null);

    const isUndefined = val => (val === undefined);

    const isNotANumber = val => (isNaN(val) || val !== val); // see MDN polyfill for isNaN for (val !== val)

    const mapValues = (obj, func) => {
        let res = {};
        if (isObject(obj)) {
            Object.keys(obj).forEach(k => res[k] = func(obj[k]));
        }
        return res;
    };

    var isString = function (arg) {
        return typeof arg === "string";
    };

    var isFunction = function (arg) {
        return typeof arg === "function";
    };

    var isObject = function (arg) {
        return typeof arg === "object";
    };

    var isNumber = function (arg) {
        return Object.prototype.toString.call(arg) === '[object Number]';
    };

    var isPercentValue = function (value) {
        return Object.prototype.toString.call(value) === '[object String]' && /^[0-9]+%$/.test(value);
    };

    var has = function(obj, key) {
        return Boolean(obj) && isObject(obj) && hasOwnProperty.call(obj, key);
    };

    var isBoolean = function(obj) {
        return obj === true || obj === false || Object.prototype.toString.call(obj) === '[object Boolean]';
    };

    var isArray = function(value) {
        return Array.isArray(value);
    };

    var protocol = function() {
        return location.protocol;
    };

    var onDocumentReady = function (callback) {
        //from zepto src
        var readyRE = /complete|loaded|interactive/;
        if (readyRE.test(document.readyState) && document.body) {
            callback();
        } else {
            document.addEventListener('DOMContentLoaded', function(){ callback(); }, false);
        }
    };

    var shallowCloneObject = function (obj, ignoreKeys) {
        var newObj = {};
        for (var p in obj){
            if(obj.hasOwnProperty(p) && ignoreKeys.indexOf(p) === -1){
                newObj[p] = obj[p];
            }
        }
        return newObj;
    };

    const merge = (source, dest) => {
        Object.keys(dest).forEach(key => {
            if (!source[key] || !isObject(dest[key])) {
                source[key] = dest[key];
            } else {
                merge(source[key], dest[key]);
            }
        });
    };

    const pick = (obj, keys) => {
        const dest = {};
        keys.forEach(key => {
            let value = obj[key];
            if (value !== null && value !== undefined) {
                dest[key] = value;
            }
        });
        return dest;
    };

    return {
        isNull,
        isUndefined,
        isNaN: isNotANumber,
        isString,
        isFunction,
        isObject,
        isNumber,
        isPercentValue,
        isArray,
        has,
        isBoolean,
        protocol,
        onDocumentReady,
        shallowCloneObject,
        merge,
        pick,
        mapValues
    };
});
