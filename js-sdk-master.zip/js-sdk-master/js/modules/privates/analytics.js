define(['privates/utils', 'privates/reporter', 'privates/postMessage', 'privates/viewMode'], function (utils, reporter, postMessage, viewMode) {

    var PIXEL_TYPES = {
        FACEBOOK: 'FACEBOOK'
    };

    var EVENT_TYPES = {
        VIEW_CONTENT: {
            eventName: 'ViewContent',
            parameters: ['value', 'currency', 'content_name', 'content_type', 'content_ids'],
            requiredParameters: []
        },
        SEARCH: {
            eventName: 'Search',
            parameters: ['value', 'currency', 'content_category', 'content_ids', 'search_string'],
            requiredParameters: []
        },
        ADD_TO_CART: {
            eventName: 'AddToCart',
            parameters: ['value', 'currency', 'content_name', 'content_type', 'content_ids'],
            requiredParameters: []
        },
        ADD_TO_WISHLIST: {
            eventName: 'AddToWishlist',
            parameters: ['value', 'currency', 'content_name', 'content_category', 'content_ids'],
            requiredParameters: []
        },
        INITIATE_CHECKOUT: {
            eventName: 'InitiateCheckout',
            parameters: ['value', 'currency', 'content_name', 'content_category', 'content_ids', 'num_items'],
            requiredParameters: []
        },
        ADD_PAYMENT_INFO: {
            eventName: 'AddPaymentInfo',
            parameters: ['value', 'currency', 'content_category', 'content_ids'],
            requiredParameters: []
        },
        PURCHASE: {
            eventName: 'Purchase',
            parameters: ['value', 'currency', 'content_name', 'content_type', 'content_ids', 'num_items'],
            requiredParameters: ['value', 'currency']
        },
        LEAD: {
            eventName: 'Lead',
            parameters: ['value', 'currency', 'content_name', 'content_category'],
            requiredParameters: []
        },
        COMPLETE_REGISTRATION: {
            eventName: 'CompleteRegistration',
            parameters: ['value', 'currency', 'content_name', 'status'],
            requiredParameters: []
        },
        CUSTOM_EVENT: {
            eventName: 'CustomEvent',
            parameters: ['event','*'],
            requiredParameters: ['event']
        }
    };

    var registerCampaignPixel = function (namespace, pixelType, pixelId){
        if (viewMode.getViewMode() !== "site") {
            reporter.reportSdkError('Invalid view mode. This function cannot be called in editor/preview mode. Supported view mode is: [site]');
            return;
        }

        if (!utils.isString(pixelType) || !utils.has(PIXEL_TYPES, pixelType)) {
            reporter.reportSdkError('Missing mandatory argument - pixelType - should be one of Wix.Analytics.PIXEL_TYPES');
            return;
        }

        if (!utils.isString(pixelId) || !Number(pixelId) || pixelId === "") {
            reporter.reportSdkError('Missing mandatory argument - pixelId - should be of type String, composes only digits, non empty');
            return;
        }

        var args = {
            pixelId: pixelId,
            pixelType: pixelType
        };

        postMessage.sendMessage(postMessage.MessageTypes.REGISTER_CAMPAIGN_PIXEL, namespace, args);
    };

    var getEventInfo = function(eventName){
        for (var key in EVENT_TYPES){
            if (EVENT_TYPES.hasOwnProperty(key) && EVENT_TYPES[key].eventName === eventName){
                return EVENT_TYPES[key];
            }
        }
        return false;
    };

    var reportCampaignEvent = function(namespace, eventType, data){
        if (viewMode.getViewMode() !== "site") {
            reporter.reportSdkError('Invalid view mode. This function cannot be called in editor/preview mode. Supported view mode is: [site]');
            return;
        }

        if (!utils.isString(eventType) || !getEventInfo(eventType)) {
            reporter.reportSdkError('Missing mandatory argument - eventType - should be one of Wix.Analytics.PixelEventType[event].eventName');
            return;
        }

        var eventInfo = getEventInfo(eventType);
        var requiredParams = eventInfo.requiredParameters;

        for (var i = 0; i < requiredParams.length; i++){
            if (!utils.isObject(data) || !data[requiredParams[i]]){
                reporter.reportSdkError('Missing mandatory argument - ' + requiredParams[i] + ' - in data object');
                return;
            }
        }

        var args = data || {};
        args.eventName = eventType;

        postMessage.sendMessage(postMessage.MessageTypes.REPORT_CAMPAIGN_EVENT, namespace, args);
    };

    return {
        PIXEL_TYPES: PIXEL_TYPES,
        EVENT_TYPES: EVENT_TYPES,
        registerCampaignPixel: registerCampaignPixel,
        reportCampaignEvent: reportCampaignEvent
    };
});
