define(['Events', 'privates/viewMode', 'privates/postMessage', 'privates/urlUtils', 'privates/styles'], function (Events, viewMode, postMessage, urlUtils, styles) {

    var readyQ;

    var isReady = false;

    var version = "__VERSION_NUMBER__";

    var init = function (opts) {
        postMessage.init(getVersion());
        if (opts && opts.endpointType !== 'worker') {
            // report ready to Wix
            postMessage.sendMessage(postMessage.MessageTypes.APP_IS_ALIVE, undefined, {version: getVersion()}, styles.init.bind(null, setReady));
        }
        viewMode.init();
    };

    var getDecodedInstance = function () {
        var instanceStr = urlUtils.getQueryParameter("instance");
        var encodedInstance = instanceStr.substring(instanceStr.indexOf(".")+1);
        return JSON.parse(decodeBase64(encodedInstance));
    };

    var getInstanceValue = function (key) {
        var decodedInstance = getDecodedInstance();
        if (decodedInstance) {
            return decodedInstance[key] || null;
        }
        return null;
    };

    var decodeBase64 = function (str) {
        return atob(str);
    };

    var setReady = function (styles) {
        isReady = true;
        callReadyQ(styles);
        postMessage.sendMessage(postMessage.MessageTypes.STYLE_PARAMS_READY, undefined, {version: getVersion()});
    };

    var callReadyQ = function (styles) {
        if(isReady && readyQ){
            for(var i = 0;i < readyQ.length; i++){
                readyQ[i].call(null, styles);
            }
        }
    };

    var addToReadyQ = function(action){
        readyQ = readyQ || [];
        readyQ.push(action);
    };

    var getVersion = function () {

        if (version !== '__VERSION_NUMBER__') {
            return 'unknown';
        }

        return version;
    };

    return {
        init: init,
        addToReadyQ: addToReadyQ,
        getInstanceValue: getInstanceValue
    };
});