define(['privates/core', 'privates/utils'], function (core, utils) {

    'use strict';
    var WIX_STYLE_ATTRIBUTE = 'wix-style';
    var TPA_DEV_STYLES_PREFIX = 'style.';
    var PRIME_COLORS_REFERENCES = ['white/black', 'black/white', 'primery-1', 'primery-2', 'primery-3'];
    var NON_PRIME_COLORS_PREFIX = 'color-';

    var googleCssFonts = {
        link: null
    };
    var queryMap = null;
    var uploadedFontFaces;

    var insertStyleReset = function () {
        var styleResetElement = document.createElement('style');
        styleResetElement.setAttribute(WIX_STYLE_ATTRIBUTE, '');
        styleResetElement.textContent = ".Title{ {{Title}} } .Menu{ {{Menu}} } .Page-title{ {{Page-title}} } .Heading-XL{ {{Heading-XL}} } .Heading-L{ {{Heading-L}} } .Heading-M{ {{Heading-M}} } .Heading-S{ {{Heading-S}} } .Body-L{ {{Body-L}} } .Body-M{ {{Body-M}} } .Body-S{ {{Body-S}} } .Body-XS{ {{Body-XS}} } }";
        document.getElementsByTagName('head')[0].appendChild(styleResetElement);
    };

    var getColorReferenceByColorName = function (colorName){
        var editorIndex = Number(colorName.split('_').pop());
        if (editorIndex <= 5) {
            return PRIME_COLORS_REFERENCES[editorIndex-1];
        } else if(editorIndex > 10){
            return NON_PRIME_COLORS_PREFIX + (editorIndex - 10);
        }
    };

    var mapColors = function (siteColors, tpaColors) {
        var colorMap = {}, ref;
        for(var i = 0; i < siteColors.length; i++){
            ref = getColorReferenceByColorName(siteColors[i].name);
            siteColors[i].reference = ref;
            colorMap[ref] = siteColors[i];
        }
        for(var color in tpaColors){
            if(tpaColors.hasOwnProperty(color)){
                colorMap[TPA_DEV_STYLES_PREFIX + color] = tpaColors[color];
            }
        }
        return colorMap;
    };

    var mapFonts = function (fonts) {
        var mappedFonts = {};
        for (var font in fonts) {
            if (fonts.hasOwnProperty(font)) {
                mappedFonts['style.' + font] = fonts[font];
            }
        }
        return mappedFonts;
    };

    var mapNumbers = function (numbers) {
        var mappedNumbers = {};
        for (var number in numbers) {
            if (numbers.hasOwnProperty(number)) {
                mappedNumbers['style.' + number] = numbers[number];
            }
        }
        return mappedNumbers;
    };

    var getWixStyleElements = function () {
        var styles = [];
        [].forEach.apply(document.getElementsByTagName('style'), [function (style) {
            if (style.hasAttribute(WIX_STYLE_ATTRIBUTE)) {
                styles.push(style);
            }
        }]);
        return styles;
    };

    var getQueryParameter = function (parameterName) {
        if (!queryMap) {
            queryMap = {};
            var queryString = location.search.substring(1) || '';
            var queryArray = queryString.split('&');

            queryArray.forEach(function(element) {
                var parts = element.split('=');
                queryMap[parts[0]] = decodeURIComponent(parts[1]);
            });
        }
        return queryMap[parameterName] || null;
    };

    var evalTemplate = function (template, replaceCallback) {
        var mediaType = getQueryParameter("deviceType") || "desktop";
        template = applyWixMediaQuery(template, mediaType);
        return template.replace(/\{{2}([^}|^\{]*)\}{2}/gmi, replaceCallback);
    };

    var evalWixStyleTemplates = function (matchFunction) {
        getWixStyleElements().forEach(function (style) {
            style.originalTemplate = style.originalTemplate || style.textContent;
            style.textContent = evalTemplate(style.originalTemplate, matchFunction);
        });
    };

    var scheduleToRemoveOldGoogleFontsLink = function() {
        scheduleToRemoveElement(googleCssFonts.link);
    };

    var scheduleToRemoveElement = function(elm) {
        setTimeout(function(){
            if (elm.parentNode) {
                elm.parentNode.removeChild(elm);
            }
        }, 5000);
    };

    var appendOrUpdateGoogleFontsLink = function(url) {
        if (!url) {
            return;
        }
        if (googleCssFonts.link) {
            if (googleCssFonts.link.getAttribute('href') === url) {
                return;
            }
            scheduleToRemoveOldGoogleFontsLink();
        }
        googleCssFonts.link = appendStyleLinkToHead(url, 'wix-google-fonts');
    };

    var appendOrUpdateUploadedFontFaces = function(fontFaces) {
        if(!fontFaces) {
            return;
        }

        if(uploadedFontFaces) {
            if (uploadedFontFaces.textContent === fontFaces) {
                return;
            }

            scheduleToRemoveElement(uploadedFontFaces);
        }

        var styleFontFacesElement = document.createElement('style');
        styleFontFacesElement.setAttribute('type', 'text/css');
        styleFontFacesElement.textContent = fontFaces;
        uploadedFontFaces = styleFontFacesElement;
        document.getElementsByTagName('head')[0].appendChild(styleFontFacesElement);
    };

    var appendStyleLinkToHead = function(url, id) {
        var head = document.getElementsByTagName('head')[0];
        var link = document.createElement('link');
        link.setAttribute('type', 'text/css');
        link.setAttribute('rel', 'stylesheet');
        link.setAttribute('href', url);
        if (utils.isString(id)) {
            link.id = id;
        }
        head.appendChild(link);
        return link;
    };

    var appendFontsLinks = function(styles){
        var fonts = styles.fonts;
        if(!fonts) {
            return;
        }
        var links = document.getElementsByTagName('link');
        fonts.cssUrls = fonts.cssUrls || [];
        fonts.cssUrls.forEach(function(url) {
            for (var i = 0; i < links.length; i++) {
                if (links[i].getAttribute('href') === url){
                    return;
                }
            }
            appendStyleLinkToHead(url);
        });
    };

    var findEndOfMediaQueryIndex = function(startIndex, styleTpl){
        var memIndex = 0;
        var index = startIndex;
        var currentChar;
        for (; index < styleTpl.length; index++) {
            currentChar = styleTpl.charAt(index);
            if (currentChar === '{') {
                memIndex += 1;
            }
            if (currentChar === '}') {
                memIndex -= 1;
            }
            if (memIndex < 0) {
                index++;
                break;
            }
        }
        return index - 1;
    };

    var getStartOfMediaQueryIndex = function(match, offset){
        return offset + match.index + match[0].length;
    };

    var getNonMediaQueryTextLength = function(match, currentIndex) {
        return match.index - currentIndex;
    };

    var applyWixMediaQuery = function (cssText, currentMediaType) {
        var target = "";
        var currentIndex = 0;
        var mediaRegExp = /@media\s*\(\s*wix-device-type\s*:\s*(\w+)\s*\)\s*\{/m;
        var match;

        while (currentIndex < cssText.length) {
            match = cssText.substr(currentIndex).match(mediaRegExp);
            if (match) {

                target += cssText.substr(currentIndex, getNonMediaQueryTextLength(match, currentIndex));
                var mediaQueryContentStartIndex = getStartOfMediaQueryIndex(match, currentIndex);
                var mediaQueryCloseIndex = findEndOfMediaQueryIndex(mediaQueryContentStartIndex, cssText);

                if (match[1] === currentMediaType) {
                    var mediaQueryLength = mediaQueryCloseIndex - mediaQueryContentStartIndex;
                    target += '/*** wix-media - @media: (' + currentMediaType + ') ***/';
                    target += cssText.substr(mediaQueryContentStartIndex, mediaQueryLength);
                }

                currentIndex = mediaQueryCloseIndex + 1;
            } else {
                target += cssText.substr(currentIndex, cssText.length - currentIndex);
                break;
            }
        }

        return target;
    };

    return {
        googleCssFonts: googleCssFonts,
        applyWixMediaQuery: applyWixMediaQuery,
        evalTemplate: evalTemplate,
        getColorReferenceByColorName: getColorReferenceByColorName,
        mapColors: mapColors,
        mapFonts: mapFonts,
        mapNumbers: mapNumbers,
        getWixStyleElements: getWixStyleElements,
        insertStyleReset: insertStyleReset,
        evalWixStyleTemplates: evalWixStyleTemplates,
        appendFontsLinks: appendFontsLinks,
        appendOrUpdateGoogleFontsLink: appendOrUpdateGoogleFontsLink,
        appendOrUpdateUploadedFontFaces: appendOrUpdateUploadedFontFaces
    };
});
