define(['privates/utils', 'privates/reporter', 'privates/postMessage'], function (utils, reporter, postMessage) {

    var TPA_PUB_SUB_PREFIX = 'TPA_PUB_SUB_';


    var unsubscribe = function (namespace, eventName, callBackOrId) {
        postMessage.removeEventListenerInternal(TPA_PUB_SUB_PREFIX + eventName, namespace, callBackOrId, true);
    };

    var subscribe = function (namespace, eventName, callBack, receivePastEvents) {
        if (!utils.isString(eventName)) {
            reporter.reportSdkError('Missing mandatory argument - eventName, must be a string');
            return;
        }
        if (!utils.isFunction(callBack)) {
            reporter.reportSdkError('Missing mandatory argument - callBack, must be a function');
            return;
        }
        return postMessage.addEventListenerInternal(TPA_PUB_SUB_PREFIX + eventName, namespace, callBack, true, {
            receivePastEvents:receivePastEvents
        });
    };

    var publish = function (namespace, eventName, data, isPersistent) {
        if (!utils.isString(eventName)) {
            reporter.reportSdkError('Missing mandatory argument - eventName, must be a string');
            return;
        }
        postMessage.sendMessage(postMessage.MessageTypes.PUBLISH, namespace, {
            eventKey:  TPA_PUB_SUB_PREFIX + eventName,
            isPersistent: !!isPersistent || false,
            eventData: data || {}
        });
    };

    return {
        unsubscribe,
        subscribe,
        publish
    };
});