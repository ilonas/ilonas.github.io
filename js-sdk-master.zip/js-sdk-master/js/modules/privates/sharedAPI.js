define(['privates/utils', 'privates/postMessage', 'privates/reporter', 'privates/responseHandlers', 'privates/styles', 'privates/core', 'privates/viewMode', 'privates/urlUtils'], function (utils, postMessage, reporter, responseHandlers, styles, core, viewMode, urlUtils) {
    'use strict';

    var resizeComponent = function(options, namespace, onSuccess, onFailure) {
        if (!options || (!options.width && !options.height)) {
            reporter.reportSdkError('Mandatory arguments - width or height must be supplied');
            return;
        }

        var args = {};

        if (options.width) {
            args.width = options.width;
        }

        if (options.height) {
            args.height = options.height;
        }

        var callback = function (data) {
            if (data.onError) {
                if (onFailure) {
                    onFailure(data);
                }
            } else {
                if (onSuccess) {
                    onSuccess(data);
                }
            }
        };

        postMessage.sendMessage(postMessage.MessageTypes.RESIZE_COMPONENT, namespace, args, callback);
    };

    var validateParamsForOpenBillingPage = function (supportedPremiumIntents, options) {
        var args = {};
        if (utils.isObject(options)) {
            if (options.premiumIntent){
                if (!utils.isString(options.premiumIntent) || !utils.has(supportedPremiumIntents, options.premiumIntent)) {
                    reporter.reportSdkError('Unsupported premiumIntent - ' + options.premiumIntent + ' - should be one of Wix.Settings.PremiumIntent');
                    return;
                }
                args.premiumIntent = options.premiumIntent;
            }

            if (utils.isString(options.referrer)){
                args.referrer = options.referrer;
            }
        }
        return args;
    };

    var openMediaDialog = function (messageType, namespace, supportedMediaTypes, mediaType, multipleSelection, onSuccess, onCancel) {
        if (!utils.isString(mediaType) || !isValidMediaType(supportedMediaTypes, mediaType)) {
            reporter.reportSdkError('Missing mandatory argument - mediaType must be one of Wix.Settings.MediaType');
            return;
        }

        if (!utils.isBoolean(multipleSelection)) {
            reporter.reportSdkError('Missing mandatory argument - multipleSelection must be true or false');
            return;
        }

        if (!utils.isFunction(onSuccess)) {
            reporter.reportSdkError('Missing mandatory argument - onSuccess must be a function');
            return;
        }

        var callOnCancel = utils.isFunction(onCancel);

        var callback = function (data) {
            if (data.wasCancelled) {
                if (callOnCancel) {
                    onCancel(data);
                }
            } else {
                onSuccess(data);
            }
        };

        var args = {
            mediaType: mediaType,
            multiSelection: multipleSelection,
            callOnCancel: callOnCancel
        };

        postMessage.sendMessage(messageType, namespace, args, callback);
    };

    var openModal = function (namespace, url, width, height, title, onClose, bareUI, options) {
        if (!url || !width || !height) {
            reporter.reportSdkError('Mandatory arguments - url & width & height must be specified');
            return;
        }
        if(!utils.isString(url)) {
            reporter.reportSdkError('Invalid argument - a Url must be of type string');
            return;
        }
        if(!utils.isNumber(width) && !utils.isPercentValue(width)) {
            reporter.reportSdkError('Invalid argument - a width must be of type Number or Percentage');
            return;
        }
        if(!utils.isNumber(height) && !utils.isPercentValue(height)) {
            reporter.reportSdkError('Invalid argument - a height must be of type Number or Percentage');
            return;
        }

        var args = {
            url   : url,
            width : width,
            height: height,
            isBareMode: bareUI,
            options: options
        };

        if (utils.isFunction(title)) {
            onClose = title;
        } else {
            args.title = title;
        }

        postMessage.sendMessage(postMessage.MessageTypes.SETTINGS_OPEN_MODAL, namespace, args, onClose);
    };

    var isValidMediaType = function (MediaType, value) {
        for(var key in MediaType) {
            if (MediaType[key] === value) {
                return true;
            }
        }
        return false;
    };

    var revalidateSession = function(namespace, onSuccess, onError) {
        if (onSuccess) {
            if(utils.isFunction(onSuccess)) {
                var callback = function (response) {
                    if (response && response.onError) {
                        var wixErrorMessage = responseHandlers.getWixError(response.error.errorCode);
                        if (onError) {
                            onError.call(this, wixErrorMessage);
                        }
                    } else {
                        onSuccess.apply(this, arguments);
                    }
                };
                postMessage.sendMessage(postMessage.MessageTypes.REVALIDATE_SESSION, namespace, {}, callback);
            } else {
                reporter.reportSdkError('Mandatory argument - onSuccess - should be of type Function');
            }
        } else {
            reporter.reportSdkError('Missing Mandatory argument - onSuccess');
        }
    };

    var getCurrentPageAnchors = function(namespace, callback){
        if (!callback || !utils.isFunction(callback)) {
            reporter.reportSdkError('Mandatory arguments - a callback function must be specified');
            return;
        }

        postMessage.sendMessage(postMessage.MessageTypes.GET_CURRENT_PAGE_ANCHORS, namespace, {}, callback);
    };

    var getProductsImpl = function (namespace, options, onSuccess, onError) {
        if (!utils.isObject(options)) {
            reporter.reportSdkError('Missing mandatory argument - options must be an object');
            return;
        }
        if (options && options.currency && !utils.isString(options.currency)) {
            reporter.reportSdkError('Invalid argument - currency must be of type string');
            return;
        }
        if (!utils.isFunction(onSuccess)) {
            reporter.reportSdkError('Missing mandatory argument - onSuccess must be a function');
            return;
        }
        if (onError && !utils.isFunction(onError)) {
            reporter.reportSdkError('Invalid argument - onError must be a function');
            return;
        }

        var callback = function (data) {
            if (data && data.error) {
                if (onError) {
                    onError(data);
                }
            } else {
                if (onSuccess) {
                    onSuccess(data);
                }
            }
        };

        var args = {};
        if (options.appDefinitionId) {
            args.appDefinitionId = options.appDefinitionId;
        }
        if (options.currency) {
            args.currency = options.currency;
        }
        postMessage.sendMessage(postMessage.MessageTypes.GET_PRODUCTS, namespace, args, callback);
    };

    var getProducts = function (namespace, options, onSuccess, onError) {
        if (utils.isObject(options)) {
            getProductsImpl(namespace, options, onSuccess, onError);
        } else if (utils.isFunction(options)) {
            getProductsImpl(namespace, {}, options, onSuccess);
        } else {
            reporter.reportSdkError('Invalid argument - first parameter must be an object or a function');
        }
    };

    var getSiteInfo = function(namespace, onSuccess) {
        postMessage.sendMessage(postMessage.MessageTypes.SITE_INFO, namespace, null, onSuccess);
    };

    var closeWindow = function (namespace, message) {
        postMessage.sendMessage(postMessage.MessageTypes.CLOSE_WINDOW, namespace, {message : message});
    };

    var getViewMode = function(namespace) {
        postMessage.sendMessage(postMessage.MessageTypes.GET_VIEW_MODE_INTERNAL, namespace);
        return viewMode.getViewMode();
    };

    var getStyle = function (callback, key) {
        if(styles.Cache[key] && callback){
            callback(styles.Cache[key]);
        } else {
            core.addToReadyQ(function(){
                if (callback) {
                    callback(styles.Cache[key]);
                }
            });
        }
        return styles.Cache[key];
    };

    var getStyleParams = function (callback) {
        return getStyle(callback, 'style');
    };

    var getStyleColorByKey = function (colorKey) {
        var color = styles.Cache.mappedColors && styles.Cache.mappedColors['style.' + colorKey];
        return color ? color.value : '';
    };

    var getColorByreference = function (colorReference) {
        var color = styles.Cache.mappedColors && styles.Cache.mappedColors[colorReference];
        color = utils.shallowCloneObject(color, ['name']);
        return color;
    };

    var EDITOR_PARAM_TYPES = ['color', 'number', 'boolean', 'font'];

    var setEditorParam = function(namespace, type, key, value, onSuccess, onError){
        if(EDITOR_PARAM_TYPES.indexOf(type) === -1){
            reporter.reportSdkError('Invalid editor param type: "' + type + '"');
        }
        if(!key){
            reporter.reportSdkError('Invalid key name');
        }

        var callback = function (data) {
            if (data && data.onError) {
                if (onError) {
                    onError.apply(this, arguments);
                }
            } else {
                if (onSuccess) {
                    onSuccess.apply(this, arguments);
                }
            }
        };

        postMessage.sendMessage(postMessage.MessageTypes.SET_STYLE_PARAM, namespace, {
            type: type,
            key: key,
            param: value
        }, callback);
    };

    var setColorParam = function (namespace, key, value, onSuccess, onError){
        if(value.hasOwnProperty('reference') && value.reference){
            value.color = getColorByreference(value.reference);
        }
        setEditorParam(namespace, 'color', key, value, onSuccess, onError);
    };

    var getSitePages = function (namespace, options, callback) {
        var args = {};

        if(utils.isFunction(options)) {
            callback = options;
        } else if (options) {
            if(utils.isObject(options)) {
                if (options.includePagesUrl) {
                    if (utils.isBoolean(options.includePagesUrl)) {
                        args.includePagesUrl = options.includePagesUrl;
                    } else {
                        reporter.reportSdkError('Invalid argument - includePagesUrl should be of type boolean');
                        return;
                    }
                }
            } else {
                reporter.reportSdkError('Invalid argument - options should be of type Object');
                return;
            }


            if (callback && !utils.isFunction(callback)) {
                reporter.reportSdkError('Invalid argument - callback should be of type Function');
                return;
            }
        }

        postMessage.sendMessage(postMessage.MessageTypes.GET_SITE_PAGES, namespace, args, callback);
    };

    var getSiteMap = function (namespace, callback) {
        if (!utils.isFunction(callback)) {
            reporter.reportSdkError('Missing mandatory argument - callback must be a function');
            return;
        }

        postMessage.sendMessage(postMessage.MessageTypes.GET_SITE_MAP, namespace, {}, callback);
    };

    var currentMember = function (namespace, onSuccess) {
        if (getViewMode() !== "site") {
            reporter.reportSdkError('Invalid view mode. This function cannot be called in editor/preview mode. Supported view mode is: [site]');
            return;
        }
        postMessage.sendMessage(postMessage.MessageTypes.SM_CURRENT_MEMBER, namespace, null, onSuccess);
    };

    var getDeviceType = function (namespace) {
        postMessage.sendMessage(postMessage.MessageTypes.GET_DEVICE_TYPE, namespace);
        return urlUtils.getQueryParameter("deviceType") || "desktop";
    };

    var getLocale = function (namespace) {
        postMessage.sendMessage(postMessage.MessageTypes.GET_WIDTH, namespace);
        return urlUtils.getQueryParameter("locale");
    };

    var getInstanceId = function (namespace) {
        postMessage.sendMessage(postMessage.MessageTypes.GET_INSTANCE_ID, namespace);
        return core.getInstanceValue("instanceId");
    };

    var getIpAndPort = function (namespace) {
        postMessage.sendMessage(postMessage.MessageTypes.GET_IP_AND_PORT, namespace);
        return core.getInstanceValue("ipAndPort");
    };

    var navigateToSection = function(namespace, sectionIdentifier, state, onFailure) {
        var args;
        if(utils.isFunction(sectionIdentifier)) {
            onFailure = sectionIdentifier;
        }
        else if(utils.isString(sectionIdentifier)) {
            args = {
                state: sectionIdentifier
            };
            onFailure = state;
        } else if(utils.isObject(sectionIdentifier) && utils.isFunction(state)) {
            args = {
                sectionIdentifier: sectionIdentifier
            };
            onFailure = state;
        } else {
            args = {
                sectionIdentifier: sectionIdentifier,
                state: state
            };
        }

        postMessage.sendMessage(postMessage.MessageTypes.NAVIGATE_TO_SECTION_PAGE, namespace, args, onFailure);
    };

    var getStateUrl = function(namespace, sectionId, state, callback) {
        if (!utils.isString(sectionId)) {
            reporter.reportSdkError('Missing mandatory argument - sectionId - should be of type String');
            return;
        }
        if (!utils.isString(state)) {
            reporter.reportSdkError('Missing mandatory argument - state - should be of type String');
            return;
        }
        if (!utils.isFunction(callback)) {
            reporter.reportSdkError('Missing mandatory argument - callback - should be of type Function');
        }
        postMessage.sendMessage(postMessage.MessageTypes.GET_STATE_URL, namespace, {sectionId, state}, callback);
    };

    var addApplicationImpl = function(namespace, appDefinitionId, options, onSuccess, onError) {
        if (!utils.isString(appDefinitionId)) {
            reporter.reportSdkError('Missing mandatory argument - appDefinitionId - should be of type String');
            return;
        }
        if (options && !utils.isObject(options)) {
            reporter.reportSdkError('Invalid argument - options - should be of type Object');
            return;
        }
        if (onSuccess && !utils.isFunction(onSuccess)) {
            reporter.reportSdkError('Invalid argument - onSuccess - should be of type Function');
            return;
        }
        if (onError && !utils.isFunction(onError)) {
            reporter.reportSdkError('Invalid argument - onError - should be of type Function');
            return;
        }

        var args = {
            appDefinitionId: appDefinitionId
        };
        if (options.pageId) {
            args.pageId = options.pageId;
        }
        if (options.shouldNavigate){
            args.shouldNavigate = options.shouldNavigate;
        }
        if (options.showPageAddedPanel) {
            args.showPageAddedPanel = options.showPageAddedPanel;
        }

        var callback = function (data) {
            if (data && data.error) {
                if (onError) {
                    onError.apply(this, arguments);
                }
            } else {
                if (onSuccess) {
                    onSuccess.apply(this, arguments);
                }
            }
        };
        postMessage.sendMessage(postMessage.MessageTypes.ADD_APPLICATION, namespace, args, callback);
    };

    var addApplication = function(namespace, appDefinitionId, options, onSuccess, onError) {
        if (viewMode.getViewMode() !== "editor") {
            reporter.reportSdkError('Invalid view mode. This function can be called only in editor mode.');
            return;
        }
        if (utils.isObject(options)) {
            addApplicationImpl(namespace, appDefinitionId, options, onSuccess, onError);
        } else if (utils.isFunction(options)) {
            addApplicationImpl(namespace, appDefinitionId, {}, options, onSuccess);
        } else if (options) {
            reporter.reportSdkError('Invalid argument - second argument should be of type Object or Function');
        } else {
            addApplicationImpl(namespace, appDefinitionId, {});
        }
    };

    var isApplicationInstalled = function(namespace, appDefinitionId, callback) {
        if (viewMode.getViewMode() !== "editor") {
            reporter.reportSdkError('Invalid view mode. This function can be called only in editor mode.');
            return;
        }
        if (!utils.isString(appDefinitionId)) {
            reporter.reportSdkError('Missing mandatory argument - appDefinitionId - should be of type String');
            return;
        }
        if (!utils.isFunction(callback)) {
            reporter.reportSdkError('Missing mandatory argument - callback - should be of type Function');
            return;
        }

        var args = {
            appDefinitionId: appDefinitionId
        };
        postMessage.sendMessage(postMessage.MessageTypes.IS_APPLICATION_INSTALLED, namespace, args, callback);
    };

    return {
        resizeComponent,
        validateParamsForOpenBillingPage,
        openMediaDialog,
        revalidateSession,
        getCurrentPageAnchors,
        openModal,
        getSiteInfo,
        closeWindow,
        getStyle,
        getStyleParams,
        getStyleColorByKey,
        getColorByreference,
        setEditorParam,
        setColorParam,
        getViewMode,
        getSitePages,
        getSiteMap,
        currentMember,
        getDeviceType,
        getLocale,
        getInstanceId,
        getIpAndPort,
        navigateToSection,
        getProducts,
		getStateUrl,
        addApplication,
        isApplicationInstalled
	};
});
