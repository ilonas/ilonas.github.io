define(['privates/utils', 'privates/postMessage', 'privates/reporter', 'privates/viewMode'], function(utils, postMessage, reporter, viewMode) {

    var SCOPE = {
        // Data set with scope = APP are accessible across all components
        APP: 'APP',

        // Data set with scope = COMPONENT are accessible across all components
        COMPONENT: 'COMPONENT'
    };

    var parseAndReturnArgs = function(options, onSuccess, onFailure) {
        var scope = SCOPE.COMPONENT;

        if (options) {
            if(utils.isObject(options) && options.scope && (options.scope === SCOPE.APP || options.scope === SCOPE.COMPONENT)) {
                scope = options.scope;
            } else if (utils.isFunction(options)) {
                onFailure = onSuccess;
                onSuccess = options;
            } else {
                reporter.reportSdkError('Invalid argument - options should be of type object, containing scope of type Wix.Data.SCOPE');
                return undefined;
            }
        }

        if (onSuccess && !utils.isFunction(onSuccess)){
            reporter.reportSdkError('Invalid argument - onSuccess - should be a function');
            return undefined;
        }

        var onComplete = function onComplete(result) {
            handleDataResponse(result, onSuccess, onFailure);
        };

        return {
            scope: scope,
            onComplete: onComplete
        };
    };


    var handleDataResponse = function (data, onSuccess, onFailure) {
        if (data && data.error) {
            if (onFailure) {
                onFailure(data);
            }
        } else {
            if (onSuccess) {
                onSuccess(data);
            }
        }
    };

    var getMulti = function(namespace, keys, options, onSuccess, onFailure) {
        if (!utils.isArray(keys)) {
            reporter.reportSdkError('Mandatory argument - keys - should be of type Array');
            return;
        }

        var args = parseAndReturnArgs(options, onSuccess, onFailure);

        if (args) {
            postMessage.sendMessage(postMessage.MessageTypes.GET_VALUES, namespace, {
                keys: keys,
                scope: args.scope
            }, args.onComplete);
        }
    };

    var set = function(namespace, key, value, options, onSuccess, onFailure) {
        if (viewMode.getViewMode() !== "editor") {
            reporter.reportSdkError('Invalid view mode. This function can be called only in editor mode.');
            return;
        }

        if (!utils.isString(key)) {
            reporter.reportSdkError('Mandatory argument - key - should be of type String');
            return;
        } else if (!(utils.isString(value) || utils.isBoolean(value) || utils.isNumber(value) || utils.isObject(value))) {
            reporter.reportSdkError('Mandatory argument - value - should be of type String, Number, Boolean or Json');
            return;
        }

        var args = parseAndReturnArgs(options, onSuccess, onFailure);

        if (args) {
            postMessage.sendMessage(postMessage.MessageTypes.SET_VALUE, namespace, {
                key: key,
                value: value,
                scope: args.scope
            }, args.onComplete);
        }
    };

    var get = function(namespace, key, options, onSuccess, onFailure) {
        if (!utils.isString(key)) {
            reporter.reportSdkError('Mandatory argument - key - should be of type String');
            return;
        }

        var args = parseAndReturnArgs(options, onSuccess, onFailure);

        if (args) {
            postMessage.sendMessage(postMessage.MessageTypes.GET_VALUE, namespace, {
                key: key,
                scope: args.scope
            }, args.onComplete);
        }
    };

    var remove = function(namespace, key, options, onSuccess, onFailure) {
        if (viewMode.getViewMode() !== "editor") {
            reporter.reportSdkError('Invalid view mode. This function can be called only in editor mode.');
            return;
        }

        if (!utils.isString(key)) {
            reporter.reportSdkError('Mandatory argument - key - should be of type String');
            return;
        }

        var args = parseAndReturnArgs(options, onSuccess, onFailure);

        if (args) {
            postMessage.sendMessage(postMessage.MessageTypes.REMOVE_VALUE, namespace, {
                key: key,
                scope: args.scope
            }, args.onComplete);
        }
    };

    return {
        SCOPE: SCOPE,

        set,
        get,
        remove,
        getMulti
    };

});
