define(['privates/postMessage', 'privates/utils', 'privates/reporter'], function (postMessage, utils, reporter) {

    var applicationLoaded = function(namespace) {
        postMessage.sendMessage(postMessage.MessageTypes.APPLICATION_LOADED, namespace);
    };

    var applicationLoadingStep = function (namespace, stageNumber, stageDescription) {
        if (!utils.isNumber(stageNumber)) {
            reporter.reportSdkError('Missing mandatory argument - stageNumber - should be of type Number');
            return;
        }

        if (stageDescription && !utils.isString(stageDescription)) {
            reporter.reportSdkError('stageDescription should be of type String');
            return;
        }

        var args = {
            stage: stageDescription,
            stageNum: stageNumber
        };
        postMessage.sendMessage(postMessage.MessageTypes.APPLICATION_LOADED_STEP, namespace, args);
    };

    return {

        applicationLoaded: applicationLoaded,

        applicationLoadingStep: applicationLoadingStep
    };
});
