var _ = require('lodash');
var sharedAPI = require('privates/sharedAPI');
var postMessage = require('privates/postMessage');
var reporter = require('privates/reporter');
var Settings = require('Settings');
var viewMode = require('privates/viewMode');

var namespace = 'namespace';
describe('openMediaDialog', function () {
    beforeEach(function () {
        spyOn(reporter, 'reportSdkError');
        spyOn(postMessage, 'sendMessage');
    });

    it('should report error when media type was not provided', function () {
        sharedAPI.openMediaDialog();

        expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - mediaType must be one of Wix.Settings.MediaType');
        expect(postMessage.sendMessage).not.toHaveBeenCalled();
    });

    it('should report error when a valid media type was not provided', function () {
        sharedAPI.openMediaDialog('foo');

        expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - mediaType must be one of Wix.Settings.MediaType');
        expect(postMessage.sendMessage).not.toHaveBeenCalled();
    });

    it('should report error when on multipleSelection was not provided', function () {
        sharedAPI.openMediaDialog(undefined, namespace, Settings.MediaType, Settings.MediaType.IMAGE);

        expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - multipleSelection must be true or false');
        expect(postMessage.sendMessage).not.toHaveBeenCalled();
    });

    it('should report error when a valid multipleSelection was not provided', function () {
        sharedAPI.openMediaDialog(undefined, namespace, Settings.MediaType, Settings.MediaType.AUDIO, undefined);

        expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - multipleSelection must be true or false');
        expect(postMessage.sendMessage).not.toHaveBeenCalled();
    });

    it('should send proper message when API parameters are valid', function () {
        var args = {
            mediaType: Settings.MediaType.AUDIO,
            multiSelection: false,
            callOnCancel: false
        };

        sharedAPI.openMediaDialog('open media dialog method', namespace, Settings.MediaType, Settings.MediaType.AUDIO, false, function(){});

        expect(reporter.reportSdkError).not.toHaveBeenCalled();
        expect(postMessage.sendMessage).toHaveBeenCalledWith(jasmine.any(String), namespace, args, jasmine.any(Function));
    });

    it('should send proper message when API parameters are valid and onCancel was given', function () {
        var args = {
            mediaType: Settings.MediaType.AUDIO,
            multiSelection: false,
            callOnCancel: true
        };

        sharedAPI.openMediaDialog('', namespace, Settings.MediaType, Settings.MediaType.AUDIO, false, function(){}, function(){});

        expect(reporter.reportSdkError).not.toHaveBeenCalled();
        expect(postMessage.sendMessage).toHaveBeenCalledWith(jasmine.any(String), namespace, args, jasmine.any(Function));
    });

    it('should send proper message when API parameters are valid and onCancel was given', function () {
        var args = {
            mediaType: Settings.MediaType.SECURE_MUSIC,
            multiSelection: false,
            callOnCancel: true
        };

        sharedAPI.openMediaDialog(postMessage.MessageTypes.OPEN_MEDIA_DIALOG, namespace, Settings.MediaType, Settings.MediaType.SECURE_MUSIC, false, function(){}, function(){});

        expect(reporter.reportSdkError).not.toHaveBeenCalled();
        expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.OPEN_MEDIA_DIALOG, namespace, args, jasmine.any(Function));
    });

    it('should invoke the onCancel callback of it was given and wasCanceled was returned', function () {
        postMessage.sendMessage.and.callFake(function (m, n, args , callback) {
            return callback({
                wasCancelled: true
            });
        });

        var args = {
            mediaType: Settings.MediaType.SECURE_MUSIC,
            multiSelection: false,
            callOnCancel: true
        };

        var error = jasmine.createSpy();
        var success = jasmine.createSpy();

        sharedAPI.openMediaDialog(postMessage.MessageTypes.OPEN_MEDIA_DIALOG, namespace, Settings.MediaType, Settings.MediaType.SECURE_MUSIC, false, success, error);

        expect(reporter.reportSdkError).not.toHaveBeenCalled();
        expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.OPEN_MEDIA_DIALOG, namespace, args, jasmine.any(Function));
        expect(error).toHaveBeenCalledWith({
            wasCancelled: true
        });
    });
});

describe('openModal', () => {
    let callback;
    beforeEach(function () {
        spyOn(reporter, 'reportSdkError');
        spyOn(postMessage, 'sendMessage');
        callback = _.noop;
    });

    it('should report error when url is not provided', () =>  {
        sharedAPI.openModal(namespace);

        expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory arguments - url & width & height must be specified');
        expect(postMessage.sendMessage).not.toHaveBeenCalledWith(postMessage.MessageTypes.SETTINGS_OPEN_MODAL, 'namespace', {}, undefined);
    });

    it('should report error when width is not provided', () =>  {
        sharedAPI.openModal(namespace, '');

        expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory arguments - url & width & height must be specified');
        expect(postMessage.sendMessage).not.toHaveBeenCalledWith(postMessage.MessageTypes.SETTINGS_OPEN_MODAL, 'namespace', {}, undefined);
    });

    it('should report error when height is not provided', () =>  {
        sharedAPI.openModal(namespace, '', 2);

        expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory arguments - url & width & height must be specified');
        expect(postMessage.sendMessage).not.toHaveBeenCalledWith(postMessage.MessageTypes.SETTINGS_OPEN_MODAL, {}, undefined);
    });

    it('should send the proper message when input is valid', () =>  {
        var args = {
            url: 'http://www.haxs0r.com',
            width: 100,
            height: 100,
            isBareMode : undefined,
            options: undefined
        };

        sharedAPI.openModal(namespace, args.url, args.width, args.height, callback);
        expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SETTINGS_OPEN_MODAL, namespace, args, callback);
    });

    it('should send the proper message with a title', () => {
        var args = {
            url: 'http://www.haxs0r.com',
            width: 100,
            height: 100,
            title: 'Testing title in modal',
            isBareMode : undefined,
            options: undefined
        };

        sharedAPI.openModal(namespace, args.url, args.width, args.height, args.title, callback);
        expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SETTINGS_OPEN_MODAL, namespace, args, callback);
    });

    it('should send the proper message with a isBareMode', () => {
        var args = {
            url: 'http://www.haxs0r.com',
            width: 100,
            height: 100,
            title: 'Testing title in modal',
            isBareMode: true,
            options: undefined
        };

        sharedAPI.openModal(namespace, args.url, args.width, args.height, args.title, callback, args.isBareMode);
        expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SETTINGS_OPEN_MODAL, namespace, args, callback);
    });

    it('should send the proper message with options', () => {
        let options = {
            padding: false,
            transparent: true,
            overlay: 'rbga(0,0,0,0)',
            background: 'rbga(0,0,0,0)'
        };
        var args = {
            url: 'http://www.haxs0r.com',
            width: 100,
            height: 100,
            title: 'Testing title in modal',
            isBareMode: true,
            options: options
        };

        sharedAPI.openModal(namespace, args.url, args.width, args.height, args.title, callback, args.isBareMode, args.options);
        expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SETTINGS_OPEN_MODAL, namespace, args, callback);
    });

    it('should pass validation with percent values',  () => {
        var args = {
            url: 'http://www.haxs0r.com',
            width: '100%',
            height: '100%',
            isBareMode : undefined,
            options: undefined
        };

        sharedAPI.openModal(namespace, args.url, args.width, args.height, callback);
        expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SETTINGS_OPEN_MODAL, namespace, args, callback);
    });
});

describe('getStateUrl', function () {
    beforeEach(function () {
        spyOn(reporter, 'reportSdkError');
        spyOn(postMessage, 'sendMessage');
    });

    it('should throw error sectionId is not sent', function () {
        sharedAPI.getStateUrl(namespace);
        expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - sectionId - should be of type String');
    });

    it('should throw error if sectionId is of type function', function () {
        sharedAPI.getStateUrl(namespace, function() {});
        expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - sectionId - should be of type String');
    });

    it('should throw error state is not sent', function () {
        sharedAPI.getStateUrl(namespace, 'cd1mp');
        expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - state - should be of type String');
    });

    it('should throw error if state is of type function', function () {
        sharedAPI.getStateUrl(namespace, 'cd1mp', function() {});
        expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - state - should be of type String');
    });

    it('should throw error if callback is not sent', function () {
        sharedAPI.getStateUrl(namespace, 'cd1mp', 'internal/app/state');
        expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - callback - should be of type Function');
    });

    it('should throw error if callback is not a function', function () {
        sharedAPI.getStateUrl(namespace, 'cd1mp', 'internal/app/state', {});
        expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - callback - should be of type Function');
    });

    it('should send a post message with the correct command', function () {
        var callback = jasmine.createSpy('callback');
        sharedAPI.getStateUrl(namespace, 'cd1mp', 'internal/app/state', callback);
        expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_STATE_URL, namespace, {sectionId: 'cd1mp', state: 'internal/app/state'}, callback);
    });
});

describe('getProducts', function () {

    beforeEach(function(){
        spyOn(postMessage, 'sendMessage');
        spyOn(reporter, 'reportSdkError');
        this.onSuccessSpy = jasmine.createSpy('onSuccess');
        this.onErrorSpy = jasmine.createSpy('onError');
    });

    it('should report an error if first param is not an object or function', function () {
        sharedAPI.getProducts(namespace, 1);

        expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - first parameter must be an object or a function');
        expect(postMessage.sendMessage).not.toHaveBeenCalled();
    });

    describe('when options is the first param', function () {

        it('should report an error if onSuccess is missing', function () {
            sharedAPI.getProducts(namespace, {});

            expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - onSuccess must be a function');
            expect(postMessage.sendMessage).not.toHaveBeenCalled();
        });

        it('should report an error if onSuccess is not a function', function () {
            sharedAPI.getProducts(namespace, {}, 1);

            expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - onSuccess must be a function');
            expect(postMessage.sendMessage).not.toHaveBeenCalled();
        });

        it('should report an error if onError is not a function', function () {
            sharedAPI.getProducts(namespace, {}, this.onSuccessSpy, 1);

            expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - onError must be a function');
            expect(postMessage.sendMessage).not.toHaveBeenCalled();
        });

        it('should reprot an error if currency is not a string', function () {
            sharedAPI.getProducts(namespace, {currency: {}}, this.onSuccessSpy, this.onErrorSpy);

            expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - currency must be of type string');
            expect(postMessage.sendMessage).not.toHaveBeenCalled();
        });

        it('should send post message if params are valid', function () {
            sharedAPI.getProducts(namespace, {appDefinitionId: '1', currency: 'USD'}, this.onSuccessSpy, this.onErrorSpy);

            expect(reporter.reportSdkError).not.toHaveBeenCalled();
            expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_PRODUCTS, namespace, {appDefinitionId: '1', currency: 'USD'}, jasmine.any(Function));
        });

        it('should call onSuccess callback when input is valid', function () {
            postMessage.sendMessage.and.callFake(function (m, namespace, args, callback) {
                return callback({
                });
            });

            sharedAPI.getProducts(namespace, {appDefinitionId: '1'}, this.onSuccessSpy, this.onErrorSpy);

            expect(this.onSuccessSpy).toHaveBeenCalledWith({});
            expect(this.onErrorSpy).not.toHaveBeenCalled();
        });

        it('should call onError callback when editor returns an error', function () {
            postMessage.sendMessage.and.callFake(function (m, namespace, args, callback) {
                return callback({
                    error: 'error'
                });
            });

            sharedAPI.getProducts(namespace, {appDefinitionId: '1'}, this.onSuccessSpy, this.onErrorSpy);

            expect(this.onSuccessSpy).not.toHaveBeenCalled();
            expect(this.onErrorSpy).toHaveBeenCalledWith({
                error : 'error'
            });
        });
    });

    describe('when onSuccess is the first param', function () {

        it('should send post message if onSuccess is valid', function () {
            sharedAPI.getProducts(namespace, this.onSuccessSpy);

            expect(reporter.reportSdkError).not.toHaveBeenCalled();
            expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_PRODUCTS, namespace, {}, jasmine.any(Function));
        });

        it('should report an error if onError is not a function', function () {
            sharedAPI.getProducts(namespace, this.onSuccessSpy, 1);

            expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - onError must be a function');
            expect(postMessage.sendMessage).not.toHaveBeenCalled();
        });

        it('should send post message if onSuccess and onError are valid', function () {
            sharedAPI.getProducts(namespace, this.onSuccessSpy, this.onErrorSpy);

            expect(reporter.reportSdkError).not.toHaveBeenCalled();
            expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_PRODUCTS, namespace, {}, jasmine.any(Function));
        });

        it('should call onSuccess callback when input is valid', function () {
            postMessage.sendMessage.and.callFake(function (m, namespace, args, callback) {
                return callback({
                });
            });

            sharedAPI.getProducts(namespace, this.onSuccessSpy, this.onErrorSpy);

            expect(this.onSuccessSpy).toHaveBeenCalledWith({});
            expect(this.onErrorSpy).not.toHaveBeenCalled();
        });

        it('should call onError callback when editor returns an error', function () {
            postMessage.sendMessage.and.callFake(function (m, namespace, args, callback) {
                return callback({
                    error: 'error'
                });
            });

            sharedAPI.getProducts(namespace, this.onSuccessSpy, this.onErrorSpy);

            expect(this.onSuccessSpy).not.toHaveBeenCalled();
            expect(this.onErrorSpy).toHaveBeenCalledWith({
                error : 'error'
            });
        });

    });
});

describe('addApplication', function () {

    beforeEach(function () {
        spyOn(postMessage, 'sendMessage');
        spyOn(reporter, 'reportSdkError');
        this.onSuccessSpy = jasmine.createSpy('onSuccess');
        this.onErrorSpy = jasmine.createSpy('onError');
        spyOn(viewMode, 'getViewMode').and.returnValue('editor');
    });
    
    it('should report an error if not in editor', function(){
        viewMode.getViewMode.and.returnValue('site');

        sharedAPI.addApplication(namespace);

        expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid view mode. This function can be called only in editor mode.');
        expect(postMessage.sendMessage).not.toHaveBeenCalled();
    });

    it('should reprot an error if appDefinitionId is not passed', function () {
        sharedAPI.addApplication(namespace);

        expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - appDefinitionId - should be of type String');
        expect(postMessage.sendMessage).not.toHaveBeenCalled();
    });

    it('should reprot an error if appDefinitionId is not a string', function () {
        sharedAPI.addApplication(namespace, 1);

        expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - appDefinitionId - should be of type String');
        expect(postMessage.sendMessage).not.toHaveBeenCalled();
    });

    it('should send post message if appDefId is valid', function () {
        sharedAPI.addApplication(namespace, 'appDefId');

        expect(reporter.reportSdkError).not.toHaveBeenCalled();
        expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.ADD_APPLICATION, namespace, {
            appDefinitionId: 'appDefId'
        }, jasmine.any(Function));
    });

    it('should reprot an error if second param is not a function or object', function(){
        sharedAPI.addApplication(namespace, 'appDefId', 1);

        expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - second argument should be of type Object or Function');
        expect(postMessage.sendMessage).not.toHaveBeenCalled();
    });

    describe('when second param is an object', function () {

        it('should reprot an error if onSuccess is not a function', function () {
            sharedAPI.addApplication(namespace, 'appDefId', {}, 1);

            expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - onSuccess - should be of type Function');
            expect(postMessage.sendMessage).not.toHaveBeenCalled();
        });

        it('should reprot an error if onError is not a function', function () {
            sharedAPI.addApplication(namespace, 'appDefId', {}, this.onSuccessSpy, 1);

            expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - onError - should be of type Function');
            expect(postMessage.sendMessage).not.toHaveBeenCalled();
        });

        it('should send post message if all params are valid', function () {
            sharedAPI.addApplication(namespace, 'appDefId', {}, this.onSuccessSpy, this.onErrorSpy);

            expect(reporter.reportSdkError).not.toHaveBeenCalled();
            expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.ADD_APPLICATION, namespace, {
                appDefinitionId: 'appDefId'
            }, jasmine.any(Function));
        });
    });

    describe('when second param is a function', function(){

        it('should reprot an error if onError is not a function', function () {
            sharedAPI.addApplication(namespace, 'appDefId', this.onSuccessSpy, 1);

            expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - onError - should be of type Function');
            expect(postMessage.sendMessage).not.toHaveBeenCalled();
        });

        it('should send post message if all params are valid', function () {
            sharedAPI.addApplication(namespace, 'appDefId', this.onSuccessSpy, this.onErrorSpy);

            expect(reporter.reportSdkError).not.toHaveBeenCalled();
            expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.ADD_APPLICATION, namespace, {
                appDefinitionId: 'appDefId'
            }, jasmine.any(Function));
        });
    });
});

describe('isApplicationInstalled', function () {

    beforeEach(function(){
        spyOn(postMessage, 'sendMessage');
        spyOn(reporter, 'reportSdkError');
        this.callback = jasmine.createSpy('callback');
        spyOn(viewMode, 'getViewMode').and.returnValue('editor');
    });

    it('should report an error if not in editor', function(){
        viewMode.getViewMode.and.returnValue('site');

        sharedAPI.isApplicationInstalled(namespace);

        expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid view mode. This function can be called only in editor mode.');
        expect(postMessage.sendMessage).not.toHaveBeenCalled();
    });

    it('should report an error if appDefinitionId is not passed', function () {
        sharedAPI.isApplicationInstalled(namespace);

        expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - appDefinitionId - should be of type String');
        expect(postMessage.sendMessage).not.toHaveBeenCalled();
    });

    it('should report an error if appDefinitionId is not a string', function () {
        sharedAPI.isApplicationInstalled(namespace, 1);

        expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - appDefinitionId - should be of type String');
        expect(postMessage.sendMessage).not.toHaveBeenCalled();
    });

    it('should report an error if callback is not passed', function () {
        sharedAPI.isApplicationInstalled(namespace, 'appDefId');

        expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - callback - should be of type Function');
        expect(postMessage.sendMessage).not.toHaveBeenCalled();
    });

    it('should report an error if callback is not a function', function () {
        sharedAPI.isApplicationInstalled(namespace, 'appDefId', 1);

        expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - callback - should be of type Function');
        expect(postMessage.sendMessage).not.toHaveBeenCalled();
    });
    
    it('should send post message if params are valid', function(){
        sharedAPI.isApplicationInstalled(namespace, 'appDefId', this.callback);

        expect(reporter.reportSdkError).not.toHaveBeenCalled();
        expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.IS_APPLICATION_INSTALLED, namespace, {
            appDefinitionId: 'appDefId'
        }, this.callback);
    });
});
