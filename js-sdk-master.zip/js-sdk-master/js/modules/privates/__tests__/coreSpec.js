define(['privates/core', 'privates/postMessage'], function (core, postMessage) {
    describe('STYLE_PARAMS_READY', function () {
        it('should send STYLE_PARAMS_READY post message after getting styles in APP_IS_ALIVE callback', function () {
            var emptyStyleData = {
                siteColors: {},
                siteTextPresets: {init: 'init'},
                fonts: {
                    cssUrls: [],
                    imageSpriteUrl: null,
                    fontsMeta: []
                },
                style: {
                    colors: {},
                    fonts: {},
                    numbers: {}
                }
            };

            spyOn(postMessage, 'sendMessage').and.callFake(function (msgType, namespace, params, callback) {
                switch (msgType) {
                    case postMessage.MessageTypes.APP_IS_ALIVE:
                        callback(emptyStyleData);
                        break;
                    case postMessage.MessageTypes.STYLE_PARAMS_READY:
                        expect(true).toBeTruthy();
                }
            });
            core.init({
                endpointType: 'editor'
            });
        })
    });
});