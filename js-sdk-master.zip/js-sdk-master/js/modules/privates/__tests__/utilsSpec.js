define(['privates/utils'], function (utils) {
    'use strict';

    describe('utils', function() {
        describe('isPercentValue', function () {
            it('should return false for integer', function () {
                var isPercent = utils.isPercentValue(123);
                expect(isPercent).toBeFalsy();
            });

            it('should return false for a string', function () {
                var isPercent = utils.isPercentValue('123');
                expect(isPercent).toBeFalsy();
            });

            it('should return false for a string with % in the middle', function () {
                var isPercent = utils.isPercentValue('12%3');
                expect(isPercent).toBeFalsy();
            });

            it('should return false for double signed integer', function () {
                var isPercent = utils.isPercentValue('12%%');
                expect(isPercent).toBeFalsy();
            });

            it('should return true for single digit percent', function () {
                var isPercent = utils.isPercentValue('1%');
                expect(isPercent).toBeTruthy();
            });

            it('should return true for double digit percent', function () {
                var isPercent = utils.isPercentValue('12%');
                expect(isPercent).toBeTruthy();
            });

            it('should return true for 100%', function () {
                var isPercent = utils.isPercentValue('100%');
                expect(isPercent).toBeTruthy();
            });

            it('should return http protocol', function () {
                expect(utils.protocol()).toBe('http:');
            });
        });

        describe('isArray', function() {
            it('should return false for number value', function() {
                expect(utils.isArray(12)).toBeFalsy();
            });

            it('should return false for string value', function() {
                expect(utils.isArray('maya')).toBeFalsy();
            });

            it('should return false for object value', function() {
                expect(utils.isArray({12: 'maya'})).toBeFalsy();
            });

            it('should return true for array value', function() {
                expect(utils.isArray([1, '12', 6])).toBeTruthy();
            });
        });

        describe('merge', function () {
            it('should return the same object if source is empty', function () {
                const source = {a : 1};
                const oldSource = source;
                const dest = {};
                utils.merge(source, dest);
                expect(source).toBe(oldSource);
                expect(Object.keys(source).length).toBe(1);
            });

            it('should add new keys and override existing keys', function () {
                const source = {a: 1, b: 1};
                const dest = {b: 2, c: 3};
                utils.merge(source, dest);
                expect(source).toEqual({a: 1, b: 2, c: 3});
            });

            it('should work for deep objects', function () {
                const source = {a : {b: 1, c: {d: 1}}};
                const dest = {a: {c: {e: 3}, f: 4}};
                utils.merge(source, dest);
                expect(source).toEqual({a: {b: 1, c: {d: 1, e: 3}, f: 4}});
            });
        });

        describe('isNull', function() {
            it('should return "true" iff the value is "null"', function() {
                expect(utils.isNull(null)).toBe(true);

                expect(utils.isNull(undefined)).toBe(false);
                expect(utils.isNull(0)).toBe(false);
                expect(utils.isNull({})).toBe(false);
                expect(utils.isNull([])).toBe(false);
                expect(utils.isNull("abc")).toBe(false);
                expect(utils.isNull(function(){})).toBe(false);
            });
        });

        describe('isNaN', function() {
            it('should return true iff the value is not a number and is not null', function() {
                expect(utils.isNaN(undefined)).toBe(true);
                expect(utils.isNaN({})).toBe(true);
                expect(utils.isNaN(function(){})).toBe(true);
                expect(utils.isNaN("abc")).toBe(true);

                expect([] * 2).toBe(0);
                expect(utils.isNaN([])).toBe(false);
                expect(utils.isNaN(null)).toBe(false);
                expect(utils.isNaN(true)).toBe(false);
                expect(utils.isNaN(0)).toBe(false);
                expect(utils.isNaN(1)).toBe(false);
                expect(utils.isNaN(-1)).toBe(false);
                expect(utils.isNaN(Infinity)).toBe(false);
            });
        });

        describe('isUndefined', function() {
            it('should return "true" iff the value === undefined', function() {
                expect(utils.isUndefined()).toBe(true);

                expect(utils.isUndefined(null)).toBe(false);
                expect(utils.isUndefined(0)).toBe(false);
                expect(utils.isUndefined("abc")).toBe(false);
                expect(utils.isUndefined([])).toBe(false);
                expect(utils.isUndefined({})).toBe(false);
                expect(utils.isUndefined(function(){})).toBe(false);
            });
        });

        describe('pick', function() {
            it('should return an object only with the x & y properties', function() {
                var xVal = {};
                var yFunc = function() {};
                var objectToPickFrom = {w: 'bar', z: 5, x: xVal, y: yFunc};

                var pickedObject = utils.pick(objectToPickFrom, ['x', 'y']);

                expect(pickedObject.x).toEqual(xVal);
                expect(pickedObject.y).toEqual(yFunc);
                expect(Object.keys(pickedObject).length).toBe(2);
            });
        });

        describe('mapValues', function() {
            it('should return an object with the same keys, and new values that are calculated from the passed func', function() {
                var objectValuesToMap = {w: 1, z: 2, x: 3, y: 0};
                var square = function(value) {
                    return value * value;
                };

                var result = utils.mapValues(objectValuesToMap, square);

                var expectedResult = {
                    w: 1,
                    z: 4,
                    x: 9,
                    y: 0
                };
                expect(result).toEqual(expectedResult);
            });
        });
    });
});
