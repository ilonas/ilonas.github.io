define(['privates/core', 'privates/utils', 'privates/templateUtils', 'privates/__tests__/data/styleData'], function (core, utils, templateUtils, styleData) {
    'use strict';

    describe('applyWixMediaQuery', function () {
        it('should replace wix media query with regular css belongs to current mediaType', function () {
            var wixTpl = "body {color: red;}@media (wix-device-type:desktop) {body {color: blue;}}@media (wix-device-type:mobile) {body {color: green;}}.content {color: green;}";
            var expectedResult = "body {color: red;}/*** wix-media - @media: (desktop) ***/body {color: blue;}.content {color: green;}";
            var result = templateUtils.applyWixMediaQuery(wixTpl, 'desktop');
            expect(result).toBe(expectedResult);
        });
    });

    describe('evalTemplate', function() {
        it('should replace non spaced empty brackets with empty string: .sel{{{}}}', function() {
            var replacer = jasmine.createSpy('replacerCallback');
            var fullString = '.sel{{{}}}';
            var match = '{{}}';
            var p1 =  '';
            templateUtils.evalTemplate('.sel{{{}}}',replacer);
            expect(replacer).toHaveBeenCalledWith(match, p1, jasmine.any(Number), fullString);
        });

        it('should replace a non spaced style param within brackets: .sel{{{color:#ffffff}}}', function(){
            var replacer = jasmine.createSpy('replacerCallback');
            var fullString = '.sel{{{color:#ffffff}}}';
            var match = '{{color:#ffffff}}';
            var p1 =  'color:#ffffff';
            templateUtils.evalTemplate(fullString, replacer);
            expect(replacer).toHaveBeenCalledWith(match, p1, jasmine.any(Number), fullString);
        });

        it('should replace a spaced empty brackets with empty string: .sel{ {{}} }', function() {
            var replacer = jasmine.createSpy('replacerCallback');
            var fullString = '.sel{ {{}} }';
            var match = '{{}}';
            var p1 =  '';
            templateUtils.evalTemplate(fullString, replacer);
            expect(replacer).toHaveBeenCalledWith(match, p1, jasmine.any(Number), fullString);
        });

        it('should replace a multi line empty brackets with empty string: .sel{\n{{}}\n}', function() {
            var replacer = jasmine.createSpy('replacerCallback');
            var fullString = '.sel{\n{{}}\n}';
            var match = '{{}}';
            var p1 =  '';
            templateUtils.evalTemplate('.sel{\n{{}}\n}',replacer);
            expect(replacer).toHaveBeenCalledWith(match, p1, jasmine.any(Number), fullString);
        });
    });

    describe('mapColors', function () {
        var TPA_DEV_STYLES_PREFIX ='style.';
        var mappedColors = {};

        beforeEach(function() {
            mappedColors = templateUtils.mapColors(styleData.getStyleData().siteColors, styleData.getStyleData().style.colors);
        });

        it('should set primary colors', function () {
            expect(mappedColors['white/black'].name).toBe('color_1');
            expect(mappedColors['black/white'].name).toBe('color_2');
            expect(mappedColors['primery-1'].name).toBe('color_3');
            expect(mappedColors['primery-2'].name).toBe('color_4');
            expect(mappedColors['primery-3'].name).toBe('color_5');
        });

        it('should set non primary colors reference as color-1, color-2...', function () {
            var colorName, colorNameNumber;
            for (var i = 1; i <= 25; i++) {
                colorName = mappedColors['color-' + i].name;
                colorNameNumber = Number(colorName.split('_').pop());
                expect(colorNameNumber).toBeGreaterThan(10);
            }
        });

        it('should set TPA color params reference with "style." prefix', function () {
            expect(mappedColors[TPA_DEV_STYLES_PREFIX + 'wix-param-color'].themeName).toEqual(styleData.getStyleData().style.colors['wix-param-color'].themeName);
            expect(mappedColors[TPA_DEV_STYLES_PREFIX + 'wix-param-color'].value).toEqual(styleData.getStyleData().style.colors['wix-param-color'].value);
        });
    });

    describe('mapFonts', function() {
        it ('should map fonts', function() {
            var fonts = templateUtils.mapFonts(styleData.getStyleData().style.fonts);
            var expected = {
                "style.wix-param-fonttt": {
                    "size": 16,
                    "style": {
                        "bold": false,
                        "italic": false,
                        "underline": false
                    },
                    "family": "arial",
                    "cssFontFamily": "'arial','ｍｓ ｐゴシック','ms pgothic','돋움','dotum','helvetica','sans-serif'",
                    "preset": "Custom",
                    "fontStyleParam": true,
                    "value": "font:normal normal normal 16px/20px arial,\"ｍｓ ｐゴシック\",\"ms pgothic\",\"돋움\",dotum,helvetica,sans-serif;"
                }
            };
            expect(fonts).toEqual(expected);
        });
    });

    describe('mapNumbers', function() {
        it ('should map numbers', function() {
            var numbers = templateUtils.mapNumbers(styleData.getStyleData().style.numbers);
            expect(numbers).toEqual( { 'style.wix-param-number': 1 } );
        });
    });

    describe('getWixStyleElements', function(){
        it('should return an array containing style with wix-style attribute', function(){
            var wixStyle = document.createElement('style');
            wixStyle.setAttribute('wix-style', '');
            var nonWixStyle = document.createElement('style');
            spyOn(document, 'getElementsByTagName').and.returnValue([wixStyle, nonWixStyle]);
            var elements = templateUtils.getWixStyleElements();
            expect(elements.length).toBe(1);
        });
    });

    describe('insertStyleReset', function(){
       it('should append a preset style element', function(){

           var expectedContent = ".Title{ {{Title}} } .Menu{ {{Menu}} } .Page-title{ {{Page-title}} } .Heading-XL{ {{Heading-XL}} } .Heading-L{ {{Heading-L}} } .Heading-M{ {{Heading-M}} } .Heading-S{ {{Heading-S}} } .Body-L{ {{Body-L}} } .Body-M{ {{Body-M}} } .Body-S{ {{Body-S}} } .Body-XS{ {{Body-XS}} } }";
           var fakeElem = {
               setAttribute: jasmine.createSpy('setAttribute'),
               appendChild: jasmine.createSpy('appendChild')
           };

           spyOn(document, 'createElement').and.returnValue(fakeElem);
           spyOn(document, 'getElementsByTagName').and.returnValue([fakeElem]);

           templateUtils.insertStyleReset();

           expect(document.createElement).toHaveBeenCalledWith('style');
           expect(fakeElem.setAttribute).toHaveBeenCalledWith('wix-style', '');
           expect(fakeElem.appendChild).toHaveBeenCalledWith(fakeElem);
           expect(fakeElem.textContent).toEqual(expectedContent);
       });
    });

    describe('evalWixStyleTemplates', function () {
        var styleMock;
        var originalTextContent = 'original text content {{replace}}';
        var matchFunction = function () {
            return 'replaced';
        };

        beforeEach(function () {
            styleMock = {
                textContent: originalTextContent,
                hasAttribute: function () {
                    return true;
                }
            };
            spyOn(document, 'getElementsByTagName').and.returnValue([styleMock]);
        });

        it('should save original style.textContent as style.originalTemplate property', function () {
            templateUtils.evalWixStyleTemplates(matchFunction);
            expect(styleMock.originalTemplate).toEqual(originalTextContent);
        });

        it('should use match function for replace', function () {
            templateUtils.evalWixStyleTemplates(matchFunction);
            expect(styleMock.textContent).toEqual('original text content replaced');
        });
    });

    describe('appendFontsLinks', function () {
        beforeEach(function () {
            spyOn(document, 'createElement').and.callThrough();
        });

        it('should add new style link to head if not exist', function () {
            templateUtils.appendFontsLinks({fonts: {cssUrls: ['url']}});
            expect(document.createElement).toHaveBeenCalledWith('link');
        });

        it('should not add style link if exist', function () {
            templateUtils.appendFontsLinks({fonts: {cssUrls: ['url']}});
            expect(document.createElement).not.toHaveBeenCalled();
        });
    });

    describe('appendOrUpdateUploadedFontFaces', function () {
        var uploadedFontFaces = templateUtils.uploadedFontFaces;
        var fontFaces = '@font-face {}';

        beforeEach(function () {
            uploadedFontFaces = document.createElement('style');
            spyOn(document, 'createElement').and.callThrough();
        });

        it('should add font face style if new', function () {
            uploadedFontFaces = null;
            templateUtils.appendOrUpdateUploadedFontFaces(fontFaces);
            expect(document.createElement).toHaveBeenCalledWith('style');
        });

        it('should not add font face style if none is given', function () {
            templateUtils.appendOrUpdateUploadedFontFaces();
            expect(document.createElement).not.toHaveBeenCalled();
        });

        it('should not add font face style if not changed', function () {
            uploadedFontFaces.textContent = fontFaces;
            templateUtils.appendOrUpdateUploadedFontFaces(fontFaces);
            expect(document.createElement).not.toHaveBeenCalled();
        });

        it('should add font face style if changed', function () {
            uploadedFontFaces.textContent = fontFaces;
            var newFontFaces =  '@font-face {} @font-face {}';
            templateUtils.appendOrUpdateUploadedFontFaces(newFontFaces);
            expect(document.createElement).toHaveBeenCalledWith('style');
        });

        it('should remove old font faces if updated after 5 seconds', function () {
            spyOn(window, 'setTimeout');
            uploadedFontFaces.textContent = fontFaces;
            var newFontFaces =  '@font-face {} @font-face {} @font-face {}';
            templateUtils.appendOrUpdateUploadedFontFaces(newFontFaces);
            expect(window.setTimeout).toHaveBeenCalledWith(jasmine.any(Function), 5000);
        });
    });

    describe('appendOrUpdateGoogleFontsLink', function () {
        var googleCssFonts = templateUtils.googleCssFonts;

        beforeEach(function () {
            googleCssFonts.link = document.createElement('link');
            spyOn(document, 'createElement').and.callThrough();
        });

        it('should add link style if new url', function () {
            googleCssFonts.link = null;
            templateUtils.appendOrUpdateGoogleFontsLink('url1');
            expect(document.createElement).toHaveBeenCalledWith('link');
        });

        it('should not add link if no url', function () {
            templateUtils.appendOrUpdateGoogleFontsLink();
            expect(document.createElement).not.toHaveBeenCalledWith('link');
        });

        it('should not add link if url not changed', function () {
            googleCssFonts.link.setAttribute('href', 'url');
            templateUtils.appendOrUpdateGoogleFontsLink('url');
            expect(document.createElement).not.toHaveBeenCalledWith('link');
        });

        it('should add link if url changed', function () {
            googleCssFonts.link.setAttribute('href', 'url');
            templateUtils.appendOrUpdateGoogleFontsLink('otherUrl');
            expect(document.createElement).toHaveBeenCalledWith('link');
        });

        it('should remove old link when url updated after 5 seconds', function () {
            spyOn(window, 'setTimeout');
            googleCssFonts.link.setAttribute('href', 'url');
            templateUtils.appendOrUpdateGoogleFontsLink('otherUrl');
            expect(window.setTimeout).toHaveBeenCalledWith(jasmine.any(Function), 5000);
        });
    });
});
