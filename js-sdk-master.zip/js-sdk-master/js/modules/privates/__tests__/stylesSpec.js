define(['privates/postMessage', 'privates/utils', 'Events', 'privates/styles', 'privates/templateUtils'], function(postMessage, utils, Events, styles, templateUtils) {

    describe('private styles tests -', function(){

        var emptyStyleData = {
            siteColors: {},
            siteTextPresets: {init: 'init'},
            fonts: {
                cssUrls: [],
                imageSpriteUrl: null,
                fontsMeta: []
            },
            style: {
                colors: {},
                fonts: {},
                numbers: {}
            }
        };

        var updatedStyleData = {
            siteColors: {},
            siteTextPresets: {init: 'init'},
            fonts: {
                cssUrls: [],
                imageSpriteUrl: 'some_url',
                fontsMeta: []
            },
            style: {
                colors: {
                    'color_1': 'value'
                },
                fonts: {
                    'font_1': 'fontValue'
                },
                numbers: {}
            }
        };

        var expectedCacheStructure = {
            siteColors: {},
            siteTextPresets: { init : 'init' },
            style: {
                colors: {},
                fonts: {},
                numbers: {}
            },
            fontsMeta: [],
            fontsSpriteUrl: null,
            mappedColors: {},
            mappedFonts: {},
            mappedNumbers: {}
        };

        beforeEach(function() {
            spyOn(templateUtils, 'insertStyleReset');
            spyOn(templateUtils, 'evalWixStyleTemplates');
            spyOn(postMessage, 'callEventListeners');
            spyOn(postMessage, 'addEventListenerInternal');
        });

        describe('init', function () {
            it('should inject wix-style reset stylesheet, update cache, update wix-style elements in the dom, add event listener to THEME_CHANGE, and STYLE_PARAM_CHANGE', function () {
                spyOn(document, 'getElementsByTagName').and.callThrough();
                styles.init(function(){}, emptyStyleData);
                expect(styles.Cache).toEqual(expectedCacheStructure);
                expect(templateUtils.insertStyleReset).toHaveBeenCalled();
                expect(document.getElementsByTagName).toHaveBeenCalled(); // templateUtils.evalWixStyleTemplates haveBeenCalled
                expect(postMessage.addEventListenerInternal).toHaveBeenCalledWith(Events.THEME_CHANGE, undefined, jasmine.any(Function));
                expect(postMessage.addEventListenerInternal).toHaveBeenCalledWith(Events.STYLE_PARAMS_CHANGE, undefined, jasmine.any(Function));
            });

            it('should execute callback', function () {
                var callback = jasmine.createSpy('callback');
                styles.init(callback, emptyStyleData);
                expect(callback).toHaveBeenCalled();
            })
        });

        describe('onThemeChange', function () {

            beforeEach(function () {
                styles.init(function(){}, {});
            });

            it('should update cache & call onStyleParamChange', function () {
                styles.onThemeChange(emptyStyleData);
                expect(postMessage.callEventListeners).toHaveBeenCalledWith({
                    params: emptyStyleData.style,
                    eventType: 'STYLE_PARAMS_CHANGE'
                }, 'internal');
            });


            it('should handle flat style as an input', function () {
                styles.onThemeChange({
                    colors: {
                        color1: '1'
                    },
                    fonts: {},
                    numbers: {}
                });

                expect(styles.Cache.style.colors).toEqual({
                    color1: '1'
                });

                expect(styles.Cache.mappedColors).toEqual({
                    'style.color1': '1'
                });
            });

            it('should call onStyleParamChange with updated styleData', function () {
                styles.onThemeChange(updatedStyleData);
                expect(postMessage.callEventListeners).toHaveBeenCalledWith({
                    params: updatedStyleData.style,
                    eventType: 'STYLE_PARAMS_CHANGE'
                }, 'internal');
            });

            it('should handle case when font object has no metaData', function () {
                styles.onThemeChange({
                    colors: {
                        color1: '1'
                    },
                    fonts: {
                        fontsMeta: {
                            font1: '1'
                        }
                    },
                    numbers: {}
                });


                styles.onThemeChange({
                    colors: {
                        color1: '1'
                    },
                    fonts: {},
                    numbers: {}
                });

                expect(styles.Cache.fontsMeta).toEqual({
                    font1: '1'
                });
            });

            it('should handle case when font object has no imageSpriteUrl', function () {
                styles.onThemeChange({
                    colors: {
                        color1: '1'
                    },
                    fonts: {
                        imageSpriteUrl: {
                            spriteUrl: '1'
                        }
                    },
                    numbers: {}
                });


                styles.onThemeChange({
                    colors: {
                        color1: '1'
                    },
                    fonts: {},
                    numbers: {}
                });

                expect(styles.Cache.fontsSpriteUrl).toEqual({
                    spriteUrl: '1'
                });
            });
        });

        describe('onStyleParamChange', function() {
           it('should update cache if not internal, and evaluate wix-style template', function() {
               styles.onStyleParamChange(emptyStyleData);
               //expect(styles.updateStylesCache).toHaveBeenCalledWith(emptyStyleData);
               expect(templateUtils.evalWixStyleTemplates).toHaveBeenCalled();
           }) ;
        });

        describe('updateStylesCache', function () {

            beforeEach(function() {
               spyOn(templateUtils, 'appendOrUpdateUploadedFontFaces');
            });

            var setParam = {
                fonts: {
                    fontsMeta: 'someObject',
                    imageSpriteUrl: 'someUrl',
                    cssUrls: []
                },
                style: {
                    colors: {}
                },
                siteColors: [{
                    "name": "color_1",
                    "value": "#FFFFFF"
                }],
                siteTextPresets: 'siteTextPresets'
            };

            var expectedCach = {
                siteColors: [{name: 'color_1', value: '#FFFFFF', reference: 'white/black'}],
                siteTextPresets: 'siteTextPresets',
                style: {colors: {}},
                fontsMeta: 'someObject',
                fontsSpriteUrl: 'someUrl',
                mappedColors: {
                    'white/black': {
                        name: 'color_1',
                        value: '#FFFFFF',
                        reference: 'white/black'
                    }
                },
                mappedFonts: {},
                mappedNumbers: {}
            };

            it('should set style cache', function () {
                styles.updateStylesCache(setParam);
                expect(styles.Cache).toEqual(expectedCach);
            });

            it('should append font faces in case there in style obj', function() {
                var uploadedFontFaces = '@font-face {} @font-face {}';
                var setParam = {
                    fonts: {
                        fontsMeta: 'someObject',
                        imageSpriteUrl: 'someUrl',
                        cssUrls: []
                    },
                    style: {
                        colors: {},
                        uploadFontFaces: uploadedFontFaces
                    },
                    siteColors: [{
                        "name": "color_1",
                        "value": "#FFFFFF"
                    }],
                    siteTextPresets: 'siteTextPresets'
                };

                styles.updateStylesCache(setParam);
                expect(templateUtils.appendOrUpdateUploadedFontFaces).toHaveBeenCalledWith(uploadedFontFaces);
            });

            it('should not append font faces in case there in style obj', function() {
                var uploadedFontFaces = '@font-face {} @font-face {}';
                var setParam = {
                    fonts: {
                        fontsMeta: 'someObject',
                        imageSpriteUrl: 'someUrl',
                        cssUrls: []
                    },
                    style: {
                        colors: {},
                        uploadFontFaces: undefined
                    },
                    siteColors: [{
                        "name": "color_1",
                        "value": "#FFFFFF"
                    }],
                    siteTextPresets: 'siteTextPresets'
                };

                styles.updateStylesCache(setParam);
                expect(templateUtils.appendOrUpdateUploadedFontFaces).not.toHaveBeenCalled();

            });
        });

        describe('mapSiteStyles', function(){
            it('should call mapFonts, mapNumbers, mapColors', function(){
                var data = getStyleData();
                var siteStylesMap = styles.mapSiteStyles(data);
                expect(siteStylesMap.mappedColors['color-1']).toEqual({ name : 'color_11', value : '#FFFFFF', reference : 'color-1' });
                expect(siteStylesMap.mappedFonts).toEqual({'style.wix-param-fonttt': data.style.fonts['wix-param-fonttt']});
                expect(siteStylesMap.mappedNumbers).toEqual({ 'style.wix-param-number' : 1 });
            });
        });

        describe('getFirstOrFallbackStyleParamValue', function() {

            styles.Cache.mappedColors = {};
            styles.Cache.mappedFonts = {};
            styles.Cache.mappedNumbers = {};
            styles.Cache.siteTextPresets = {};

            it('should replace color param', function() {
                var key = 'style.color';
                var value = '#FFFFFF';
                styles.Cache.mappedColors[key] = {value: value};
                var response = styles.getFirstOrFallbackStyleParamValue('{{' + key + '}}', key);
                expect(response).toBe(value);
            });

            it('should replace font param', function(){
                var key = 'style.font';
                var value = 'halvatica';
                styles.Cache.mappedFonts[key] = {value: value};
                var response = styles.getFirstOrFallbackStyleParamValue('{{' + key + '}}', key);
                console.log(response);
                expect(response).toBe(value);
            });

            it ('should replace number param', function(){
                var key = 'style.number';
                var value = 1;
                styles.Cache.mappedNumbers[key] = value;
                var response = styles.getFirstOrFallbackStyleParamValue('{{' + key + '}}', key);
                expect(response).toBe(value);
            });

            it ('should replace site text presets param', function(){
                var key = 'Title';
                var value = 'title';
                styles.Cache.siteTextPresets[key] = {value: value};
                var response = styles.getFirstOrFallbackStyleParamValue('{{' + key + '}}', key);
                expect(response).toBe(value);
            });

            it('should return a fallback in case no value was found', function(){
                var key = 'style.undefined color-1';
                var response = styles.getFirstOrFallbackStyleParamValue('{{' + key + '}}', key);
                expect(response).toBe(styles.Cache.mappedColors['color-1'].value);
            });

            it('should return the original value in case no match was found and no fallbacks are given', function(){
                var key = 'style.undefined';
                var response = styles.getFirstOrFallbackStyleParamValue('{{' + key + '}}', key);
                expect(response).toBe(key);
            });

            it('should return the last fallback in case no match was found and fallbacks are given', function() {
                var key = 'style.undefined color-foo color-bar';
                var response = styles.getFirstOrFallbackStyleParamValue('{{' + key + '}}', key);
                expect(response).toBe('color-bar');
            });

            it('should return the first fallback match in case fallbacks are given and a match was found', function(){
                var key = 'style.undefined color-1 color-2';
                styles.Cache.mappedColors['color-1'] = {value: 'color-1'};
                var response = styles.getFirstOrFallbackStyleParamValue('{{' + key + '}}', key);
                expect(response).toBe('color-1');

            });
        });

        describe('Cache', function () {
            it('should be an object', function () {
                expect(utils.isObject(styles.Cache)).toBe(true);
            });
        });

    });

    var getStyleData = function(){
        return  {
            "fonts": {
                "cssUrls": [
                    "//static.parastorage.com/services/santa/1.797.1/static/css/user-site-fonts/latin.css"
                ],
                "imageSpriteUrl": "//static.parastorage.com/services/santa/1.797.1/static/images/editorUI/fonts.png",
                "fontsMeta": [
                    {
                        "lang": "latin",
                        "fonts": [
                            {
                                "displayName": "Amatic SC",
                                "fontFamily": "amatic sc",
                                "cdnName": "Amatic+SC",
                                "genericFamily": "cursive",
                                "provider": "google",
                                "characterSets": [
                                    "latin"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 154,
                                "cssFontFamily": "\"amatic sc\",cursive"
                            },
                            {
                                "displayName": "American Typewriter",
                                "fontFamily": "americantypwrteritcw01--731025",
                                "cdnName": "",
                                "genericFamily": "serif",
                                "provider": "monotype",
                                "characterSets": [
                                    "latin",
                                    "latin-ext"
                                ],
                                "permissions": "all",
                                "fallbacks": "americantypwrteritcw02--737091",
                                "spriteIndex": 142,
                                "cssFontFamily": "americantypwrteritcw01--731025,americantypwrteritcw02--737091,serif"
                            },
                            {
                                "displayName": "Anton",
                                "fontFamily": "anton",
                                "cdnName": "Anton",
                                "genericFamily": "sans-serif",
                                "provider": "google",
                                "characterSets": [
                                    "latin",
                                    "latin-ext"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 0,
                                "cssFontFamily": "anton,sans-serif"
                            },
                            {
                                "displayName": "Arial",
                                "fontFamily": "arial",
                                "cdnName": "",
                                "genericFamily": "sans-serif",
                                "provider": "system",
                                "characterSets": [
                                    "latin",
                                    "latin-ext",
                                    "cyrillic",
                                    "hebrew",
                                    "arabic"
                                ],
                                "permissions": "all",
                                "fallbacks": "ｍｓ ｐゴシック,ms pgothic,돋움,dotum,helvetica",
                                "spriteIndex": 2,
                                "cssFontFamily": "arial,\"ｍｓ ｐゴシック\",\"ms pgothic\",\"돋움\",dotum,helvetica,sans-serif"
                            },
                            {
                                "displayName": "Arial Black",
                                "fontFamily": "arial black",
                                "cdnName": "",
                                "genericFamily": "sans-serif",
                                "provider": "system",
                                "characterSets": [
                                    "latin",
                                    "latin-ext",
                                    "cyrillic"
                                ],
                                "permissions": "all",
                                "fallbacks": "arial-w01-black,arial-w02-black,arial-w10 black",
                                "spriteIndex": 12,
                                "cssFontFamily": "\"arial black\",arial-w01-black,arial-w02-black,\"arial-w10 black\",sans-serif"
                            },
                            {
                                "displayName": "Avenida",
                                "fontFamily": "avenida-w01",
                                "cdnName": "",
                                "genericFamily": "fantasy",
                                "provider": "monotype",
                                "characterSets": [
                                    "latin",
                                    "latin-ext"
                                ],
                                "permissions": "all",
                                "fallbacks": "avenida-w02",
                                "spriteIndex": 112,
                                "cssFontFamily": "avenida-w01,avenida-w02,fantasy"
                            },
                            {
                                "displayName": "Basic",
                                "fontFamily": "basic",
                                "cdnName": "Basic",
                                "genericFamily": "sans-serif",
                                "provider": "google",
                                "characterSets": [
                                    "latin",
                                    "latin-ext"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 15,
                                "cssFontFamily": "basic,sans-serif"
                            },
                            {
                                "displayName": "Bodoni Poster",
                                "fontFamily": "bodoni-w01-poster",
                                "cdnName": "",
                                "genericFamily": "fantasy",
                                "provider": "monotype",
                                "characterSets": [
                                    "latin",
                                    "cyrillic"
                                ],
                                "permissions": "all",
                                "fallbacks": "bodoni-poster-w10",
                                "spriteIndex": 108,
                                "cssFontFamily": "bodoni-w01-poster,bodoni-poster-w10,fantasy"
                            },
                            {
                                "displayName": "Braggadocio",
                                "fontFamily": "braggadocio-w01",
                                "cdnName": "",
                                "genericFamily": "fantasy",
                                "provider": "monotype",
                                "characterSets": [
                                    "latin"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 117,
                                "cssFontFamily": "braggadocio-w01,fantasy"
                            },
                            {
                                "displayName": "Caudex",
                                "fontFamily": "caudex",
                                "cdnName": "Caudex",
                                "genericFamily": "serif",
                                "provider": "google",
                                "characterSets": [
                                    "latin",
                                    "latin-ext"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 17,
                                "cssFontFamily": "caudex,serif"
                            },
                            {
                                "displayName": "Chelsea Market",
                                "fontFamily": "chelsea market",
                                "cdnName": "Chelsea+Market",
                                "genericFamily": "fantasy",
                                "provider": "google",
                                "characterSets": [
                                    "latin"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 19,
                                "cssFontFamily": "\"chelsea market\",fantasy"
                            },
                            {
                                "displayName": "Clarendon LT",
                                "fontFamily": "clarendon-w01-medium-692107",
                                "cdnName": "",
                                "genericFamily": "serif",
                                "provider": "monotype",
                                "characterSets": [
                                    "latin",
                                    "latin-ext"
                                ],
                                "permissions": "all",
                                "fallbacks": "clarendon-w02-medium-693834",
                                "spriteIndex": 138,
                                "cssFontFamily": "clarendon-w01-medium-692107,clarendon-w02-medium-693834,serif"
                            },
                            {
                                "displayName": "Comic Sans MS",
                                "fontFamily": "comic sans ms",
                                "cdnName": "",
                                "genericFamily": "cursive",
                                "provider": "system",
                                "characterSets": [
                                    "latin",
                                    "latin-ext",
                                    "cyrillic"
                                ],
                                "permissions": "all",
                                "fallbacks": "comic-sans-w01-regular,comic-sans-w02-regular,comic-sans-w10-regular",
                                "spriteIndex": 20,
                                "cssFontFamily": "\"comic sans ms\",comic-sans-w01-regular,comic-sans-w02-regular,comic-sans-w10-regular,cursive"
                            },
                            {
                                "displayName": "Cookie",
                                "fontFamily": "cookie",
                                "cdnName": "Cookie",
                                "genericFamily": "cursive",
                                "provider": "google",
                                "characterSets": [
                                    "latin",
                                    "latin-ext"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 148,
                                "cssFontFamily": "cookie,cursive"
                            },
                            {
                                "displayName": "Coquette",
                                "fontFamily": "coquette-w00-light",
                                "cdnName": "",
                                "genericFamily": "sans-serif",
                                "provider": "monotype",
                                "characterSets": [
                                    "latin",
                                    "latin-ext"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 155,
                                "cssFontFamily": "coquette-w00-light,sans-serif"
                            },
                            {
                                "displayName": "Corben",
                                "fontFamily": "corben",
                                "cdnName": "Corben",
                                "genericFamily": "serif",
                                "provider": "google",
                                "characterSets": [
                                    "latin"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 23,
                                "cssFontFamily": "corben,serif"
                            },
                            {
                                "displayName": "Courier New",
                                "fontFamily": "courier new",
                                "cdnName": "",
                                "genericFamily": "monospace",
                                "provider": "system",
                                "characterSets": [
                                    "latin",
                                    "latin-ext",
                                    "cyrillic",
                                    "hebrew",
                                    "arabic"
                                ],
                                "permissions": "all",
                                "fallbacks": "courier-ps-w01,courier-ps-w02,courier-ps-w10",
                                "spriteIndex": 7,
                                "cssFontFamily": "\"courier new\",courier-ps-w01,courier-ps-w02,courier-ps-w10,monospace"
                            },
                            {
                                "displayName": "DIN Next Light",
                                "fontFamily": "din-next-w01-light",
                                "cdnName": "",
                                "genericFamily": "sans-serif",
                                "provider": "monotype",
                                "characterSets": [
                                    "latin",
                                    "latin-ext",
                                    "cyrillic"
                                ],
                                "permissions": "all",
                                "fallbacks": "din-next-w02-light,din-next-w10-light",
                                "spriteIndex": 121,
                                "cssFontFamily": "din-next-w01-light,din-next-w02-light,din-next-w10-light,sans-serif"
                            },
                            {
                                "displayName": "Droid Serif",
                                "fontFamily": "droid-serif-w01-regular",
                                "cdnName": "",
                                "genericFamily": "serif",
                                "provider": "monotype",
                                "characterSets": [
                                    "latin",
                                    "latin-ext",
                                    "cyrillic"
                                ],
                                "permissions": "all",
                                "fallbacks": "droid-serif-w02-regular,droid-serif-w10-regular",
                                "spriteIndex": 135,
                                "cssFontFamily": "droid-serif-w01-regular,droid-serif-w02-regular,droid-serif-w10-regular,serif"
                            },
                            {
                                "displayName": "EB Garamond",
                                "fontFamily": "eb garamond",
                                "cdnName": "EB+Garamond",
                                "genericFamily": "serif",
                                "provider": "google",
                                "characterSets": [
                                    "latin",
                                    "latin-ext",
                                    "cyrillic"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 24,
                                "cssFontFamily": "\"eb garamond\",serif"
                            },
                            {
                                "displayName": "Enriqueta",
                                "fontFamily": "enriqueta",
                                "cdnName": "Enriqueta",
                                "genericFamily": "serif",
                                "provider": "google",
                                "characterSets": [
                                    "latin",
                                    "latin-ext"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 27,
                                "cssFontFamily": "enriqueta,serif"
                            },
                            {
                                "displayName": "Forum",
                                "fontFamily": "forum",
                                "cdnName": "Forum",
                                "genericFamily": "serif",
                                "provider": "google",
                                "characterSets": [
                                    "latin",
                                    "latin-ext",
                                    "cyrillic"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 29,
                                "cssFontFamily": "forum,serif"
                            },
                            {
                                "displayName": "Fredericka the Great",
                                "fontFamily": "fredericka the great",
                                "cdnName": "Fredericka+the+Great",
                                "genericFamily": "fantasy",
                                "provider": "google",
                                "characterSets": [
                                    "latin"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 32,
                                "cssFontFamily": "\"fredericka the great\",fantasy"
                            },
                            {
                                "displayName": "Georgia",
                                "fontFamily": "georgia",
                                "cdnName": "",
                                "genericFamily": "serif",
                                "provider": "system",
                                "characterSets": [
                                    "latin",
                                    "latin-ext",
                                    "cyrillic"
                                ],
                                "permissions": "all",
                                "fallbacks": "palatino,book antiqua,palatino linotype",
                                "spriteIndex": 33,
                                "cssFontFamily": "georgia,palatino,\"book antiqua\",\"palatino linotype\",serif"
                            },
                            {
                                "displayName": "Geotica Four Open",
                                "fontFamily": "geotica-w01-four-open",
                                "cdnName": "",
                                "genericFamily": "fantasy",
                                "provider": "monotype",
                                "characterSets": [
                                    "latin"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 115,
                                "cssFontFamily": "geotica-w01-four-open,fantasy"
                            },
                            {
                                "displayName": "Helvetica",
                                "fontFamily": "helvetica-w01-roman",
                                "cdnName": "",
                                "genericFamily": "sans-serif",
                                "provider": "monotype",
                                "characterSets": [
                                    "latin",
                                    "latin-ext",
                                    "cyrillic"
                                ],
                                "permissions": "all",
                                "fallbacks": "helvetica-w02-roman,helvetica-lt-w10-roman",
                                "spriteIndex": 124,
                                "cssFontFamily": "helvetica-w01-roman,helvetica-w02-roman,helvetica-lt-w10-roman,sans-serif"
                            },
                            {
                                "displayName": "Helvetica Bold",
                                "fontFamily": "helvetica-w01-bold",
                                "cdnName": "",
                                "genericFamily": "sans-serif",
                                "provider": "monotype",
                                "characterSets": [
                                    "latin",
                                    "latin-ext",
                                    "cyrillic"
                                ],
                                "permissions": "all",
                                "fallbacks": "helvetica-w02-bold,helvetica-lt-w10-bold",
                                "spriteIndex": 129,
                                "cssFontFamily": "helvetica-w01-bold,helvetica-w02-bold,helvetica-lt-w10-bold,sans-serif"
                            },
                            {
                                "displayName": "Helvetica Light",
                                "fontFamily": "helvetica-w01-light",
                                "cdnName": "",
                                "genericFamily": "sans-serif",
                                "provider": "monotype",
                                "characterSets": [
                                    "latin",
                                    "latin-ext"
                                ],
                                "permissions": "all",
                                "fallbacks": "helvetica-w02-light",
                                "spriteIndex": 127,
                                "cssFontFamily": "helvetica-w01-light,helvetica-w02-light,sans-serif"
                            },
                            {
                                "displayName": "ITC Arecibo",
                                "fontFamily": "itc-arecibo-w01-regular",
                                "cdnName": "",
                                "genericFamily": "fantasy",
                                "provider": "monotype",
                                "characterSets": [
                                    "latin"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 111,
                                "cssFontFamily": "itc-arecibo-w01-regular,fantasy"
                            },
                            {
                                "displayName": "Impact",
                                "fontFamily": "impact",
                                "cdnName": "",
                                "genericFamily": "sans-serif",
                                "provider": "system",
                                "characterSets": [
                                    "latin",
                                    "latin-ext",
                                    "cyrillic"
                                ],
                                "permissions": "all",
                                "fallbacks": "impact-w01-2010,impact-w02-2010,impact-w10-2010",
                                "spriteIndex": 36,
                                "cssFontFamily": "impact,impact-w01-2010,impact-w02-2010,impact-w10-2010,sans-serif"
                            },
                            {
                                "displayName": "Jockey One",
                                "fontFamily": "jockey one",
                                "cdnName": "Jockey+One",
                                "genericFamily": "sans-serif",
                                "provider": "google",
                                "characterSets": [
                                    "latin",
                                    "latin-ext"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 39,
                                "cssFontFamily": "\"jockey one\",sans-serif"
                            },
                            {
                                "displayName": "Josefin Slab",
                                "fontFamily": "josefin slab",
                                "cdnName": "Josefin+Slab",
                                "genericFamily": "serif",
                                "provider": "google",
                                "characterSets": [
                                    "latin"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 41,
                                "cssFontFamily": "\"josefin slab\",serif"
                            },
                            {
                                "displayName": "Jura",
                                "fontFamily": "jura",
                                "cdnName": "Jura",
                                "genericFamily": "sans-serif",
                                "provider": "google",
                                "characterSets": [
                                    "latin",
                                    "latin-ext",
                                    "cyrillic"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 42,
                                "cssFontFamily": "jura,sans-serif"
                            },
                            {
                                "displayName": "Kelly Slab",
                                "fontFamily": "kelly slab",
                                "cdnName": "Kelly+Slab",
                                "genericFamily": "fantasy",
                                "provider": "google",
                                "characterSets": [
                                    "latin",
                                    "latin-ext",
                                    "cyrillic"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 45,
                                "cssFontFamily": "\"kelly slab\",fantasy"
                            },
                            {
                                "displayName": "Lobster",
                                "fontFamily": "lobster",
                                "cdnName": "Lobster",
                                "genericFamily": "cursive",
                                "provider": "google",
                                "characterSets": [
                                    "latin",
                                    "latin-ext",
                                    "cyrillic"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 54,
                                "cssFontFamily": "lobster,cursive"
                            },
                            {
                                "displayName": "Lucida Console",
                                "fontFamily": "lucida console",
                                "cdnName": "",
                                "genericFamily": "monospace",
                                "provider": "system",
                                "characterSets": [
                                    "latin",
                                    "latin-ext"
                                ],
                                "permissions": "all",
                                "fallbacks": "lucida-console-w01",
                                "spriteIndex": 48,
                                "cssFontFamily": "\"lucida console\",lucida-console-w01,monospace"
                            },
                            {
                                "displayName": "Lucida Sans Unicode",
                                "fontFamily": "lucida sans unicode",
                                "cdnName": "",
                                "genericFamily": "sans-serif",
                                "provider": "system",
                                "characterSets": [
                                    "latin"
                                ],
                                "permissions": "all",
                                "fallbacks": "lucida grande",
                                "spriteIndex": 50,
                                "cssFontFamily": "\"lucida sans unicode\",\"lucida grande\",sans-serif"
                            },
                            {
                                "displayName": "Marck Script",
                                "fontFamily": "marck script",
                                "cdnName": "Marck+Script",
                                "genericFamily": "cursive",
                                "provider": "google",
                                "characterSets": [
                                    "latin",
                                    "latin-ext",
                                    "cyrillic"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 51,
                                "cssFontFamily": "\"marck script\",cursive"
                            },
                            {
                                "displayName": "Marzo",
                                "fontFamily": "marzo-w00-regular",
                                "cdnName": "",
                                "genericFamily": "fantasy",
                                "provider": "monotype",
                                "characterSets": [
                                    "latin"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 116,
                                "cssFontFamily": "marzo-w00-regular,fantasy"
                            },
                            {
                                "displayName": "Monoton",
                                "fontFamily": "monoton",
                                "cdnName": "Monoton",
                                "genericFamily": "fantasy",
                                "provider": "google",
                                "characterSets": [
                                    "latin",
                                    "latin-ext"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 144,
                                "cssFontFamily": "monoton,fantasy"
                            },
                            {
                                "displayName": "Mr De Haviland",
                                "fontFamily": "mr de haviland",
                                "cdnName": "Mr+De+Haviland",
                                "genericFamily": "cursive",
                                "provider": "google",
                                "characterSets": [
                                    "latin"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 57,
                                "cssFontFamily": "\"mr de haviland\",cursive"
                            },
                            {
                                "displayName": "Museo",
                                "fontFamily": "museo-w01-700",
                                "cdnName": "",
                                "genericFamily": "serif",
                                "provider": "monotype",
                                "characterSets": [
                                    "latin"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 140,
                                "cssFontFamily": "museo-w01-700,serif"
                            },
                            {
                                "displayName": "Museo Slab",
                                "fontFamily": "museo-slab-w01-100",
                                "cdnName": "",
                                "genericFamily": "serif",
                                "provider": "monotype",
                                "characterSets": [
                                    "latin"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 141,
                                "cssFontFamily": "museo-slab-w01-100,serif"
                            },
                            {
                                "displayName": "Niconne",
                                "fontFamily": "niconne",
                                "cdnName": "Niconne",
                                "genericFamily": "fantasy",
                                "provider": "google",
                                "characterSets": [
                                    "latin"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 58,
                                "cssFontFamily": "niconne,fantasy"
                            },
                            {
                                "displayName": "Nimbus Sans",
                                "fontFamily": "nimbus-sans-tw01con",
                                "cdnName": "",
                                "genericFamily": "sans-serif",
                                "provider": "monotype",
                                "characterSets": [
                                    "latin"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 132,
                                "cssFontFamily": "nimbus-sans-tw01con,sans-serif"
                            },
                            {
                                "displayName": "Noticia Text",
                                "fontFamily": "noticia text",
                                "cdnName": "Noticia+Text",
                                "genericFamily": "serif",
                                "provider": "google",
                                "characterSets": [
                                    "latin",
                                    "latin-ext"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 59,
                                "cssFontFamily": "\"noticia text\",serif"
                            },
                            {
                                "displayName": "Open Sans",
                                "fontFamily": "open sans",
                                "cdnName": "",
                                "genericFamily": "sans-serif",
                                "provider": "open source",
                                "characterSets": [
                                    "latin",
                                    "latin-ext",
                                    "cyrillic"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 61,
                                "cssFontFamily": "\"open sans\",sans-serif"
                            },
                            {
                                "displayName": "Open Sans Condensed",
                                "fontFamily": "open sans condensed",
                                "cdnName": "Open+Sans+Condensed:300",
                                "genericFamily": "sans-serif",
                                "provider": "google",
                                "characterSets": [
                                    "latin",
                                    "latin-ext",
                                    "cyrillic"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 151,
                                "cssFontFamily": "\"open sans condensed\",sans-serif"
                            },
                            {
                                "displayName": "Overlock",
                                "fontFamily": "overlock",
                                "cdnName": "Overlock",
                                "genericFamily": "sans-serif",
                                "provider": "google",
                                "characterSets": [
                                    "latin"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 64,
                                "cssFontFamily": "overlock,sans-serif"
                            },
                            {
                                "displayName": "Pacifica Condensed",
                                "fontFamily": "pacifica-w00-condensed",
                                "cdnName": "",
                                "genericFamily": "fantasy",
                                "provider": "monotype",
                                "characterSets": [
                                    "latin"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 114,
                                "cssFontFamily": "pacifica-w00-condensed,fantasy"
                            },
                            {
                                "displayName": "Palatino Linotype",
                                "fontFamily": "palatino linotype",
                                "cdnName": "",
                                "genericFamily": "serif",
                                "provider": "system",
                                "characterSets": [
                                    "latin",
                                    "latin-ext"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 65,
                                "cssFontFamily": "\"palatino linotype\",serif"
                            },
                            {
                                "displayName": "Patrick Hand",
                                "fontFamily": "patrick hand",
                                "cdnName": "Patrick+Hand",
                                "genericFamily": "cursive",
                                "provider": "google",
                                "characterSets": [
                                    "latin",
                                    "latin-ext"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 67,
                                "cssFontFamily": "\"patrick hand\",cursive"
                            },
                            {
                                "displayName": "Play",
                                "fontFamily": "play",
                                "cdnName": "Play",
                                "genericFamily": "sans-serif",
                                "provider": "google",
                                "characterSets": [
                                    "latin",
                                    "latin-ext",
                                    "cyrillic"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 69,
                                "cssFontFamily": "play,sans-serif"
                            },
                            {
                                "displayName": "Raleway",
                                "fontFamily": "raleway",
                                "cdnName": "Raleway",
                                "genericFamily": "sans-serif",
                                "provider": "google",
                                "characterSets": [
                                    "latin"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 150,
                                "cssFontFamily": "raleway,sans-serif"
                            },
                            {
                                "displayName": "Reklame Script",
                                "fontFamily": "reklamescriptw00-medium",
                                "cdnName": "",
                                "genericFamily": "cursive",
                                "provider": "monotype",
                                "characterSets": [
                                    "latin",
                                    "latin-ext"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 118,
                                "cssFontFamily": "reklamescriptw00-medium,cursive"
                            },
                            {
                                "displayName": "Rosewood",
                                "fontFamily": "rosewood-w01-regular",
                                "cdnName": "",
                                "genericFamily": "sans-serif",
                                "provider": "monotype",
                                "characterSets": [
                                    "latin"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 157,
                                "cssFontFamily": "rosewood-w01-regular,sans-serif"
                            },
                            {
                                "displayName": "Sacramento",
                                "fontFamily": "sacramento",
                                "cdnName": "Sacramento",
                                "genericFamily": "cursive",
                                "provider": "google",
                                "characterSets": [
                                    "latin",
                                    "latin-ext"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 146,
                                "cssFontFamily": "sacramento,cursive"
                            },
                            {
                                "displayName": "Sarina",
                                "fontFamily": "sarina",
                                "cdnName": "Sarina",
                                "genericFamily": "cursive",
                                "provider": "google",
                                "characterSets": [
                                    "latin",
                                    "latin-ext"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 72,
                                "cssFontFamily": "sarina,cursive"
                            },
                            {
                                "displayName": "Signika",
                                "fontFamily": "signika",
                                "cdnName": "Signika",
                                "genericFamily": "sans-serif",
                                "provider": "google",
                                "characterSets": [
                                    "latin",
                                    "latin-ext"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 74,
                                "cssFontFamily": "signika,sans-serif"
                            },
                            {
                                "displayName": "Snell Roundhand",
                                "fontFamily": "snellroundhandw01-scrip",
                                "cdnName": "",
                                "genericFamily": "cursive",
                                "provider": "monotype",
                                "characterSets": [
                                    "latin"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 120,
                                "cssFontFamily": "snellroundhandw01-scrip,cursive"
                            },
                            {
                                "displayName": "Soho Condensed",
                                "fontFamily": "soho-w01-thin-condensed",
                                "cdnName": "",
                                "genericFamily": "serif",
                                "provider": "monotype",
                                "characterSets": [
                                    "latin",
                                    "latin-ext"
                                ],
                                "permissions": "all",
                                "fallbacks": "soho-w02-thin-condensed",
                                "spriteIndex": 133,
                                "cssFontFamily": "soho-w01-thin-condensed,soho-w02-thin-condensed,serif"
                            },
                            {
                                "displayName": "Spinnaker",
                                "fontFamily": "spinnaker",
                                "cdnName": "Spinnaker",
                                "genericFamily": "sans-serif",
                                "provider": "google",
                                "characterSets": [
                                    "latin"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 76,
                                "cssFontFamily": "spinnaker,sans-serif"
                            },
                            {
                                "displayName": "Stencil",
                                "fontFamily": "stencil-w01-bold",
                                "cdnName": "",
                                "genericFamily": "fantasy",
                                "provider": "monotype",
                                "characterSets": [
                                    "latin"
                                ],
                                "permissions": "all",
                                "fallbacks": "",
                                "spriteIndex": 110,
                                "cssFontFamily": "stencil-w01-bold,fantasy"
                            },
                            {
                                "displayName": "Tahoma",
                                "fontFamily": "tahoma",
                                "cdnName": "",
                                "genericFamily": "sans-serif",
                                "provider": "system",
                                "characterSets": [
                                    "latin",
                                    "latin-ext",
                                    "hebrew",
                                    "arabic"
                                ],
                                "permissions": "all",
                                "fallbacks": "tahoma-w01-regular,tahoma-w02-regular,tahoma-w10-regular,tahoma-w15--regular,tahoma-w99-regular",
                                "spriteIndex": 77,
                                "cssFontFamily": "tahoma,tahoma-w01-regular,tahoma-w02-regular,tahoma-w10-regular,tahoma-w15--regular,tahoma-w99-regular,sans-serif"
                            },
                            {
                                "displayName": "Times New Roman",
                                "fontFamily": "times new roman",
                                "cdnName": "",
                                "genericFamily": "serif",
                                "provider": "system",
                                "characterSets": [
                                    "latin",
                                    "latin-ext",
                                    "cyrillic",
                                    "hebrew",
                                    "arabic"
                                ],
                                "permissions": "all",
                                "fallbacks": "times",
                                "spriteIndex": 81,
                                "cssFontFamily": "\"times new roman\",times,serif"
                            },
                            {
                                "displayName": "Verdana",
                                "fontFamily": "verdana",
                                "cdnName": "",
                                "genericFamily": "sans-serif",
                                "provider": "system",
                                "characterSets": [
                                    "latin",
                                    "latin-ext",
                                    "cyrillic"
                                ],
                                "permissions": "all",
                                "fallbacks": "geneva",
                                "spriteIndex": 86,
                                "cssFontFamily": "verdana,geneva,sans-serif"
                            }
                        ]
                    }
                ]
            },
            "siteTextPresets": {
                "Title": {
                    "editorKey": "font_0",
                    "lineHeight": "1.4em",
                    "style": "normal",
                    "weight": "normal",
                    "size": "28px",
                    "fontFamily": "lucida sans unicode",
                    "value": "font:normal normal normal 28px/1.4em \"lucida sans unicode\",\"lucida grande\",sans-serif;"
                },
                "Menu": {
                    "editorKey": "font_1",
                    "lineHeight": "1.4em",
                    "style": "normal",
                    "weight": "bold",
                    "size": "28px",
                    "fontFamily": "mr de haviland",
                    "value": "font:normal normal bold 28px/1.4em \"mr de haviland\",cursive;"
                },
                "Page-title": {
                    "editorKey": "font_2",
                    "lineHeight": "1.4em",
                    "style": "normal",
                    "weight": "normal",
                    "size": "63px",
                    "fontFamily": "mr de haviland",
                    "value": "font:normal normal normal 63px/1.4em \"mr de haviland\",cursive;"
                },
                "Heading-XL": {
                    "editorKey": "font_3",
                    "lineHeight": "1.4em",
                    "style": "normal",
                    "weight": "normal",
                    "size": "60px",
                    "fontFamily": "signika",
                    "value": "font:normal normal normal 60px/1.4em signika,sans-serif;"
                },
                "Heading-L": {
                    "editorKey": "font_4",
                    "lineHeight": "1.4em",
                    "style": "normal",
                    "weight": "normal",
                    "size": "40px",
                    "fontFamily": "mr de haviland",
                    "value": "font:normal normal normal 40px/1.4em \"mr de haviland\",cursive;"
                },
                "Heading-M": {
                    "editorKey": "font_5",
                    "lineHeight": "1.4em",
                    "style": "normal",
                    "weight": "normal",
                    "size": "29px",
                    "fontFamily": "signika",
                    "value": "font:normal normal normal 29px/1.4em signika,sans-serif;"
                },
                "Heading-S": {
                    "editorKey": "font_6",
                    "lineHeight": "1.4em",
                    "style": "normal",
                    "weight": "normal",
                    "size": "26px",
                    "fontFamily": "signika",
                    "value": "font:normal normal normal 26px/1.4em signika,sans-serif;"
                },
                "Body-L": {
                    "editorKey": "font_7",
                    "lineHeight": "1.4em",
                    "style": "normal",
                    "weight": "normal",
                    "size": "16px",
                    "fontFamily": "signika",
                    "value": "font:normal normal normal 16px/1.4em signika,sans-serif;"
                },
                "Body-M": {
                    "editorKey": "font_8",
                    "lineHeight": "1.4em",
                    "style": "normal",
                    "weight": "normal",
                    "size": "13px",
                    "fontFamily": "signika",
                    "value": "font:normal normal normal 13px/1.4em signika,sans-serif;"
                },
                "Body-S": {
                    "editorKey": "font_9",
                    "lineHeight": "1.4em",
                    "style": "normal",
                    "weight": "normal",
                    "size": "12px",
                    "fontFamily": "signika",
                    "value": "font:normal normal normal 12px/1.4em signika,sans-serif;"
                },
                "Body-XS": {
                    "editorKey": "font_10",
                    "lineHeight": "1.4em",
                    "style": "normal",
                    "weight": "normal",
                    "size": "10px",
                    "fontFamily": "signika",
                    "value": "font:normal normal normal 10px/1.4em signika,sans-serif;"
                }
            },
            "siteColors": [
                {
                    "name": "color_1",
                    "value": "#FFFFFF"
                },
                {
                    "name": "color_2",
                    "value": "#000000"
                },
                {
                    "name": "color_3",
                    "value": "#FFCB05"
                },
                {
                    "name": "color_4",
                    "value": "#0088CB"
                },
                {
                    "name": "color_5",
                    "value": "#ED1C24"
                },
                {
                    "name": "color_11",
                    "value": "#FFFFFF"
                },
                {
                    "name": "color_12",
                    "value": "#999999"
                },
                {
                    "name": "color_13",
                    "value": "#666666"
                },
                {
                    "name": "color_14",
                    "value": "#333333"
                },
                {
                    "name": "color_15",
                    "value": "#000000"
                },
                {
                    "name": "color_16",
                    "value": "#D5D3D1"
                },
                {
                    "name": "color_17",
                    "value": "#ABA9A6"
                },
                {
                    "name": "color_18",
                    "value": "#827E7A"
                },
                {
                    "name": "color_19",
                    "value": "#565451"
                },
                {
                    "name": "color_20",
                    "value": "#2B2A28"
                },
                {
                    "name": "color_21",
                    "value": "#F4C3B1"
                },
                {
                    "name": "color_22",
                    "value": "#EAA389"
                },
                {
                    "name": "color_23",
                    "value": "#E05726"
                },
                {
                    "name": "color_24",
                    "value": "#953A19"
                },
                {
                    "name": "color_25",
                    "value": "#4A1D0C"
                },
                {
                    "name": "color_26",
                    "value": "#C7CCD2"
                },
                {
                    "name": "color_27",
                    "value": "#999FA6"
                },
                {
                    "name": "color_28",
                    "value": "#666F7A"
                },
                {
                    "name": "color_29",
                    "value": "#444A51"
                },
                {
                    "name": "color_30",
                    "value": "#222528"
                },
                {
                    "name": "color_31",
                    "value": "#FFEADA"
                },
                {
                    "name": "color_32",
                    "value": "#FFD5B5"
                },
                {
                    "name": "color_33",
                    "value": "#BF9F87"
                },
                {
                    "name": "color_34",
                    "value": "#7F6A5A"
                },
                {
                    "name": "color_35",
                    "value": "#3F352D"
                }
            ],
            "style": {
                "colors": {
                    "wix-param-color": {
                        "themeName": "color_21",
                        "value": "#F4C3B1"
                    },
                    "wix-param-color-opac": {
                        "value": "rgba(203,85,85,0.4)"
                    }
                },
                "numbers": {
                    "wix-param-number": 1
                },
                "booleans": {},
                "fonts": {
                    "wix-param-fonttt": {
                        "size": 16,
                        "style": {
                            "bold": false,
                            "italic": false,
                            "underline": false
                        },
                        "family": "arial",
                        "cssFontFamily": "'arial','ｍｓ ｐゴシック','ms pgothic','돋움','dotum','helvetica','sans-serif'",
                        "preset": "Custom",
                        "fontStyleParam": true,
                        "value": "font:normal normal normal 16px/20px arial,\"ｍｓ ｐゴシック\",\"ms pgothic\",\"돋움\",dotum,helvetica,sans-serif;"
                    }
                },
                "googleFontsCssUrl": "//fonts.googleapis.com/css?family=Mr+De+Haviland:n,b,i,bi|Signika:n,b,i,bi|&subset=latin"
            }
        };
    };
});
