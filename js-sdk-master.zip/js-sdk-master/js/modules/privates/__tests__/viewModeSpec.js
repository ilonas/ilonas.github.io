var postMessage = require('privates/postMessage');
var urlUtils = require('privates/urlUtils');
var viewMode = require('privates/viewMode');

describe('view mode', function () {
    it('should return the query param viewMode if has no local param', function () {
        var getQueryParameter = 'getQueryParameter';
        spyOn(urlUtils, 'getQueryParameter').and.returnValue(getQueryParameter);
        expect(viewMode.getViewModeInternal()).toBe(getQueryParameter);
    });

    it('should return the local viewMode if has one', function () {
        var editMode = 'editMode';
        spyOn(urlUtils, 'getQueryParameter').and.returnValue('queryParamEditMode');
        spyOn(postMessage, 'addEventListenerInternal');
        spyOn(postMessage, 'sendMessage').and.callFake(function (msg, n, data, cb) {
            cb({editMode: editMode})
        });
        viewMode.init();
        expect(viewMode.getViewModeInternal()).toBe(editMode);
    });
});