var postMessage = require('privates/postMessage');
var urlUtils = require('privates/urlUtils');
var currentEditMode;

var getViewMode = () => {
    return (window.top === window) ? 'standalone' :  getViewModeInternal();
};

var getViewModeInternal = () => {
    return currentEditMode || urlUtils.getQueryParameter('viewMode');
};

var setViewModeFromHandler = () => {
    postMessage.sendMessage(postMessage.MessageTypes.GET_VIEW_MODE, undefined, {}, (params) => {
        currentEditMode = params && params.editMode;
    });
};

var init = () => {
    // initialize edit mode state tracking
    postMessage.addEventListenerInternal('EDIT_MODE_CHANGE', undefined, function(params) {
        currentEditMode = params.editMode;
    });

    setViewModeFromHandler();
};

module.exports = {
    init: init,
    getViewMode: getViewMode,
    getViewModeInternal
};