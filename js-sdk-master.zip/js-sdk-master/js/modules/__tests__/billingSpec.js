define(['Billing', 'privates/postMessage', 'privates/reporter', 'privates/sharedAPI'], function(Billing, postMessage, reporter, sharedAPI) {

    describe('Billing', function () {

        beforeEach(function () {
            spyOn(reporter, 'reportSdkError');
            spyOn(postMessage, 'sendMessage');
            this.onSuccessSpy = jasmine.createSpy('onSuccess');
            this.onErrorSpy = jasmine.createSpy('onError');
        });

        describe('openBillingPageForProduct', function () {
            it('should report error when productVendorId was not provided', function () {
                Billing.openBillingPageForProduct();

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - vendorProductId must be a string');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error when cycle was not provided', function () {
                Billing.openBillingPageForProduct('1002');

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - cycle must be one of Wix.Billing.Cycle');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error when cycle was not a valid value', function () {
                Billing.openBillingPageForProduct('1002', 'foo');

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - cycle must be one of Wix.Billing.Cycle');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should sent proper message when API parameters are valid', function () {
                Billing.openBillingPageForProduct('1002', Billing.Cycle.YEARLY, function () {});
                var args = {
                    vendorProductId: '1002',
                    cycle: Billing.Cycle.YEARLY
                };

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.OPEN_BILLING_PAGE_FOR_PRODUCT, 'Billing', args, jasmine.any(Function));
            });
        });

        describe('getBillingPageForProduct', function () {
            it('should report error when productVendorId was not provided', function () {
                Billing.getBillingPageForProduct();

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - vendorProductId must be a string');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error when cycle was not provided', function () {
                Billing.getBillingPageForProduct('1002');

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - cycle must be one of Wix.Billing.Cycle');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error when cycle was not a valid value', function () {
                Billing.getBillingPageForProduct('1002', 'foo');

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - cycle must be one of Wix.Billing.Cycle');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error when onSuccess was not provided', function () {
                Billing.getBillingPageForProduct('1002', Billing.Cycle.YEARLY);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - onSuccess must be a function');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should sent proper message when API parameters are valid', function () {
                Billing.getBillingPageForProduct('1002', Billing.Cycle.YEARLY, function () {});
                var args = {
                    vendorProductId: '1002',
                    cycle: Billing.Cycle.YEARLY
                };

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_BILLING_PAGE_FOR_PRODUCT, 'Billing', args, jasmine.any(Function));
            });
        });

        describe('getBillingPackages', function () {
            it('should report error when onSuccess was not provided', function () {
                Billing.getBillingPackages();

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - onSuccess must be a function');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });


            it('should sent proper message when API parameters are valid and vendor product ids was not given', function () {
                Billing.getBillingPackages(function () {});

                var args = {
                    vendorProductIds: undefined
                };

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_BILLING_PACKAGES, 'Billing', args, jasmine.any(Function));
            });

            it('should sent proper message when API parameters are valid and vendor product ids was given', function () {
                Billing.getBillingPackages(['foo'], function () {});

                var args = {
                    vendorProductIds: ['foo']
                };

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_BILLING_PACKAGES, 'Billing', args, jasmine.any(Function));
            });
        });

        describe('getProducts', function () {

            beforeEach(function () {
                spyOn(sharedAPI, 'getProducts').and.callThrough();
            });

            it('should call sharedAPI.getProducts with all params', function () {
                Billing.getProducts({currency: 'USD'}, this.onSuccessSpy, this.onErrorSpy);

                expect(sharedAPI.getProducts).toHaveBeenCalledWith('Billing', {currency: 'USD'}, this.onSuccessSpy, this.onErrorSpy);
            });

        });
    });
});
