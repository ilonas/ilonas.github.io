define(['Features', 'privates/reporter', 'privates/postMessage'], function (features, reporter, postMessage) {
    'use strict';

    describe('Features', function () {

        beforeEach(function () {
            spyOn(reporter, 'reportSdkError');
            spyOn(postMessage, 'sendMessage');
        });

        it('should not do a post message when feature name and callback are not given and report an error', function () {
            features.isSupported();
            expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory arguments - feature name and callback must be supplied.');
            expect(postMessage.sendMessage).not.toHaveBeenCalled();
        });

        it('should not do a post message when callback is not provided', function () {
            features.isSupported('PREVIEW_TO_SETTINGS');
            expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory argument - callback must be supplied.');
            expect(postMessage.sendMessage).not.toHaveBeenCalled();
        });

        it('should not do a post message when callback is not a function', function () {
            features.isSupported('PREVIEW_TO_SETTINGS', 'ahdahsdasd');
            expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory argument - callback must be a function.');
            expect(postMessage.sendMessage).not.toHaveBeenCalled();
        });


        it('should not do a post message when feature name is not provided', function () {
            features.isSupported(function(){});
            expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory argument - feature name must be supplied.');
            expect(postMessage.sendMessage).not.toHaveBeenCalled();
        });

        it('should not do a post message when feature name is not valid', function () {
            features.isSupported('dsds', function() {});
            expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory argument - feature must be one of Wix.Features.Types.');
            expect(postMessage.sendMessage).not.toHaveBeenCalled();
        });

        it('should do a post message when callback and featureName is given and valid', function () {
            var callback = jasmine.createSpy();
            var data = {
                name: 'PREVIEW_TO_SETTINGS'
            };

            features.isSupported('PREVIEW_TO_SETTINGS', callback);
            expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.IS_SUPPORTED, 'Features', data, jasmine.any(Function));
        });
    });
});
