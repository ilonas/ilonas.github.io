define(['Settings', 'Styles', 'Base', 'privates/reporter', 'privates/postMessage', 'privates/sharedAPI', 'privates/viewMode'], function (Settings, Styles, Base, reporter, postMessage, sharedAPI, viewMode) {
    'use strict';
    describe('Settings', function () {
        var namespace = 'Settings';

        var postMessageSpy;
        beforeEach(function () {
            spyOn(reporter, 'reportSdkError');
            postMessageSpy = spyOn(postMessage, 'sendMessage');
        });

        describe('getDashboardAppUrl', function () {
            it('should call Wix.Settings.getDashboardAppUrl without callback and throw error', function() {
                Settings.getDashboardAppUrl();

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory arguments - a callback must be specified');
            });

            it('should send the proper message when input is valid', function() {
                var callback = function () {};
                Settings.getDashboardAppUrl(callback);

                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_DASHBOARD_APP_URL, 'Settings', undefined, callback);
            });
        });

        describe('openModal', function () {
            it('should call shared api open modal', function () {
                spyOn(sharedAPI, 'openModal');

                Settings.openModal('http://www.haxs0r.com', 100, 100, 'Testing title in modal');
                expect(sharedAPI.openModal).toHaveBeenCalledWith('Settings', 'http://www.haxs0r.com', 100, 100, 'Testing title in modal', undefined, undefined);
            });

            it('should call shared api open modal w/ onClose and isBareMode', function () {
                spyOn(sharedAPI, 'openModal');

                Settings.openModal('http://www.haxs0r.com', 100, 100, 'Testing title in modal', function() {}, true);
                expect(sharedAPI.openModal).toHaveBeenCalledWith('Settings', 'http://www.haxs0r.com', 100, 100, 'Testing title in modal', jasmine.any(Function), true);
            });
        });

        describe('close Window', function () {
            it('should call Base.closeWindow', function () {
                spyOn(sharedAPI, 'closeWindow');

                Settings.closeWindow();
                expect(sharedAPI.closeWindow).toHaveBeenCalled();
            });
        });

        describe('openMediaDialog', function () {
            it('should call the shared api openMediaDialog function with correct message', function () {
                spyOn(sharedAPI, 'openMediaDialog');
                var error = jasmine.createSpy();
                var success = jasmine.createSpy();

                Settings.openMediaDialog(Settings.MediaType.SECURE_MUSIC, false, success, error);

                expect(sharedAPI.openMediaDialog.calls.argsFor(0)[0]).toEqual(postMessage.MessageTypes.OPEN_MEDIA_DIALOG);
            });

            it('should call the shared api openMediaDialog function with supported media types', function () {
                spyOn(sharedAPI, 'openMediaDialog');
                var error = jasmine.createSpy();
                var success = jasmine.createSpy();

                Settings.openMediaDialog(Settings.MediaType.SECURE_MUSIC, false, success, error);

                expect(sharedAPI.openMediaDialog.calls.argsFor(0)[2]).toEqual(Settings.MediaType);
            });
        });

        describe('resizeComponent', function () {
            it('should validate options object', function () {
                Settings.resizeComponent();

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory arguments - width or height must be supplied');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should sent proper message when API parameters are valid', function () {
                Settings.resizeComponent({
                    height: 'bar'
                });

                var args = {
                    height: 'bar'
                };

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.RESIZE_COMPONENT, 'Settings', args, jasmine.any(Function));
            });

            it('should sent proper message when API parameters are valid', function () {
                Settings.resizeComponent({
                    width: 'bar'
                });

                var args = {
                    width: 'bar'
                };

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.RESIZE_COMPONENT, 'Settings', args, jasmine.any(Function));
            });

            it('should not brake if onSuccess is not given', function () {
                var args = {
                    width: 100
                };

                Settings.resizeComponent({
                    width: 100
                });

                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.RESIZE_COMPONENT, 'Settings', args, jasmine.any(Function));
            });

            it('should call onSuccess callback when input is valid', function () {
                var cb = jasmine.createSpy('cb');
                postMessageSpy.and.callFake(function (m, n, args , callback) {
                    return callback({
                        width: 100
                    });
                });

                Settings.resizeComponent({
                    width: 100
                }, cb);

                expect(cb).toHaveBeenCalledWith({
                    width: 100
                });
            });

            it('should call onError callback when editor retuns an error', function () {
                var cb = jasmine.createSpy('cb');
                var onError = jasmine.createSpy('onError');
                postMessageSpy.and.callFake(function (m, n, args , callback) {
                    return callback({
                        onError: {
                            message: 'error'
                        }
                    });
                });

                Settings.resizeComponent({
                    width: 100
                }, cb, onError);

                expect(cb).not.toHaveBeenCalledWith({
                    width: 100
                });

                expect(onError).toHaveBeenCalledWith({
                    onError : {
                        message : 'error'
                    }
                });
            });
        });

        describe('add components', function () {
            it('should validate options object', function () {
                Settings.addComponent();

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory arguments - options has to have componentType');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should validate options object has componentType', function () {
                Settings.addComponent({
                    foo: 'bar'
                });

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory arguments - options has to have componentType');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should validate options object has widget object when componentType is WIDGET', function () {
                Settings.addComponent({
                    componentType: 'WIDGET'
                });

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory arguments - options has to have widget object');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should validate options object has page object when componentType is PAGE', function () {
                Settings.addComponent({
                    componentType: 'PAGE'
                });

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory arguments - options has to have page object');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should validate options object copyStyle propery is boolean', function () {
                Settings.addComponent({
                    componentType: 'PAGE',
                    copyStyle: 'str',
                    page: {
                        pageId : 'pageId'
                    }
                });

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - copyStyle should be of type Boolean');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should sent proper message when API parameters are valid for adding a widget', function () {
                var args = {
                    componentType: 'WIDGET',
                    widget : {
                        tpaWidgetId : 'my-widget-id',
                        allPages : false,
                        wixPageId : undefined
                    }
                };

                Settings.addComponent({
                    componentType: 'WIDGET',
                    widget: {
                        widgetId: 'my-widget-id'
                    }
                });
                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.ADD_COMPONENT, 'Settings', args, jasmine.any(Function));
            });

            it('should sent proper message when API parameters are valid for adding a page', function () {
                var args = {
                    componentType: 'PAGE',
                    copyStyle: true,
                    styleId: '1234',
                    page : {
                        pageId : 'pageId',
                        title : undefined
                    }
                };

                Settings.addComponent({
                    componentType: 'PAGE',
                    copyStyle: true,
                    styleId: '1234',
                    page: {
                        pageId : 'pageId'
                    }
                });

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.ADD_COMPONENT, 'Settings', args, jasmine.any(Function));
            });
        });

        describe('setExternalId', function () {
            it('must provide a GUID value', function () {
                Settings.setExternalId();

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory arguments - GUID must be provided');
            });

            it('should call a message with the proper values', function () {
                var args = {
                    externalId: 'value'
                };

                Settings.setExternalId('value');

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SET_EXTERNAL_ID, 'Settings', args, jasmine.any(Function));
            });
        });

        describe('revalidateSession', function() {
            it('should call a message with the proper values', function () {
                Settings.revalidateSession(function(){});
                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.REVALIDATE_SESSION, 'Settings', {}, jasmine.any(Function));
            });

            it('should report error when onSuccess is not supplied', function () {
                Settings.revalidateSession();
                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing Mandatory argument - onSuccess');
                expect(postMessage.sendMessage).not.toHaveBeenCalledWith(postMessage.MessageTypes.REVALIDATE_SESSION, 'Settings', {}, jasmine.any(Function));
            });

            it('should report error when onSuccess is not a function', function () {
                Settings.revalidateSession('onSuccess');
                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory argument - onSuccess - should be of type Function');
                expect(postMessage.sendMessage).not.toHaveBeenCalledWith(postMessage.MessageTypes.REVALIDATE_SESSION, 'Settings', {}, jasmine.any(Function));
            });
        });

        describe('setFullWidth', () => {
            it('should not post message when shouldBeFullWidth is not given', () => {
                Settings.setFullWidth();
                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory argument - shouldBeFullWidth - should be of type Boolean');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should post message when shouldBeFullWidth is given', () => {
                Settings.setFullWidth(true, {
                    margins: {
                        left: '10px',
                        right: '20px'
                    }
                });
                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SET_FULL_WIDTH, 'Settings', {
                    stretch: true,
                    margins: {
                        left: '10px',
                        right: '20px'
                    }
                }, jasmine.any(Function));
            });

            it('should post message when shouldBeFullWidth is given and convert % to vw', () => {
                Settings.setFullWidth(true, {
                    margins: {
                        left: '10%',
                        right: '20%'
                    }
                });
                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SET_FULL_WIDTH, 'Settings', {
                    stretch: true,
                    margins: {
                        left: '10vw',
                        right: '20vw'
                    }
                }, jasmine.any(Function));
            });

            it('should call onSuccess callback if post message succeeded', function (){
                postMessageSpy.and.callFake(function (m, n, args , callback) {
                    return callback({});
                });
                var onSuccessSpy = jasmine.createSpy('onSuccess');
                Settings.setFullWidth(true, {} , onSuccessSpy);
                expect(onSuccessSpy).toHaveBeenCalled();
            });

            it('should call onSuccess callback if post message succeeded but no data was given from the post message', function (){
                postMessageSpy.and.callFake(function (m, n, args , callback) {
                    return callback();
                });
                var onSuccessSpy = jasmine.createSpy('onSuccess');
                Settings.setFullWidth(true, {} , onSuccessSpy);
                expect(onSuccessSpy).toHaveBeenCalled();
            });

            it('should call onError callback if post message failed', function (){
                postMessageSpy.and.callFake(function (m, n, args , callback) {
                    return callback({
                        onError: 'error'
                    });
                });
                var onErrorSpy = jasmine.createSpy('onError');
                Settings.setFullWidth(true, {} , function(){}, onErrorSpy);
                expect(onErrorSpy).toHaveBeenCalled();
            });
        });

        describe('isFullWidth', () => {
            it('should validate a callback was given', () => {
                Settings.isFullWidth();
                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory arguments - a callback must be specified');
            });

            it('should post message when callback is given', () => {
                var callbackSpy = jasmine.createSpy('callbackSpy');
                Settings.isFullWidth(callbackSpy);
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.IS_FULL_WIDTH, 'Settings', undefined, jasmine.any(Function));
            });
        });

        describe('openReviewInfo', function() {
            it('should call a message with the proper values', function(){
                Settings.openReviewInfo();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.OPEN_REVIEW_INFO, 'Settings');
            });
        });

        describe('openSiteMembersSettingsDialog', function() {
            it('should call a message with the proper values', function(){
                Settings.openSiteMembersSettingsDialog();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.OPEN_SITE_MEMBERS_SETTINGS_DIALOG, 'Settings');
            });
        });

        describe('refreshApp', function () {
            it('should call a message with the proper values', function () {
                var queryParams = {};
                Settings.refreshApp(queryParams);
                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.REFRESH_APP, 'Settings', {queryParams});
            });
        });

        describe('refreshAppByCompIds', function () {
            it('should call a message with the proper values', function () {
                var queryParams = {};
                var compIds = [];
                Settings.refreshAppByCompIds(compIds, queryParams);
                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.REFRESH_APP, 'Settings', {queryParams, compIds});
            });
        });

        describe('isComponentInstalled', function () {

            it('should report error if componentId is not passed', function () {
                Settings.isComponentInstalled();

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - componentId - should be a non empty String');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error if componentId is not a string', function () {
                Settings.isComponentInstalled({});

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - componentId - should be a non empty String');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error if componentId is an empty string', function () {
                Settings.isComponentInstalled('');

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - componentId - should be a non empty String');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error if callback is not passed', function () {
                Settings.isComponentInstalled('id');

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - callback - should be of type Function');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error if callback is not a function', function () {
                Settings.isComponentInstalled('id', 1);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - callback - should be of type Function');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should send post message if componentId is valid ', function () {
                Settings.isComponentInstalled('id', function(){});

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.IS_COMPONENT_INSTALLED, 'Settings', {componentId: 'id'}, jasmine.any(Function));
            });

            it('should call callback with the response', function (done) {
                postMessage.sendMessage.and.callFake(function (msgType, namespace, options, callback) {
                    return callback(true);
                });

                Settings.isComponentInstalled('id', function (data) {
                    expect(data).toEqual(true);
                    done();
                });
            });

        });

        describe('openLinkPanel', function () {
            var successSpy = jasmine.createSpy('onSuccess');
            var errorSpy = jasmine.createSpy('onCancel');

            describe('when options is the first param', function () {

                it('should return an error if onSuccess is not passed', function () {
                    Settings.openLinkPanel({link: {}});

                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - onSuccess - should be of type Function');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should return an error if onCacnel is not a function', function () {
                    Settings.openLinkPanel({link: {}}, successSpy, 1);

                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - onCacnel - should be of type Function');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should send message if params are valid', function () {
                    Settings.openLinkPanel({link: {type: 'page'}}, successSpy, errorSpy);

                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.OPEN_LINK_PANEL, 'Settings', {
                        link: {type: 'page'}
                    }, jasmine.any(Function));
                });

                it('should call the onSuccess callback with the link data', function (done) {
                    postMessage.sendMessage.and.callFake(function (msgType, namespace, options, callback) {
                        return callback({
                            type: 'page'
                        });
                    });

                    Settings.openLinkPanel({link: {type: 'page'}}, function (data) {
                        expect(data).toEqual({
                            type: 'page'
                        });
                        done();
                    }, errorSpy);
                });

                it('should call onCacnel callback when editor retuns cancel', function (done) {
                    postMessageSpy.and.callFake(function (m, n, args, callback) {
                        return callback({
                            onCacnel: true
                        });
                    });

                    Settings.openLinkPanel({link: {type: 'page'}}, successSpy, function (data) {
                        expect(data).toEqual({
                            onCacnel: true
                        });
                        done();
                    });
                });
            });

            describe('when onSuccess is the first param', function(){
                it('should return an error if onCacnel is not a function', function () {
                    Settings.openLinkPanel(successSpy, 1);

                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - onCacnel - should be of type Function');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should send message if params are valid', function () {
                    Settings.openLinkPanel(successSpy, errorSpy);

                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.OPEN_LINK_PANEL, 'Settings', {}, jasmine.any(Function));
                });
            });

            it('should return error if first param is not passed', function(){
                Settings.openLinkPanel();

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - first argument should be of type Object or Function');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should return error if first param is null', function(){
                Settings.openLinkPanel(null);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - first argument should be of type Object or Function');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });
        });

        describe('openBillingPage', function () {

            it('should send post message if no arguments were given', function () {
                Settings.openBillingPage();

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.OPEN_BILLING_PAGE, 'Settings', {});
            });

            it('should report error if options.premiumIntent is not a string', function () {
                Settings.openBillingPage({premiumIntent: 123});

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Unsupported premiumIntent - 123 - should be one of Wix.Settings.PremiumIntent');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error if options.premiumIntent is not a one of the enum options', function () {
                Settings.openBillingPage({premiumIntent: 'unknown'});

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Unsupported premiumIntent - unknown - should be one of Wix.Settings.PremiumIntent');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should send post message options.premiumIntent was given', function () {
                Settings.openBillingPage({premiumIntent: Settings.PremiumIntent.NEUTRAL});

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.OPEN_BILLING_PAGE, 'Settings', {premiumIntent: Settings.PremiumIntent.NEUTRAL});
            });
        });

        describe('appEngaged', function () {

            it('should report error if premiumIntent is not given', function () {
                Settings.appEngaged();

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - premiumIntent - should be one of Wix.Settings.PremiumIntent');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error if premiumIntent is not a string', function () {
                Settings.appEngaged(123);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - premiumIntent - should be one of Wix.Settings.PremiumIntent');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error if premiumIntent is not a one of the enum options', function () {
                Settings.appEngaged('unknown');

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - premiumIntent - should be one of Wix.Settings.PremiumIntent');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should send post message premiumIntent was given', function () {
                Settings.appEngaged(Settings.PremiumIntent.NEUTRAL);

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.APP_ENGAGED, 'Settings', {premiumIntent: Settings.PremiumIntent.NEUTRAL});
            });
        });

        describe('isApplicationInstalled', function(){

            beforeEach(function(){
                spyOn(viewMode, 'getViewMode').and.returnValue('editor');
                this.callback = jasmine.createSpy('callback');
            });

            it('should report an error if appDefinitionId is not passed', function () {
                Settings.isApplicationInstalled();

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - appDefinitionId - should be of type String');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report an error if appDefinitionId is not a string', function () {
                Settings.isApplicationInstalled(1);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - appDefinitionId - should be of type String');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report an error if callback is not passed', function () {
                Settings.isApplicationInstalled('appDefId');

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - callback - should be of type Function');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report an error if callback is not a function', function () {
                Settings.isApplicationInstalled('appDefId', 1);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - callback - should be of type Function');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should send post message if params are valid', function(){
                Settings.isApplicationInstalled('appDefId', this.callback);

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.IS_APPLICATION_INSTALLED, 'Settings', {
                    appDefinitionId: 'appDefId'
                }, this.callback);
            });
        });
    });
});
