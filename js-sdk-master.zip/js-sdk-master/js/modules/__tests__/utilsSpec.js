define(['Utils', 'Media', 'privates/postMessage', 'privates/utils', 'privates/reporter', 'privates/urlUtils', 'privates/core'],
    function (Utils, Media, postMessage, utils, reporter, urlUtils, core) {
    'use strict';

    describe('Utils tests', function () {
        var postMessageSpy,  error;
        beforeEach(function () {
            postMessageSpy = spyOn(postMessage, 'sendMessage');
            spyOn(urlUtils, 'getQueryParameter');
            spyOn(reporter, 'reportSdkError');
            spyOn(core, 'getInstanceValue');

            error = jasmine.createSpy();
        });

        describe('navigateToSection', function () {
            it('should invoke dispatcher sendMessage with the proper message name, state and given callback', function () {
                var state = "state";
                var args = {
                    state: state
                };
                Utils.navigateToSection(state, error);

                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.NAVIGATE_TO_SECTION_PAGE, 'Utils', args, error);
                expect(error).not.toHaveBeenCalled();
            });

            it('should invoke dispatcher sendMessage with the proper message name, sectionIdentifier and given callback', function () {
                var sectionIdentifier = {
                    sectionIdentifier: 'sectionIdentifier'
                };
                var args = {
                    sectionIdentifier: sectionIdentifier
                };

                Utils.navigateToSection(sectionIdentifier, error);

                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.NAVIGATE_TO_SECTION_PAGE, 'Utils', args, error);
                expect(error).not.toHaveBeenCalled();
            });

            it('should invoke dispatcher sendMessage with the proper message name, state, sectionIdentifier and given callback', function () {
                var sectionIdentifier = {
                    sectionIdentifier: 'sectionIdentifier'
                };
                var state = 'state';
                var args = {
                    state: state,
                    sectionIdentifier: sectionIdentifier
                };

                Utils.navigateToSection(sectionIdentifier, state, error);

                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.NAVIGATE_TO_SECTION_PAGE, 'Utils', args, error);
                expect(error).not.toHaveBeenCalled();
            });

            it('should invoke the callback when an error happened', function() {
                postMessageSpy.and.callFake(function (m, n, args , callback) {
                    return callback({
                        error: {
                            message: 'some error message'
                        }
                    });
                });

                var state = 'state';
                var args = {
                    state: state
                };

                Utils.navigateToSection(state, error);

                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.NAVIGATE_TO_SECTION_PAGE, 'Utils', args, error);
                expect(error).toHaveBeenCalledWith({error: { message: 'some error message' }});
            });

            it('should navigate to section when just sectionIdentifier was given', function () {
                var sectionIdentifier = {
                    sectionIdentifier: 'sectionIdentifier'
                };

                var args = {
                    sectionIdentifier: sectionIdentifier,
                    state: undefined
                };

                Utils.navigateToSection(sectionIdentifier);
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.NAVIGATE_TO_SECTION_PAGE, 'Utils', args, undefined);
            });

            it('should navigate to section when just onFailure was given', function () {
                Utils.navigateToSection(error);

                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.NAVIGATE_TO_SECTION_PAGE, 'Utils', undefined, error);
            });
        });

        describe('getSectionUrl', function () {
            it('should invoke sendMessage when sectionId and callback were given', function () {
                var callback = function () {};
                var args = {
                    sectionIdentifier: "section_id"
                };

                Utils.getSectionUrl({
                    sectionId: args.sectionIdentifier
                }, callback);

                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_SECTION_URL, 'Utils', args, callback);
            });

            it('should invoke the callback with section url', function () {
                postMessageSpy.and.callFake(function (m, n, args , callback) {
                    return callback({
                        url: 'http://section_url.com'
                    });
                });

                var callback = jasmine.createSpy();
                var args = {
                    sectionIdentifier: 'section_id'
                };

                Utils.getSectionUrl({
                    sectionId: args.sectionIdentifier
                }, callback);

                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_SECTION_URL, 'Utils', args, callback);
                expect(callback).toHaveBeenCalledWith({
                    url: 'http://section_url.com'
                });
            });

            it('should report error when sectionIdentifier was given but no callback', function () {
                var args = {
                    sectionIdentifier: "section_id"
                };

                Utils.getSectionUrl({sectionId: args.sectionIdentifier});

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory arguments - callback must be specified');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error when given sectionIdentifier has no sectionId', function () {
                var callback = function () {};
                var args = {
                    sectionIdentifier: 'section_id'
                };

                Utils.getSectionUrl({
                    foo: args.sectionIdentifier
                }, callback);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Wrong arguments - an Object with sectionId must be provided');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should retrieve the section url from query when no sectionId was given', function () {
                Utils.getSectionUrl();

                expect(urlUtils.getQueryParameter).toHaveBeenCalled();
            });

        });

        it('should get the instance value', function () {
            Utils.getInstanceValue('aaa');

            expect(core.getInstanceValue).toHaveBeenCalledWith('aaa');
        });

        it('should get compId', function () {
            Utils.getCompId();

            expect(urlUtils.getQueryParameter).toHaveBeenCalledWith('compId');
        });

        it('should get siteOwnerId', function () {
            Utils.getSiteOwnerId();
            expect(core.getInstanceValue).toHaveBeenCalledWith('siteOwnerId');
        });
    });
});