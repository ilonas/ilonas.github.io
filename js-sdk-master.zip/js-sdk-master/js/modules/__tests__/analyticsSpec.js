define(['lodash', 'Analytics', 'privates/postMessage', 'privates/reporter', 'privates/viewMode'],
    function (_, Analytics, postMessage, reporter, viewMode) {
    'use strict';

    describe('Analytics tests', function () {
        var postMessageMock;

        beforeEach(function () {
            spyOn(reporter, 'reportSdkError');
            postMessageMock = spyOn(postMessage, 'sendMessage');
        });

        describe('registerCampaignPixel', function () {
            it('should report error if view mode is not site', function () {
                spyOn(viewMode, 'getViewMode').and.returnValue('editor');

                Analytics.registerCampaignPixel();

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid view mode. This function cannot be called in editor/preview mode. Supported view mode is: [site]');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error if there is no pixel type', function () {
                spyOn(viewMode, 'getViewMode').and.returnValue('site');

                Analytics.registerCampaignPixel();

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - pixelType - should be one of Wix.Analytics.PIXEL_TYPES');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error if the pixel type is not a string', function () {
                spyOn(viewMode, 'getViewMode').and.returnValue('site');

                Analytics.registerCampaignPixel(123);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - pixelType - should be one of Wix.Analytics.PIXEL_TYPES');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error if the pixel type is unknown', function () {
                spyOn(viewMode, 'getViewMode').and.returnValue('site');

                Analytics.registerCampaignPixel('unknownPixelType');

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - pixelType - should be one of Wix.Analytics.PIXEL_TYPES');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error if pixelId param is missing', function () {
                spyOn(viewMode, 'getViewMode').and.returnValue('site');

                Analytics.registerCampaignPixel(Analytics.PixelType.FACEBOOK);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - pixelId - should be of type String, composes only digits, non empty');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error if pixelId param is not a string', function () {
                spyOn(viewMode, 'getViewMode').and.returnValue('site');

                Analytics.registerCampaignPixel(Analytics.PixelType.FACEBOOK, 123);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - pixelId - should be of type String, composes only digits, non empty');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error if pixelId param is an empty string', function () {
                spyOn(viewMode, 'getViewMode').and.returnValue('site');

                Analytics.registerCampaignPixel(Analytics.PixelType.FACEBOOK, '');

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - pixelId - should be of type String, composes only digits, non empty');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error if pixelId param is a string not composed of digits', function () {
                spyOn(viewMode, 'getViewMode').and.returnValue('site');

                Analytics.registerCampaignPixel(Analytics.PixelType.FACEBOOK, 'invalidId');

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - pixelId - should be of type String, composes only digits, non empty');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should not report error if all required parameters are there', function () {
                spyOn(viewMode, 'getViewMode').and.returnValue('site');

                Analytics.registerCampaignPixel(Analytics.PixelType.FACEBOOK, '1234567890');

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.REGISTER_CAMPAIGN_PIXEL, 'Analytics', {pixelId: '1234567890', pixelType: Analytics.PixelType.FACEBOOK});
            });
        });

        describe('reportCampaignEvent', function () {
            it('should report error if view mode is not site', function () {
                spyOn(viewMode, 'getViewMode').and.returnValue('editor');

                Analytics.reportCampaignEvent();

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid view mode. This function cannot be called in editor/preview mode. Supported view mode is: [site]');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error if there is no event type', function () {
                spyOn(viewMode, 'getViewMode').and.returnValue('site');
                Analytics.reportCampaignEvent();

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - eventType - should be one of Wix.Analytics.PixelEventType[event].eventName');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error if event type is not a string', function () {
                spyOn(viewMode, 'getViewMode').and.returnValue('site');
                Analytics.reportCampaignEvent(123);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - eventType - should be one of Wix.Analytics.PixelEventType[event].eventName');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error if event type is unknown', function () {
                spyOn(viewMode, 'getViewMode').and.returnValue('site');
                Analytics.reportCampaignEvent("unknownEvent");

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - eventType - should be one of Wix.Analytics.PixelEventType[event].eventName');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error if event type is missing required parameters (no data object)', function () {
                spyOn(viewMode, 'getViewMode').and.returnValue('site');

                Analytics.reportCampaignEvent(Analytics.PixelEventType.PURCHASE.eventName);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - value - in data object');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error if event type is missing required parameters', function () {
                spyOn(viewMode, 'getViewMode').and.returnValue('site');

                Analytics.reportCampaignEvent(Analytics.PixelEventType.PURCHASE.eventName, {value: 50});

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - currency - in data object');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should send post message if the event is known and doesn\'t require parameters', function () {
                spyOn(viewMode, 'getViewMode').and.returnValue('site');

                Analytics.reportCampaignEvent(Analytics.PixelEventType.COMPLETE_REGISTRATION.eventName);

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.REPORT_CAMPAIGN_EVENT, 'Analytics',
                    {eventName: Analytics.PixelEventType.COMPLETE_REGISTRATION.eventName});
            });

            it('should send post message if the event is known and required parameters are given', function () {
                spyOn(viewMode, 'getViewMode').and.returnValue('site');

                Analytics.reportCampaignEvent(Analytics.PixelEventType.PURCHASE.eventName, {value: 50, currency: 'USD'});

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.REPORT_CAMPAIGN_EVENT, 'Analytics',
                    {eventName: Analytics.PixelEventType.PURCHASE.eventName, value: 50, currency: 'USD'});
            });
        });
    });

});