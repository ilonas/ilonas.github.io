define(['privates/data', 'Worker'], function(data, Worker) {
    describe('Worker', function() {
        describe('public data', function() {
            var callback;
            var key = 'key';
            var keys = ['key1', 'key2'];

            beforeEach(function() {
                spyOn(data, 'get');
                spyOn(data, 'getMulti');
                callback = jasmine.createSpy('callback');
            });

            it('getValue should invoke data public get with app scope', function() {
                Worker.Data.Public.get(key, callback, callback);

                expect(data.get).toHaveBeenCalledWith('Worker.Data.Public', key, {scope: data.SCOPE.APP}, callback, callback);
            });

            it('getMulti should invoke data public get with app scope', function() {
                Worker.Data.Public.getMulti(keys, callback, callback);

                expect(data.getMulti).toHaveBeenCalledWith('Worker.Data.Public', keys, {scope: data.SCOPE.APP}, callback, callback);
            });
        });
    });
});
