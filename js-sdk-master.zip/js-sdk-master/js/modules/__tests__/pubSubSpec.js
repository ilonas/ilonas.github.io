define(['PubSub', 'privates/reporter', 'privates/postMessage'], function (PubSub, reporter, postMessage) {
    'use strict';

    describe('PubSub tests', function () {

        beforeEach(function () {
            spyOn(postMessage, 'removeEventListenerInternal');
            spyOn(postMessage, 'addEventListenerInternal');
            spyOn(postMessage, 'sendMessage');
            spyOn(reporter, 'reportSdkError');
        });

        var TPA_PUB_SUB_PREFIX = 'TPA_PUB_SUB_';

        describe('unsubscribe', function () {
            it('should call removeEventListenerInternal when calling unsubscribe', function () {
                PubSub.unsubscribe('myKey', function () {});
                expect(postMessage.removeEventListenerInternal).toHaveBeenCalledWith(TPA_PUB_SUB_PREFIX + 'myKey', 'PubSub', jasmine.any(Function), true);
            });
        });

        describe('subscribe', function () {
            it('should report sdk error when eventKey string is not given', function () {
                PubSub.subscribe(function () {});

                expect(postMessage.addEventListenerInternal).not.toHaveBeenCalled();
                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - eventName, must be a string');

            });

            it('should report sdk error when callback function is not given', function () {
                PubSub.subscribe('key');

                expect(postMessage.addEventListenerInternal).not.toHaveBeenCalled();
                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - callBack, must be a function');
            });

            it('should call addEventListenerInternal when calling subscribe', function () {
                PubSub.subscribe('myKey', function () {
                }, true);

                expect(postMessage.addEventListenerInternal).toHaveBeenCalledWith(TPA_PUB_SUB_PREFIX + 'myKey', 'PubSub',
                    jasmine.any(Function), true, {receivePastEvents: true});
            });
        });

        describe('publish', function () {
            it('should report sdk error when eventKey is not given', function () {
                PubSub.publish(function () {});

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - eventName, must be a string');
            });

            it('should call sendMessage with the given arguments', function () {
                var data = { data: 'myData'};


                PubSub.publish('key', data, true);

                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.PUBLISH, 'PubSub', {
                    eventKey: TPA_PUB_SUB_PREFIX + 'key',
                    isPersistent: true,
                    eventData: data
                });
            });

            it('should call sendMessage with empty eventData when one is not given', function () {
                PubSub.publish('key', undefined, true);

                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.PUBLISH, 'PubSub', {
                    eventKey: TPA_PUB_SUB_PREFIX + 'key',
                    isPersistent: true,
                    eventData: {}
                });
            });

            it('should call the dispatcher with isPersistent false when one is not given', function () {
                PubSub.publish('key', {});

                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.PUBLISH, 'PubSub', {
                    eventKey: TPA_PUB_SUB_PREFIX + 'key',
                    isPersistent: false,
                    eventData: {}
                });
            });
        });
    });
});