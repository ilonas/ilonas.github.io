define(['lodash', 'Contacts', 'privates/core',  'privates/postMessage', 'privates/utils', 'privates/responseHandlers', 'privates/reporter'],
    function (_, Contacts, core, postMessage, utils, responseHandlers, reporter) {
        'use strict';

        describe('Contacts tests', function () {
            var _w;

            function givenW(){
                return {
                    MessageTypes:{
                        GET_CONTACT_BY_ID: 'getContactById',
                        GET_CONTACTS: 'getContacts',
                        CREATE_CONTACT: 'createContact'
                    },
                    reportSdkError:function(){},
                    handleDataResponse: jasmine.createSpy(),
                    PostMessageDispatcher: jasmine.createSpy()
                };
            }

            beforeEach(function(){
                _w = givenW();
            });

            describe('getContacts', function(){
                beforeEach(function(){
                    spyOn(responseHandlers, 'handleCursorResponse');
                });

                it('should invoke the given onSuccess callback when request is valid', function() {
                    spyOn(postMessage, 'sendMessage');

                    var error = jasmine.createSpy();
                    var options = {};
                    var success = jasmine.createSpy();

                    Contacts.getContacts(options, success, error);
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_CONTACTS, 'Contacts', { options: options }, jasmine.any(Function));
                });

                it('should invoke the given onSuccess callback w/ options when request is valid', function() {
                    spyOn(postMessage, 'sendMessage').and.callFake(function (m, n, args , callback) {
                        return callback({
                            data: {
                                "previousCursor": '332',
                                "nextCursor": '112',
                                "results": [{
                                    data: {
                                        'contact': '1'
                                    }
                                }]
                            }
                        });
                    });

                    var error = jasmine.createSpy();
                    var options = {
                        pageSize: 50,
                        labels: '123'
                    };
                    var success = jasmine.createSpy();
                    var response = { data : { previousCursor : '332', nextCursor : '112', results : [ { data : { contact : '1' } } ] } };


                    Contacts.getContacts(options, success, error);
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_CONTACTS, 'Contacts', { options: options }, jasmine.any(Function));
                    expect(responseHandlers.handleCursorResponse).toHaveBeenCalledWith(response, success, error, postMessage.MessageTypes.GET_CONTACTS, options);
                });

                it('should report sdk error when callback options is not given', function() {
                    spyOn(postMessage, 'sendMessage');
                    spyOn(reporter, 'reportSdkError');


                    Contacts.getContacts();
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - options, must be an object');
                });

                it('should report sdk error when callback function is not given', function(){
                    spyOn(postMessage, 'sendMessage');
                    spyOn(reporter, 'reportSdkError');

                    Contacts.getContacts({});
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - onSuccess, must be a function');
                });

                it('should invoke the given onFailure callback with a Wix Error when an error happened', function(){
                    spyOn(postMessage, 'sendMessage').and.callFake(function (m, n, args , callback) {
                        return callback({
                            error: {errorCode: 500}
                        });
                    });

                    var error = jasmine.createSpy();
                    var success = jasmine.createSpy();
                    var options = {};


                    Contacts.getContacts(options, success, error);

                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_CONTACTS, 'Contacts', { options: options }, jasmine.any(Function));
                    expect(responseHandlers.handleCursorResponse).toHaveBeenCalledWith({error: { errorCode: 500 }}, success, error, _w.MessageTypes.GET_CONTACTS, {});
                });
            });

            describe('getContactById', function(){
                it('should invoke the given onSuccess callback when request is valid', function() {
                    spyOn(postMessage, 'sendMessage').and.callFake(function (m, n, args , callback) {
                        return callback({
                            data: {'contactId': '3221'}
                        });
                    });

                    responseHandlers.handleDataResponse = jasmine.createSpy();

                    var error = jasmine.createSpy();
                    var success = jasmine.createSpy();

                    Contacts.getContactById('3221', success, error);
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_CONTACT_BY_ID, 'Contacts', {id: '3221'}, jasmine.any(Function));
                    expect(responseHandlers.handleDataResponse).toHaveBeenCalledWith({data: { contactId: '3221' }}, success, error);
                });

                it('should report sdk error when contact id is not given or not a string', function(){
                    spyOn(postMessage, 'sendMessage');
                    spyOn(reporter, 'reportSdkError');


                    Contacts.getContactById();
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - id, must be a string');

                    Contacts.getContactById(3321);
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - id, must be a string');

                });

                it('should report sdk error when onSuccess callback function is not given', function(){
                    spyOn(postMessage, 'sendMessage');
                    spyOn(reporter, 'reportSdkError');

                    Contacts.getContactById('3221');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - onSuccess, must be a function');
                });

                it('should report sdk error when onFailure callback function is not given', function(){
                    spyOn(postMessage, 'sendMessage');
                    spyOn(reporter, 'reportSdkError');

                    Contacts.getContactById('3221', function(){});
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - onFailure, must be a function');
                });

                it('should invoke the given onFailure callback with a Wix Error when an error happened', function(){
                    spyOn(postMessage, 'sendMessage').and.callFake(function (m, n, args , callback) {
                        return callback({
                            error: {
                                errorCode: 500
                            }
                        });
                    });

                    spyOn(responseHandlers, 'handleCursorResponse');
                    var error = jasmine.createSpy();
                    var success = jasmine.createSpy();

                    Contacts.getContactById('3221', success, error);

                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_CONTACT_BY_ID, 'Contacts', {id: '3221'}, jasmine.any(Function));
                    expect(responseHandlers.handleDataResponse).toHaveBeenCalledWith({error: { errorCode: 500 }}, success, error);
                });
            });

            describe('reconcile contact', function () {
                it('invoke correct core api on valid options', function () {
                    responseHandlers.handleDataResponse = jasmine.createSpy();
                    spyOn(postMessage, 'sendMessage');

                    Contacts.reconcileContact({a: 'b'});
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.RECONCILE_CONTACT, 'Contacts', {a: 'b'}, jasmine.any(Function));
                });

                it('should call success callback on valid options when cb was passed', function () {
                    spyOn(postMessage, 'sendMessage').and.callFake(function (m, n, args, cb) {
                        return cb({
                            data: {x: 'y'}
                        });
                    });
                    responseHandlers.handleDataResponse = jasmine.createSpy();

                    var success = jasmine.createSpy();
                    var failure = jasmine.createSpy();

                    Contacts.reconcileContact({a: 'b'}, success, failure);
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.RECONCILE_CONTACT, 'Contacts', {a: 'b'}, jasmine.any(Function));
                    expect(responseHandlers.handleDataResponse).toHaveBeenCalledWith({data: { x: 'y' }}, success, failure);
                });

                it('should report sdk error when contact info is not given', function () {
                    spyOn(reporter, 'reportSdkError');
                    spyOn(postMessage, 'sendMessage');

                    Contacts.reconcileContact();
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory contact options parameter');
                });

                it('should report sdk error when contact info is not an object', function () {
                    spyOn(reporter, 'reportSdkError');
                    spyOn(postMessage, 'sendMessage');

                    Contacts.reconcileContact('not an object');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Contact options parameter must be an object');
                });

                it('should report sdk error when onSuccess callback param given but not a function', function () {
                    spyOn(reporter, 'reportSdkError');
                    spyOn(postMessage, 'sendMessage');

                    Contacts.reconcileContact({}, 'not a func');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - onSuccess, must be a function');
                });

                it('should report sdk error when onFailure callback param is given but not a function', function () {
                    spyOn(reporter, 'reportSdkError');
                    spyOn(postMessage, 'sendMessage');

                    Contacts.reconcileContact({}, function () {}, 'not a func');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - onFailure, must be a function');
                });
            });
        });
    });