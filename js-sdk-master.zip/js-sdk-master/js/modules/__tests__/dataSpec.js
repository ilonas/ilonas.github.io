define(['Data', 'privates/postMessage', 'privates/reporter', 'privates/viewMode'], function(Data, postMessage, reporter, viewMode) {

    'use strict';

    describe('Data', function() {
        var onSuccess, onFailure;

        beforeEach(function () {
            spyOn(reporter, 'reportSdkError');
            spyOn(postMessage, 'sendMessage');
            spyOn(viewMode, 'getViewMode').and.returnValue('editor');
            onSuccess = jasmine.createSpy('onSuccess');
            onFailure = jasmine.createSpy('onFailure');
        });

        describe('getMulti', function() {
            it('should report sdk error if keys is not given is parameter', function() {
                Data.Public.getMulti(onSuccess, onFailure);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory argument - keys - should be of type Array');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
                expect(onSuccess).not.toHaveBeenCalled();
                expect(onFailure).not.toHaveBeenCalled();
            });

            it('should report sdk error if keys is of type string', function() {
                Data.Public.getMulti('arr', onSuccess, onFailure);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory argument - keys - should be of type Array');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
                expect(onSuccess).not.toHaveBeenCalled();
                expect(onFailure).not.toHaveBeenCalled();
            });

            it('should report sdk error if keys is of type object', function() {
                Data.Public.getMulti({ 1: 'arr'}, onSuccess, onFailure);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory argument - keys - should be of type Array');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
                expect(onSuccess).not.toHaveBeenCalled();
                expect(onFailure).not.toHaveBeenCalled();
            });

            it('should get multi values and return the data in onSuccess callback', function() {
                var keys = ['key1', 'key2'];
                var expectedObj = {};
                expectedObj[keys[0]] = 'val1';
                expectedObj[keys[1]] = 'val2';

                postMessage.sendMessage.and.callFake(function(type, ns, obj, callback) {
                    callback(expectedObj)
                });

                Data.Public.getMulti(keys, onSuccess, onFailure);

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_VALUES, 'Data.Public', {
                    keys: keys,
                    scope: Data.SCOPE.COMPONENT
                }, jasmine.any(Function));
                expect(onSuccess).toHaveBeenCalledWith(expectedObj);
                expect(onFailure).not.toHaveBeenCalled();
            });

            it('should call the onFailure function in case of failure', function() {
                var keys = ['key1', 'key2'];
                var expectedObj = {};
                expectedObj[keys[0]] = 'val1';
                expectedObj[keys[1]] = 'val2';
                var dataError = { error: 'key not found'};

                postMessage.sendMessage.and.callFake(function(type, ns, obj, callback) {
                    callback(dataError)
                });

                Data.Public.getMulti(keys, onSuccess, onFailure);

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_VALUES, 'Data.Public', {
                    keys: keys,
                    scope: Data.SCOPE.COMPONENT
                }, jasmine.any(Function));
                expect(onSuccess).not.toHaveBeenCalled();
                expect(onFailure).toHaveBeenCalledWith(dataError);
            });
        });

        describe('get', function() {
            it('should report sdk error if key is not given is parameter', function() {
                Data.Public.get(onSuccess, onFailure);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory argument - key - should be of type String');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
                expect(onSuccess).not.toHaveBeenCalled();
                expect(onFailure).not.toHaveBeenCalled();
            });

            it('should report sdk error if key is of type function', function() {
                Data.Public.get(function(){}, onSuccess, onFailure);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory argument - key - should be of type String');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
                expect(onSuccess).not.toHaveBeenCalled();
                expect(onFailure).not.toHaveBeenCalled();
            });

            it('should report sdk error if key is of type number', function() {
                Data.Public.get(2, onSuccess, onFailure);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory argument - key - should be of type String');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
                expect(onSuccess).not.toHaveBeenCalled();
                expect(onFailure).not.toHaveBeenCalled();
            });

            it('should get value and return the data in onSuccess callback', function() {
                var key = 'key1';
                var expectedObj = {};
                expectedObj[key] = 'val1';

                postMessage.sendMessage.and.callFake(function(type, ns, obj, callback) {
                    callback(expectedObj)
                });

                Data.Public.get(key, onSuccess, onFailure);

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_VALUE, 'Data.Public', {
                    key: key,
                    scope: Data.SCOPE.COMPONENT
                }, jasmine.any(Function));
                expect(onSuccess).toHaveBeenCalledWith(expectedObj);
                expect(onFailure).not.toHaveBeenCalled();
            });

            it('should call the onFailure function in case of failure', function() {
                var key = 'key1';
                var dataError = { error: 'key not found'};

                postMessage.sendMessage.and.callFake(function(type, ns, obj, callback) {
                    callback(dataError)
                });

                Data.Public.get(key, onSuccess, onFailure);

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_VALUE, 'Data.Public', {
                    key: key,
                    scope: Data.SCOPE.COMPONENT
                }, jasmine.any(Function));
                expect(onSuccess).not.toHaveBeenCalled();
                expect(onFailure).toHaveBeenCalledWith(dataError);
            });
        });

        describe('remove', function() {
            it('should report sdk error if in viewer mode', function() {
                viewMode.getViewMode.and.returnValue('viewer');

                Data.Public.remove('key', onSuccess, onFailure);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid view mode. This function can be called only in editor mode.');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
                expect(onSuccess).not.toHaveBeenCalled();
                expect(onFailure).not.toHaveBeenCalled();
            });

            it('should report sdk error if key is not given is parameter', function() {
                Data.Public.remove(onSuccess, onFailure);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory argument - key - should be of type String');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
                expect(onSuccess).not.toHaveBeenCalled();
                expect(onFailure).not.toHaveBeenCalled();
            });

            it('should report sdk error if key is of type function', function() {
                Data.Public.remove(function(){}, onSuccess, onFailure);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory argument - key - should be of type String');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
                expect(onSuccess).not.toHaveBeenCalled();
                expect(onFailure).not.toHaveBeenCalled();
            });

            it('should report sdk error if key is of type number', function() {
                Data.Public.remove(2, onSuccess, onFailure);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory argument - key - should be of type String');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
                expect(onSuccess).not.toHaveBeenCalled();
                expect(onFailure).not.toHaveBeenCalled();
            });

            it('should remove value and return the removed value in onSuccess callback', function() {
                var key = 'key1';
                var expectedObj = {};
                expectedObj[key] = 'val1';

                postMessage.sendMessage.and.callFake(function(type, ns, obj, callback) {
                    callback(expectedObj)
                });

                Data.Public.remove(key, onSuccess, onFailure);

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.REMOVE_VALUE, 'Data.Public', {
                    key: key,
                    scope: Data.SCOPE.COMPONENT
                }, jasmine.any(Function));
                expect(onSuccess).toHaveBeenCalledWith(expectedObj);
                expect(onFailure).not.toHaveBeenCalled();
            });

            it('should remove value even if only key is defined', function() {
                var key = 'key1';
                var expectedObj = {};
                expectedObj[key] = 'val1';

                postMessage.sendMessage.and.callFake(function(type, ns, obj, callback) {
                    callback(expectedObj)
                });

                Data.Public.remove(key, {scope: 'COMPONENT'});

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.REMOVE_VALUE, 'Data.Public', {
                    key: key,
                    scope: Data.SCOPE.COMPONENT
                }, jasmine.any(Function));
            });

            it('should remove value even if onSuccess callback is not defined', function() {
                var key = 'key1';
                var expectedObj = {};
                expectedObj[key] = 'val1';

                postMessage.sendMessage.and.callFake(function(type, ns, obj, callback) {
                    callback(expectedObj)
                });

                Data.Public.remove(key, {scope: 'COMPONENT'});

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.REMOVE_VALUE, 'Data.Public', {
                    key: key,
                    scope: Data.SCOPE.COMPONENT
                }, jasmine.any(Function));
            });

            it('should call the onFailure function in case of failure', function() {
                var key = 'key1';
                var dataError = { error: 'key not found'};

                postMessage.sendMessage.and.callFake(function(type, ns, obj, callback) {
                    callback(dataError)
                });

                Data.Public.remove(key, onSuccess, onFailure);

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.REMOVE_VALUE, 'Data.Public', {
                    key: key,
                    scope: Data.SCOPE.COMPONENT
                }, jasmine.any(Function));
                expect(onSuccess).not.toHaveBeenCalled();
                expect(onFailure).toHaveBeenCalledWith(dataError);
            });
        });

        describe('set', function() {
            it('should report sdk error if in viewer mode', function() {
                viewMode.getViewMode.and.returnValue('viewer');

                Data.Public.set('key', 'val', onSuccess, onFailure);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid view mode. This function can be called only in editor mode.');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
                expect(onSuccess).not.toHaveBeenCalled();
                expect(onFailure).not.toHaveBeenCalled();
            });

            it('should report sdk error if key is not given is parameter', function () {
                Data.Public.set(onSuccess, onFailure);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory argument - key - should be of type String');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
                expect(onSuccess).not.toHaveBeenCalled();
                expect(onFailure).not.toHaveBeenCalled();
            });

            it('should report sdk error if value is not given is parameter', function () {
                Data.Public.set('key1', onSuccess, onFailure);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory argument - value - should be of type String, Number, Boolean or Json');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
                expect(onSuccess).not.toHaveBeenCalled();
                expect(onFailure).not.toHaveBeenCalled();
            });

            it('should set value of type string and return the data in onSuccess callback', function () {
                var key = 'key1';
                var val = 'val1';
                var expectedObj = {};
                expectedObj[key] = val;

                postMessage.sendMessage.and.callFake(function (type, ns, obj, callback) {
                    callback(expectedObj)
                });

                Data.Public.set(key, val, onSuccess, onFailure);

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SET_VALUE, 'Data.Public', {
                    key: key,
                    value: val,
                    scope: Data.SCOPE.COMPONENT
                }, jasmine.any(Function));
                expect(onSuccess).toHaveBeenCalledWith(expectedObj);
                expect(onFailure).not.toHaveBeenCalled();
            });

            it('should set value of type boolean and return the data in onSuccess callback', function () {
                var key = 'key1';
                var val = false;
                var expectedObj = {};
                expectedObj[key] = val;

                postMessage.sendMessage.and.callFake(function (type, ns, obj, callback) {
                    callback(expectedObj)
                });

                Data.Public.set(key, val, onSuccess, onFailure);

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SET_VALUE, 'Data.Public', {
                    key: key,
                    value: val,
                    scope: Data.SCOPE.COMPONENT
                }, jasmine.any(Function));
                expect(onSuccess).toHaveBeenCalledWith(expectedObj);
                expect(onFailure).not.toHaveBeenCalled();
            });

            it('should set value of type number and return the data in onSuccess callback', function () {
                var key = 'key1';
                var val = 12;
                var expectedObj = {};
                expectedObj[key] = val;

                postMessage.sendMessage.and.callFake(function (type, ns, obj, callback) {
                    callback(expectedObj)
                });

                Data.Public.set(key, val, onSuccess, onFailure);

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SET_VALUE, 'Data.Public', {
                    key: key,
                    value: val,
                    scope: Data.SCOPE.COMPONENT
                }, jasmine.any(Function));
                expect(onSuccess).toHaveBeenCalledWith(expectedObj);
                expect(onFailure).not.toHaveBeenCalled();
            });

            it('should set value of type json and return the data in onSuccess callback', function () {
                var key = 'key1';
                var val = {
                    1: {
                        123: 'ddd',
                        12: 'fff'
                    }
                };
                var expectedObj = {};
                expectedObj[key] = val;

                postMessage.sendMessage.and.callFake(function (type, ns, obj, callback) {
                    callback(expectedObj)
                });

                Data.Public.set(key, val, onSuccess, onFailure);

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SET_VALUE, 'Data.Public', {
                    key: key,
                    value: val,
                    scope: Data.SCOPE.COMPONENT
                }, jasmine.any(Function));
                expect(onSuccess).toHaveBeenCalledWith(expectedObj);
                expect(onFailure).not.toHaveBeenCalled();
            });

            it('should call the onFailure function in case of failure', function () {
                var key = 'key1';
                var val = 1;
                var dataError = {error: 'key in different scopes'};

                postMessage.sendMessage.and.callFake(function (type, ns, obj, callback) {
                    callback(dataError)
                });

                Data.Public.set(key, val, onSuccess, onFailure);

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SET_VALUE, 'Data.Public', {
                    key: key,
                    value: val,
                    scope: Data.SCOPE.COMPONENT
                }, jasmine.any(Function));
                expect(onSuccess).not.toHaveBeenCalled();
                expect(onFailure).toHaveBeenCalledWith(dataError);
            });

            it('should report SDK error if options contains scope with other type than the enum SCOPE', function() {
                Data.Public.set('key1', 'val1', { scope: '123'}, onSuccess, onFailure);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - options should be of type object, containing scope of type Wix.Data.SCOPE');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
                expect(onSuccess).not.toHaveBeenCalled();
                expect(onFailure).not.toHaveBeenCalled();
            });

            it('should report SDK error if options is of type string', function() {
                Data.Public.set('key1', 'val1', Data.SCOPE.COMPONENT, onSuccess, onFailure);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - options should be of type object, containing scope of type Wix.Data.SCOPE');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
                expect(onSuccess).not.toHaveBeenCalled();
                expect(onFailure).not.toHaveBeenCalled();
            });

            it('should report SDK error if onSuccess is not a function', function() {
                Data.Public.set('key1', 'val1', {scope: Data.SCOPE.COMPONENT}, 'string');

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - onSuccess - should be a function');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
                expect(onSuccess).not.toHaveBeenCalled();
                expect(onFailure).not.toHaveBeenCalled();
            });

            it('should set scope APP', function () {
                var key = 'key1';
                var val = {
                    1: {
                        123: 'ddd',
                        12: 'fff'
                    }
                };
                var expectedObj = {};
                expectedObj[key] = val;

                postMessage.sendMessage.and.callFake(function (type, ns, obj, callback) {
                    callback(expectedObj)
                });

                Data.Public.set(key, val, {scope: Data.SCOPE.APP}, onSuccess, onFailure);

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SET_VALUE, 'Data.Public', {
                    key: key,
                    value: val,
                    scope: Data.SCOPE.APP
                }, jasmine.any(Function));
                expect(onSuccess).toHaveBeenCalledWith(expectedObj);
                expect(onFailure).not.toHaveBeenCalled();
            });

            it('should set scope COMPONENT', function () {
                var key = 'key1';
                var val = {
                    1: {
                        123: 'ddd',
                        12: 'fff'
                    }
                };
                var expectedObj = {};
                expectedObj[key] = val;

                postMessage.sendMessage.and.callFake(function (type, ns, obj, callback) {
                    callback(expectedObj)
                });

                Data.Public.set(key, val, {scope: Data.SCOPE.COMPONENT}, onSuccess, onFailure);

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SET_VALUE, 'Data.Public', {
                    key: key,
                    value: val,
                    scope: Data.SCOPE.COMPONENT
                }, jasmine.any(Function));
                expect(onSuccess).toHaveBeenCalledWith(expectedObj);
                expect(onFailure).not.toHaveBeenCalled();
            });
        });
    });
});
