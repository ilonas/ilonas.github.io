var WixDataCursor = require('WixDataCursor');
var core = require('privates/core');
var postMessage = require('privates/postMessage');

describe('WixDataCursor tests', function () {
    it('should throw error because mandatory params are missing', function () {
        try {
            var cursor = new WixDataCursor('', data);
        } catch (error) {
        }

        expect(cursor).not.toBeDefined();
    });

    it('should return false for hasNext if has no next cursor', function () {
        var cursor = givenCursorWithNextAndPrevious([]);
        cursor.setNextCursor(null);
        expect(cursor.hasNext()).toBe(false);

        cursor.setNextCursor(undefined);
        expect(cursor.hasNext()).toBe(false);

        cursor.setNextCursor(0);
        expect(cursor.hasNext()).toBe(false);
    });

    it('should return false for hasPrevious if has no previous cursor', function () {
        var cursor = givenCursorWithNextAndPrevious([]);
        cursor.setPreviousCursor(null);
        expect(cursor.hasPrevious()).toBe(false);

        cursor.setPreviousCursor(undefined);
        expect(cursor.hasPrevious()).toBe(false);

        cursor.setPreviousCursor(0);
        expect(cursor.hasPrevious()).toBe(false);
    });

    it('should return totals', function () {
        var cursor = givenCursorWith([], [], [], 100, 25);
        expect(cursor.getTotal()).toBe(100);
    });

    it('should return pageSize', function () {
        var cursor = givenCursorWith([], [], [], 100, 25);
        expect(cursor.getPageSize()).toBe(25);
    });

    describe('hasNext() and hasPrevious()', function () {
        var postMessageMock;
        beforeEach(function () {
            postMessageMock = spyOn(postMessage, 'sendMessage');
        });

        it('should return next cursor', function () {
            var cursor = givenCursorWithNextAndPrevious([], '123' , '456');
            postMessageMock.and.callFake(function (m, n, args, callback) {
                return callback({
                    data: {
                        "previousCursor": '123',
                        "nextCursor": '456',
                        "results": [{foo: 'bar'}]
                    }
                });
            });

            var args = {
                cursorId: '123',
                options: {}
            };

            cursor.next(function () {}, function () {});
            expect(postMessageMock).toHaveBeenCalledWith("getContacts", 'WixDataCursor', args, jasmine.any(Function));

            cursor.next(function (data) {
                expect(data).toBeDefined();
                expect(data.length).toEqual(1);
                expect(data[0].foo).toBe('bar');
                expect(cursor.getData()[0].foo).toBe('bar');
            }, function (error) {
            });
            expect(postMessageMock).toHaveBeenCalledWith("getContacts", 'WixDataCursor', args, jasmine.any(Function));
        });

        it('should return next cursor with given options', function () {
            var options = {
                pageSize: 50
            };
            var cursor = givenCursorWith([], '123', '456', 100, 50, options);
            var args = {
                cursorId: '123',
                options: options
            };

            cursor.next(function (data) {
            }, function (error) {
            });
            expect(postMessageMock).toHaveBeenCalledWith("getContacts", 'WixDataCursor', args, jasmine.any(Function));

            cursor.next(function (data) {
                expect(data).toBeDefined();
                expect(data.length).toEqual(1);
                expect(data[0].foo).toBe('bar');
                expect(cursor.getData()[0].foo = 'bar');
            }, function (error) {
            });
            expect(postMessageMock).toHaveBeenCalledWith("getContacts", 'WixDataCursor', args, jasmine.any(Function));
        });

        it('should return has no next data when response has no data', function () {
            var cursor = givenCursorWithNextAndPrevious([]);

            postMessageMock.and.callFake(function (m, args, callback) {
                return callback({
                    data: {
                        "results": []
                    }
                });
            });

            cursor.next(function (data) {
                expect(data).toBeDefined();
                expect(data.length).toEqual(0);
            }, function (error) {
            });
            expect(cursor.hasNext()).toBeFalsy();
        });

        it('should return an empty list when next is called but hasNext is null', function () {
            var cursor = givenCursorWithNextAndPrevious([], '123', '456');
            var args = {
                cursorId: '123',
                options: {}
            };

            cursor.next(function (data) {
            }, function () {
            });
            expect(postMessageMock).toHaveBeenCalledWith("getContacts", 'WixDataCursor', args, jasmine.any(Function));

            cursor.next(function (data) {
                expect(data).toBeDefined();
                expect(data.length).toEqual(0);
                expect(data.status).not.toBeDefined();
            }, function () {
            });

            expect(postMessageMock).not.toHaveBeenCalledWith("getContacts", 'WixDataCursor', {
                cursorId: null,
                options: {}
            }, jasmine.any(Function));
        });

        it('should not do a post message when previous is called, but hasPrevious is null', function () {
            var cursor = givenCursorWithNextAndPrevious([], '123', '456');
            var args = {
                cursorId: '123',
                options: {}
            };

            cursor.next(function (data) {
            }, function () {
            });
            expect(postMessageMock).toHaveBeenCalledWith("getContacts", 'WixDataCursor', args, jasmine.any(Function));

            cursor.previous(function (data) {
            }, function () {
            });
            expect(postMessageMock).not.toHaveBeenCalledWith("getContacts", 'WixDataCursor', {
                cursorId: null,
                options: {}
            }, jasmine.any(Function));
        });

        it('should return an error when an error occurred', function () {
            var error = jasmine.createSpy('error');
            var success = jasmine.createSpy('success');
            postMessage.sendMessage.and.callFake(function (m, n, args, callback) {
                return callback({error: {}});
            });

            var cursor = givenCursorWithNextAndPrevious([], '123', '456');

            cursor.next(success, error);
            expect(error).toHaveBeenCalled();
            expect(success).not.toHaveBeenCalled();
        });
    });

    function givenCursorWithNextAndPrevious(data, next, previous) {
        var cursor = new WixDataCursor("getContacts", data);
        cursor.setNextCursor(next);
        cursor.setPreviousCursor(previous);
        return cursor;
    }

    function givenCursorWith(data, next, previous, totals, pageSize, options) {
        var cursor = new WixDataCursor("getContacts", data, totals, pageSize);
        cursor.setOptions(options);
        cursor.setNextCursor(next);
        cursor.setPreviousCursor(previous);
        return cursor;
    }

});