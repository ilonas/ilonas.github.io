define(['privates/postMessage', 'privates/reporter'], function (postMessage, reporter) {
    'use strict';

    describe('postMessage tests', function () {

        describe('sendMessage', function () {
            var sdkVersion = '1.2.3';
            var target;
            beforeEach(function () {
                postMessage.init(sdkVersion);
                target = parent.postMessage ? parent : (parent.document.postMessage ? parent.document : undefined);
                spyOn(target, 'postMessage');
            });

            it('should report calling sendMessage params different than object', function () {
                spyOn(reporter, 'reportSdkMsg');
                var msgMock = {
                    'intent': 'TPA2',
                    'callId': 1,
                    'type': 'msgType',
                    'compId':'[UNKNOWN]',
                    'deviceType':'desktop',
                    'data': 'arbitrary string',
                    'namespace': 'namespace'
                };
                postMessage.sendMessage(msgMock.type, msgMock.namespace, msgMock.data);
                expect(reporter.reportSdkMsg).toHaveBeenCalledWith('Expecting params to be of type Object, string given');
            });

            it('should call postMessage with the right arguments', function () {
                var msgMock = {
                    'intent': 'TPA2',
                    'callId': 2,
                    'type': 'msgType',
                    'compId':'[UNKNOWN]',
                    'deviceType':'desktop',
                    namespace: 'namespace',
                    'data': {
                        a: 'b',
                    },
                    version: sdkVersion
                };
                postMessage.sendMessage(msgMock.type, msgMock.namespace, msgMock.data);
                var callArgs = target.postMessage.calls.argsFor(0);
                expect(JSON.parse(callArgs[0])).toEqual(msgMock);
                expect(callArgs[1]).toBe('*');
            });
        });

    });
});