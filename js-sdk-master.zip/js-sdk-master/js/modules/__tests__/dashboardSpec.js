define(['Dashboard', 'Settings', 'privates/core', 'Base', 'privates/reporter', 'privates/postMessage'], function (Dashboard, Settings, core, Base, reporter, postMessage) {

    describe('Dashboard tests', function () {
        beforeEach(function () {
            spyOn(reporter, 'reportSdkError');
            spyOn(postMessage, 'sendMessage');
        });

        it('should call Wix.setHeight when calling Wix.Dashboard.setHeight', function () {
            spyOn(Base, 'setHeight');
            Dashboard.setHeight(100);
            expect(Base.setHeight).toHaveBeenCalledWith(100);
        });

        it('should call Wix.scrollTo when calling Wix.Dashboard.scrollTo', function () {
            spyOn(Base, 'scrollTo');
            Dashboard.scrollTo(100, 100);
            expect(Base.scrollTo).toHaveBeenCalledWith(100, 100);
        });

        it('should call Wix.Settings.openMediaDialog when calling Wix.Dashboard.openMediaDialog', function () {
            spyOn(Settings, 'openMediaDialog');
            Dashboard.openMediaDialog(Settings.MediaType.IMAGE, false, function () {
            });
            expect(Settings.openMediaDialog).toHaveBeenCalledWith(Settings.MediaType.IMAGE, false, jasmine.any(Function), undefined);
        });

        it('should call Wix.openModal when calling Wix.Dashboard.openMediaDialog', function () {
            spyOn(Base, 'openModal');
            Dashboard.openModal("about:blank", 100, 100, function () {
            });
            expect(Base.openModal).toHaveBeenCalledWith("about:blank", 100, 100, jasmine.any(Function));
        });

        it('should call Wix.closeWindow when calling Wix.Dashboard.closeWindow', function () {
            spyOn(Base, 'closeWindow');
            Dashboard.closeWindow("message");
            expect(Base.closeWindow).toHaveBeenCalledWith("message");
        });

        it('should call Wix.Settings.openBillingPage when calling Wix.Dashboard.openBillingPage', function () {
            spyOn(Settings, 'openBillingPage');
            Dashboard.openBillingPage();
            expect(Settings.openBillingPage).toHaveBeenCalled();
        });

        it('should call Wix.Settings.openBillingPage when calling Wix.Dashboard.openBillingPage and pass parameters', function () {
            spyOn(Settings, 'openBillingPage');
            Dashboard.openBillingPage({premiumIntent: Settings.PremiumIntent.FREE});
            expect(Settings.openBillingPage).toHaveBeenCalledWith({premiumIntent: Settings.PremiumIntent.FREE});
        });

        it('should call Wix.pushState when calling Wix.Dashboard.pushState', function () {
            Dashboard.pushState('someState?with=param');

            expect(postMessage.sendMessage).toHaveBeenCalledWith("appStateChanged", 'Dashboard', {state: 'someState?with=param'});
        });

        it('should call Wix.resizeWindow when calling Wix.Dashboard.resizeWindow', function () {
            spyOn(Base, 'resizeWindow');
            Dashboard.resizeWindow(200, 200, function () {
            });
            expect(Base.resizeWindow).toHaveBeenCalledWith(200, 200, jasmine.any(Function));
        });


        describe('getEditorUrl', function () {
            it('should fail if callback function is not given', function () {
                Dashboard.getEditorUrl();
                expect(reporter.reportSdkError).toHaveBeenCalled();
            });

            it('should send GET_EDITOR_URL message when callback function is given', function () {
                var callback = jasmine.createSpy();
                Dashboard.getEditorUrl(callback);

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_EDITOR_URL, 'Dashboard', undefined, callback);
            });
        });

        describe('getSiteViewUrl', function() {
            it('should send GET_SITE_VIEW_URL in case only callback is given', function() {
                var callback = jasmine.createSpy();

                Dashboard.getSiteViewUrl(callback);

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_SITE_VIEW_URL, 'Dashboard', undefined, callback);

            });

            it('should send GET_SITE_VIEW_URL in case options and callback are given', function() {
                var callback = jasmine.createSpy();

                Dashboard.getSiteViewUrl({}, callback);

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_SITE_VIEW_URL, 'Dashboard', {}, callback);

            });

            it('should not send GET_SITE_VIEW_URL in case only options is given', function() {
                Dashboard.getSiteViewUrl({});

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - onSuccess');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();

            });

            it('should not send GET_SITE_VIEW_URL in case no params are given', function() {
                Dashboard.getSiteViewUrl();

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - onSuccess');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();

            });

            it('should not send GET_SITE_VIEW_URL in case string params is given', function() {
                Dashboard.getSiteViewUrl('test');

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - onSuccess');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();

            });
        });
    });
});
