define(['Base', 'privates/utils', 'Theme', 'WindowOrigin', 'WindowPlacement', 'privates/reporter', 'privates/postMessage', 'Events', 'privates/viewMode'],
    function (Base, utils, Theme, WindowOrigin, WindowPlacement, reporter, postMessage, Events, viewMode) {
        describe('Wix', function () {
            beforeEach(function () {
                spyOn(postMessage, 'sendMessage');
                spyOn(reporter, 'reportSdkError');
            });

            describe('Wix.openPopup', function () {
                it('should report error when view mode is editor', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('editor');
                    var position = {
                        origin: WindowOrigin.FIXED,
                        placement: WindowPlacement.CENTER
                    };

                    Base.openPopup('url', 200, 200, position, function () {
                    });
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid view mode. This function cannot be called in editor mode. Supported view modes are: [preview, site]');
                });

                describe('postMessage sendMessage', function () {
                    it('should call dispatcher with default theme when theme is not given', function () {
                        var position = {
                            origin: WindowOrigin.FIXED,
                            placement: WindowPlacement.CENTER
                        };

                        Base.openPopup('url', 200, 200, position, function () {
                        });

                        var args = {
                            url: 'url',
                            width: 200,
                            height: 200,
                            position: position,
                            theme: Theme.DEFAULT
                        };

                        expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.OPEN_POPUP, 'Wix', args, jasmine.any(Function));
                    });

                    it('should call dispatcher with the given theme', function () {
                        var position = {
                            origin: WindowOrigin.FIXED,
                            placement: WindowPlacement.CENTER
                        };

                        Base.openPopup('url', 200, 200, position, function () {
                        }, Theme.BARE);

                        var args = {
                            url: 'url',
                            width: 200,
                            height: 200,
                            position: position,
                            theme: Theme.BARE
                        };

                        expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.OPEN_POPUP, 'Wix', args, jasmine.any(Function));
                    });

                    it('should return the host page id', function () {
                        var callback = jasmine.createSpy();

                        Base.getCurrentPageId(callback);

                        expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_CURRENT_PAGE_ID, 'Wix', null, callback);
                    });


                    it('should set default origin if not given', function () {

                    });

                    it('should set default placement if not given', function () {

                    });

                    it('should set pass the right placement', function () {

                    });

                    it('should set pass the right origin', function () {

                    });
                });
            });

            describe('Wix.openModal', function () {
                it('should report error when view mode is editor', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('editor');

                    Base.openModal('url', 200, 200, function () {
                    });
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid view mode. This function cannot be called in editor mode. Supported view modes are: [preview, site]');
                });

                describe('postMessage sendMessage', function () {
                    it('should call dispatcher with default theme when theme is not given', function () {
                        Base.openModal('url', 200, 200, function () {
                        });

                        var args = {
                            url: 'url',
                            width: 200,
                            height: 200,
                            theme: Theme.DEFAULT
                        };

                        expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.OPEN_MODAL, 'Wix', args, jasmine.any(Function));
                    });

                    it('should call dispatcher with the given theme', function () {
                        Base.openModal('url', 200, 200, function () {
                        }, Theme.BARE);
                        var args = {
                            url: 'url',
                            width: 200,
                            height: 200,
                            theme: Theme.BARE
                        };

                        expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.OPEN_MODAL, 'Wix', args, jasmine.any(Function));
                    });

                    it('should return the host page id', function () {
                        var callback = jasmine.createSpy();

                        Base.getCurrentPageId(callback);
                        expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_CURRENT_PAGE_ID, 'Wix', null, callback);
                    });
                });
            });

            describe('scrollTo', function () {
                it('should construct the right args', function () {
                    Base.scrollTo(200, 200);
                    var args = {
                        x: 200,
                        y: 200
                    };

                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SCROLL_TO, 'Wix', args);
                });

                it('should not work in editor mode and throw sdk error', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('editor');

                    Base.scrollTo(200, 200);
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid view mode. This function cannot be called in editor mode. Supported view modes are: [preview, site]');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });
            });

            describe('scrollBy', function () {
                it('should not work in editor mode and throw sdk error', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('editor');

                    Base.scrollBy(0, 500);
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid view mode. This function cannot be called in editor mode. Supported view modes are: [preview, site]');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });
            });

            describe('setHeight', function () {
                it('should report an error when not a number is given', function () {
                    Base.setHeight({});
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory argument - height - should be of type Number');
                });

                it('should report an error when height is negative', function () {
                    Base.setHeight(-120);
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('height should be a positive integer');
                });

                it('should report an error if options is not of type object', function () {
                    Base.setHeight(1500, true);
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - options should be of type object, containing boolean indicating if to resize this component over other components on the page');
                });

                it('should report an error if options not contains overflow key', function () {
                    Base.setHeight(1500, {key: 1});
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - options should be of type object, containing boolean indicating if to resize this component over other components on the page');
                });

                it('should setHeight with overflow undefined if overflow is not given as param', function () {
                    Base.setHeight(1500);
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.HEIGHT_CHANGED, 'Wix', {
                        'height': 1500,
                        overflow: undefined
                    });
                });

                it('should setHeight with overflow true', function () {
                    Base.setHeight(1500, {overflow: true});
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.HEIGHT_CHANGED, 'Wix', {
                        'height': 1500,
                        overflow: true
                    });
                });

                it('should setHeight with overflow false', function () {
                    Base.setHeight(1500, {overflow: false});
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.HEIGHT_CHANGED, 'Wix', {
                        'height': 1500,
                        overflow: false
                    });
                });
            });

            describe('pushState', function () {
                it('should report an error when state is not a string', function () {
                    Base.pushState({});
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - state - should be of type String');
                });

                it('should sendMessage', function () {
                    Base.pushState('foo');

                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.APP_STATE_CHANGED, 'Wix', {'state': 'foo'});
                });
            });

            describe('setPageMetadata', function () {
                it('should report an error if run outside of site mode', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('editor');

                    Base.setPageMetadata({});

                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid view mode. This function cannot be called in editor/preview mode. Supported view mode is: [site]');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should report an error if options param is missing', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('site');

                    Base.setPageMetadata();

                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - options - should be of type Object');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should report an error if options param is empty', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('site');

                    Base.setPageMetadata({});

                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - options must contain title and/or description of type string');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should report an error if title is not a string', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('site');

                    Base.setPageMetadata({title: 1});

                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - title must be of type string');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should report an error if description is not a string', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('site');

                    Base.setPageMetadata({description: 1});

                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - description must be of type string');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should report an error if overrideTitle is not boolean', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('site');

                    Base.setPageMetadata({title: 'title', overrideTitle: 'string'});

                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - overrideTitle must be of type boolean');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should send message if title is valid', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('site');

                    Base.setPageMetadata({title: 'title'});

                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SET_PAGE_METADATA, 'Wix', {
                        title: 'title'
                    });
                });

                it('should send message if description is valid', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('site');

                    Base.setPageMetadata({description: 'description'});

                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SET_PAGE_METADATA, 'Wix', {
                        description: 'description'
                    });
                });

                it('should send message if both title and description are valid', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('site');

                    Base.setPageMetadata({title: 'title', description: 'description', overrideTitle: true});

                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SET_PAGE_METADATA, 'Wix', {
                        title: 'title',
                        description: 'description',
                        overrideTitle: true
                    });
                });

            });

            describe('getExternalId', function () {
                it('must provide an onSuccess callback', function () {
                    Base.getExternalId();
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory arguments - an onSuccess callback must be specified');
                });

                it('should call a message with the proper values', function () {
                    var callback = jasmine.createSpy();

                    Base.getExternalId(callback);
                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_EXTERNAL_ID, 'Wix', undefined, jasmine.any(Function));
                });
            });

            describe('navigateToComponent', function () {
                it('should navigate to component if only comp id is given as parameter', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('preview');

                    Base.navigateToComponent('comp1');
                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.NAVIGATE_TO_COMPONENT, 'Wix', {compId: 'comp1'}, undefined);
                });

                it('should not work in editor mode and throw sdk error', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('editor');

                    Base.navigateToComponent('comp1');
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid view mode. This function cannot be called in editor mode. Supported view modes are: [preview, site]');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('must provide compId parameter', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('preview');

                    Base.navigateToComponent();
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - compId - should be of type String');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('must provide compId parameter as string and not as object', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('preview');

                    Base.navigateToComponent({});
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - compId - should be of type String');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('must provide compId parameter as string and not as function', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('preview');

                    Base.navigateToComponent(jasmine.createSpy());
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - compId - should be of type String');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should handle onFailure callback if it is given as second param', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('site');

                    var onFailure = jasmine.createSpy('onFailure');
                    Base.navigateToComponent('comp1', onFailure);
                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.NAVIGATE_TO_COMPONENT, 'Wix', {compId: 'comp1'}, onFailure);
                });

                it('should throw sdk Error if pageId is not given inside an object', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('site');

                    var onFailure = jasmine.createSpy('onFailure');
                    Base.navigateToComponent('comp1', 'page1', onFailure);
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - options should be of type object, containing string representing page id and optionally noPageTransition');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should throw sdk Error if pageId is not of type string', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('site');

                    var onFailure = jasmine.createSpy('onFailure');
                    Base.navigateToComponent('comp1', {pageId: 222}, onFailure);
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - options must contain pageId of type string');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should throw sdk Error if noPageTransition is not of type boolean', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('site');

                    var onFailure = jasmine.createSpy('onFailure');
                    Base.navigateToComponent('comp1', {pageId: 'page1', noPageTransition: 222}, onFailure);
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - noPageTransition should be of type boolean');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should throw sdk Error if only noPageTransition is forward in options', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('site');

                    var onFailure = jasmine.createSpy('onFailure');
                    Base.navigateToComponent('comp1', {noPageTransition: 222}, onFailure);
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - options should be of type object, containing string representing page id and optionally noPageTransition');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should ignore other keys in options param', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('site');

                    var onFailure = jasmine.createSpy('onFailure');
                    Base.navigateToComponent('comp1', {id: 'page1', pageId: 'page2'}, onFailure);
                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.NAVIGATE_TO_COMPONENT, 'Wix', {
                        compId: 'comp1',
                        pageId: 'page2'
                    }, onFailure);
                });

                it('should add pageId param to args if it is given', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('site');

                    var onFailure = jasmine.createSpy('onFailure');
                    Base.navigateToComponent('comp1', {pageId: 'page1'}, onFailure);
                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.NAVIGATE_TO_COMPONENT, 'Wix', {
                        compId: 'comp1',
                        pageId: 'page1'
                    }, onFailure);
                });

                it('should add noPageTransition param to args if it is given', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('site');

                    var onFailure = jasmine.createSpy('onFailure');
                    Base.navigateToComponent('comp1', {pageId: 'page1', noPageTransition: true}, onFailure);
                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.NAVIGATE_TO_COMPONENT, 'Wix', {
                        compId: 'comp1',
                        pageId: 'page1',
                        noPageTransition: true
                    }, onFailure);
                });

                it('should add noTransition param to args if it is given', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('site');

                    var onFailure = jasmine.createSpy('onFailure');
                    Base.navigateToComponent('comp1', {pageId: 'page1', noPageTransition: true}, onFailure);
                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.NAVIGATE_TO_COMPONENT, 'Wix', {
                        compId: 'comp1',
                        pageId: 'page1',
                        noPageTransition: true
                    }, onFailure);
                });
            });

            describe('navigateToPage', function () {
                it('should navigate to page if page id is given as parameter', function () {
                    Base.navigateToPage('page1');
                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.NAVIGATE_TO_PAGE, 'Wix', {pageId: 'page1'}, undefined);
                });

                it('should repprt an error if pageId is not passed', function () {
                    Base.navigateToPage();
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - pageId of type string');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should throw sdk Error if noTransition is not of type boolean', function () {
                    Base.navigateToPage('page1', {noTransition: 222});
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - noTransition should be of type boolean');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should ignore other keys in options param', function () {
                    Base.navigateToPage('page1', {id: 'page1', pageId: 'page2'});
                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.NAVIGATE_TO_PAGE, 'Wix', {pageId: 'page1'}, undefined);
                });

                it('should add noTransition param to args if it is given', function () {
                    Base.navigateToPage('page1', {noTransition: true});
                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.NAVIGATE_TO_PAGE, 'Wix', {
                        pageId: 'page1',
                        noTransition: true
                    }, undefined);
                });


                it('should report an error if options is not an object', function () {
                    Base.navigateToPage('id', 1);

                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - options must be of type Object');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should report an error if onFailure is not a function', function () {
                    Base.navigateToPage('id', {}, 1);

                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - onFailure must be of type Function');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should report an error if anchorId is passed in editor mode', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('editor');

                    Base.navigateToPage('id', {anchorId: 'id'});

                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid view mode. This function cannot be called with anchorId in editor mode. Supported view modes are: [preview, site]');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should send post message with anchorId and callback', function () {
                    Base.navigateToPage('id', {anchorId: 'anchorId'}, _.noop);

                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.NAVIGATE_TO_PAGE, 'Wix', {
                        pageId: 'id',
                        anchorId: 'anchorId'
                    }, jasmine.any(Function));
                });
            });

            describe('resizeComponent', function () {
                it('should throw error if called from preview view mode', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('preview');
                    Base.resizeComponent({width: 200}, jasmine.createSpy('onSuccess'));
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('preview is an invalid view mode. This function can only be called in editor mode.');
                });

                it('should throw error if called from site view modes', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('site');
                    Base.resizeComponent({width: 200}, jasmine.createSpy('onSuccess'));
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('site is an invalid view mode. This function can only be called in editor mode.');
                });
            });

            describe('getComponentInfo', function () {
                it('should throw error in case callback is not given', function () {
                    Base.getComponentInfo();
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - callback - should be of type Function');
                });

                it('should throw error in case callback is of type object', function () {
                    Base.getComponentInfo({});
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - callback - should be of type Function');

                });

                it('should send the correct message', function () {
                    var callback = jasmine.createSpy();

                    Base.getComponentInfo(callback);

                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_COMPONENT_INFO, 'Wix', null, callback);
                });
            });

            describe('addEventListener', function () {

                it('should return callId', function () {
                    var callbackId = Base.addEventListener(Events.THEME_CHANGE, function () {
                    });
                    expect(callbackId).toBeDefined();
                });

                describe('site saved', function () {

                    it('should add site-saved listener', function () {
                        reporter.reportSdkError.and.callThrough();
                        expect(function () {
                            Base.addEventListener(Events.SITE_SAVED, function () {
                            });
                        }).not.toThrow();
                        expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    });

                    it('should call site-saved callback', function (done) {
                        postMessage.sendMessage.and.callThrough();
                        postMessage.init();
                        var callback = jasmine.createSpy('site saved callback').and.callFake(function () {
                            expect(callback).toHaveBeenCalled();
                            done();
                        });

                        var callbackId = Base.addEventListener(Events.SITE_SAVED, callback);

                        var msgData = {
                            intent: 'addEventListener',
                            callId: callbackId,
                            type: 'message',
                            compId: 12345,
                            eventType: Events.SITE_SAVED,
                            data: {
                                name: 'lo'
                            }
                        };
                        var msg = JSON.stringify(msgData);

                        window.postMessage(msg, '*');
                    });
                });
            });

            describe('replaceSectionState', function () {
                it('should throw error when called in editor mode', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('editor');

                    Base.replaceSectionState('new state');

                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid view mode. This function cannot be called in editor mode. Supported view modes are: [preview, site]');
                });

                it('should throw error when state is not provided', function () {
                    Base.replaceSectionState();

                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - state');
                });

                it('should throw error when state is not a String', function () {
                    Base.replaceSectionState(13);

                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - state should be of type String');
                });

                it('should send a post message with correct command', function () {
                    Base.replaceSectionState('new state');

                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.REPLACE_SECTION_STATE, 'Wix', {state: 'new state'});
                });
            });

            describe('logOutCurrentMember', function () {

                it('should report error when view mode is editor', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('editor');

                    Base.logOutCurrentMember();
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid view mode. This function cannot be called in editor/preview mode. Supported view mode is: [site]');
                });

                describe('view mode viewer', function () {

                    beforeEach(function () {
                        spyOn(viewMode, 'getViewMode').and.returnValue('site');
                    });

                    it('should reprot error if options is not an object or a function', function () {
                        Base.logOutCurrentMember(1);

                        expect(postMessage.sendMessage).not.toHaveBeenCalled();
                        expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - options, must be an object');
                    });

                    it('should reprot error if onError is not an function', function () {
                        Base.logOutCurrentMember({}, 1);

                        expect(postMessage.sendMessage).not.toHaveBeenCalled();
                        expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - onError, must be a function');
                    });

                    it('should send post message if options is an object and onError is a function', function () {
                        Base.logOutCurrentMember({language: 'en'}, function () {
                        });

                        expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.LOG_OUT_CURRENT_MEMBER, 'Wix', {language: 'en'}, jasmine.any(Function));
                        expect(reporter.reportSdkError).not.toHaveBeenCalledWith();
                    });

                    it('should send post message if options is a function', function () {
                        Base.logOutCurrentMember(function () {
                        });

                        expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.LOG_OUT_CURRENT_MEMBER, 'Wix', {}, jasmine.any(Function));
                        expect(reporter.reportSdkError).not.toHaveBeenCalledWith();
                    });

                    it('should send post message no params given', function () {
                        Base.logOutCurrentMember();

                        expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.LOG_OUT_CURRENT_MEMBER, 'Wix', {});
                        expect(reporter.reportSdkError).not.toHaveBeenCalledWith();
                    });

                    it('should call onError callback when handler retuns an error', function () {
                        postMessage.sendMessage.and.callFake(function (m, namespace, args, callback) {
                            return callback({
                                onError: 'error'
                            });
                        });
                        var onErrorSpy = jasmine.createSpy('onError');

                        Base.logOutCurrentMember({}, onErrorSpy);

                        expect(onErrorSpy).toHaveBeenCalledWith({
                            onError: 'error'
                        });
                    });
                });


            });

            describe('getSitePages', function () {
                it('should send the correct message', function () {
                    var callback = jasmine.createSpy();

                    Base.getSitePages(callback);

                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_SITE_PAGES, 'Wix', {}, callback);
                });

                it('should send the correct message with no callback if not given', function () {
                    Base.getSitePages();

                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_SITE_PAGES, 'Wix', {}, undefined);
                });

                it('should ignore other keys in options param', function () {
                    var callback = jasmine.createSpy();

                    Base.getSitePages({key: 'key'}, callback);
                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_SITE_PAGES, 'Wix', {}, callback);
                });

                it('should add includePagesUrl param to args if it is given', function () {
                    var callback = jasmine.createSpy();
                    Base.getSitePages({includePagesUrl: true}, callback);
                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_SITE_PAGES, 'Wix', {includePagesUrl: true}, callback);
                });

                it('should throw error in case options param is not object', function () {
                    var callback = jasmine.createSpy();
                    Base.getSitePages('parama', callback);
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - options should be of type Object');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should throw error in case includePagesUrl param is not boolean', function () {
                    var callback = jasmine.createSpy();
                    Base.getSitePages({includePagesUrl: {}}, callback);
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - includePagesUrl should be of type boolean');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should throw error in case callback is not of type function', function () {
                    var callback = {};
                    Base.getSitePages({includePagesUrl: true}, callback);
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - callback should be of type Function');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should ignore params after callback', function () {
                    var callback = jasmine.createSpy();
                    Base.getSitePages(callback, {includePagesUrl: true});
                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_SITE_PAGES, 'Wix', {}, callback);
                });
            });

            describe('requestLogin', function () {

                it('should report error when view mode is editor', function () {
                    spyOn(viewMode, 'getViewMode').and.returnValue('editor');

                    Base.requestLogin(function () {
                    });
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid view mode. This function cannot be called in editor/preview mode. Supported view mode is: [site]');
                });

                describe('on site view mode', function () {
                    beforeEach(function () {
                        this.onSuccessSpy = jasmine.createSpy('onSuccess');
                        this.onCancelSpy = jasmine.createSpy('onCancel');
                        spyOn(viewMode, 'getViewMode').and.returnValue('site');
                    });

                    it('should send post message', function () {
                        Base.requestLogin();

                        expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SM_REQUEST_LOGIN, 'Wix', {}, jasmine.any(Function));
                        expect(reporter.reportSdkError).not.toHaveBeenCalledWith();
                    });

                    it('should send post message if first param is a function', function () {
                        Base.requestLogin(this.onSuccessSpy);

                        expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SM_REQUEST_LOGIN, 'Wix', {callOnCancel: false}, jasmine.any(Function));
                    });

                    it('should send post message if first param is a function and second is a function too', function () {
                        Base.requestLogin(this.onSuccessSpy, this.onCancelSpy);

                        expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SM_REQUEST_LOGIN, 'Wix', {callOnCancel: true}, jasmine.any(Function));
                    });

                    it('should send post message if first param is an object and second is a function', function () {
                        Base.requestLogin({mode: 'login', language: 'es'}, this.onSuccessSpy);

                        expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SM_REQUEST_LOGIN, 'Wix', {
                            mode: 'login',
                            language: 'es',
                            callOnCancel: false
                        }, jasmine.any(Function));
                    });

                    it('should send post message if first param is an object, second is a function and third is a function too', function () {
                        Base.requestLogin({mode: 'login', language: 'es'}, this.onSuccessSpy, this.onCancelSpy);

                        expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SM_REQUEST_LOGIN, 'Wix', {
                            mode: 'login',
                            language: 'es',
                            callOnCancel: true
                        }, jasmine.any(Function));
                    });

                    it('should send post message if first param is an object with only language property', function () {
                        Base.requestLogin({language: 'es'});

                        expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SM_REQUEST_LOGIN, 'Wix', {language: 'es'}, jasmine.any(Function));
                    });

                    it('should send post message if first param is an object with only mode property', function () {
                        Base.requestLogin({mode: 'signup'});

                        expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SM_REQUEST_LOGIN, 'Wix', {mode: 'signup'}, jasmine.any(Function));
                    });

                    it('should invoke the onSuccess callback if it was given and wasCancelled is undefined + options is given', function () {
                        postMessage.sendMessage.and.callFake(function (msgType, namespace, options, callback) {
                            return callback({});
                        });

                        Base.requestLogin({mode: 'login'}, this.onSuccessSpy, this.onCancelSpy);
                        expect(this.onSuccessSpy).toHaveBeenCalled();
                        expect(this.onCancelSpy).not.toHaveBeenCalled();
                    });

                    it('should invoke the onCancel callback if it was given and wasCancelled is true + options is given', function () {
                        postMessage.sendMessage.and.callFake(function (msgType, namespace, options, callback) {
                            return callback({
                                wasCancelled: true
                            });
                        });

                        Base.requestLogin({mode: 'login'}, this.onSuccessSpy, this.onCancelSpy);
                        expect(this.onCancelSpy).toHaveBeenCalledWith({
                            wasCancelled: true
                        });
                        expect(this.onSuccessSpy).not.toHaveBeenCalled();
                    });

                    it('should invoke the onSuccess callback if it was given and wasCancelled is undefined + options is not given', function () {
                        postMessage.sendMessage.and.callFake(function (msgType, namespace, options, callback) {
                            return callback({});
                        });

                        Base.requestLogin(this.onSuccessSpy, this.onCancelSpy);
                        expect(this.onSuccessSpy).toHaveBeenCalled();
                        expect(this.onCancelSpy).not.toHaveBeenCalled();
                    });

                    it('should invoke the onCancel callback if it was given and wasCancelled is true + options is not given', function () {
                        postMessage.sendMessage.and.callFake(function (msgType, namespace, options, callback) {
                            return callback({
                                wasCancelled: true
                            });
                        });

                        Base.requestLogin(this.onSuccessSpy, this.onCancelSpy);
                        expect(this.onCancelSpy).toHaveBeenCalledWith({
                            wasCancelled: true
                        });
                        expect(this.onSuccessSpy).not.toHaveBeenCalled();
                    });

                    it('should report an error if second param is not a function', function () {
                        Base.requestLogin({}, 123);

                        expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - onSuccess must be of type Function');
                        expect(postMessage.sendMessage).not.toHaveBeenCalled();
                    });

                    it('should report an error if first param is a function but second param is not a function', function () {
                        Base.requestLogin(this.onSuccessSpy, 123);

                        expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - onSuccess must be of type Function');
                        expect(postMessage.sendMessage).not.toHaveBeenCalled();
                    });

                    it('should report an error if mode is invalid', function () {
                        Base.requestLogin({mode: 'test'}, this.onSuccessSpy);

                        expect(reporter.reportSdkError).toHaveBeenCalledWith("Invalid argument - mode can only be 'login' or 'signup'");
                        expect(postMessage.sendMessage).not.toHaveBeenCalled();
                    });
                });
            });

            describe('navigateTo', function () {

                it('should report error in editor mode', function(){
                    spyOn(viewMode, 'getViewMode').and.returnValue('editor');

                    Base.navigateTo();

                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid view mode. This function cannot be called in editor mode. Supported view modes are: [preview, site]');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should report an error if linkData is not passed', function(){
                    Base.navigateTo();

                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - linkData of type Object');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should report an error if onFailure is not a function', function(){
                    Base.navigateTo({}, 1);

                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - onFailure must be of type Function');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should send message if params are valid', function(){
                    Base.navigateTo({}, function(){});

                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.NAVIGATE_TO, 'Wix', {link: {}}, jasmine.any(Function));
                });

                it('should open external links', function () {
                    spyOn(window, 'open');

                    Base.navigateTo({type: "ExternalLink", target: "_blank", url: "http://www.ynet.co.il"});

                    expect(window.open).toHaveBeenCalledWith('http://www.ynet.co.il', '_blank');
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.NAVIGATE_TO, 'Wix', {
                        link: {
                            type: "ExternalLink",
                            target: "_blank",
                            url: "http://www.ynet.co.il"
                        }
                    },undefined);
                });
            });

            describe('getAdsOnPage', function() {

                it('should report error if called without onSuccess', function () {
                    Base.getAdsOnPage();

                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory argument - onSuccess function must be specified');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should report error if called with onSuccess which is not a function', function () {
                    Base.getAdsOnPage({});

                    expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory argument - onSuccess function must be specified');
                    expect(postMessage.sendMessage).not.toHaveBeenCalled();
                });

                it('should send message in case onSuccess function is supplied', function () {
                    var onSuccess = jasmine.createSpy('onSuccess');

                    Base.getAdsOnPage(onSuccess);

                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_ADS_ON_PAGE, 'Wix', undefined, onSuccess);
                });

            });
        });
    });
