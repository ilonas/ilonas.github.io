define(['privates/core', 'privates/postMessage', 'privates/styles',  'privates/templateUtils', 'Styles', 'privates/reporter'], function(core, postMessage, styles, templateUtils, Styles, reporter) {

    describe('Styles', function () {
        describe('getStyle', function() {
            beforeEach(function(){
                styles.updateStylesCache({
                    fonts: {
                        fontsMeta: 'someObject',
                        imageSpriteUrl: 'someUrl',
                        cssUrls: []
                    },
                    style: {
                        colors: {}
                    },
                    siteColors: [{
                        "name": "color_1",
                        "value": "#FFFFFF"
                    }],
                    siteTextPresets: 'siteTextPresets'
                });
            });

            it('getEditorFonts - should return fontsMeta from cache', function(done) {
                Styles.getEditorFonts(function(fonts){
                    expect(fonts).toEqual('someObject');
                    done()
                });
            });

            it('getStyleParams - should return style from cache', function(done){
                Styles.getStyleParams(function (styleParams) {
                    expect(styleParams).toEqual({
                        colors: {}
                    });
                    done();
                });
            });

            it('getFontsSpriteUrl', function(done) {
                Styles.getFontsSpriteUrl(function (fontsSpriteUrl) {
                    expect(fontsSpriteUrl).toEqual('someUrl');
                    done();
                });
            });

            it('getSiteColors - should return siteColors from cache', function(done) {
                Styles.getSiteColors(function (siteColors) {
                    expect(siteColors).toEqual([{
                        "name": "color_1",
                        "value": "#FFFFFF",
                        "reference" : "white/black"
                    }]);
                    done();
                });
            });

            it('getSiteColors with no callback - should return siteColors from cache', function() {
                var siteColors = Styles.getSiteColors();
                expect(siteColors).toEqual([{
                    "name": "color_1",
                    "value": "#FFFFFF",
                    "reference" : "white/black"
                }]);
            });

            it('siteTextPresets', function(done) {
                Styles.getSiteTextPresets(function (siteTextPresets) {
                    expect(siteTextPresets).toEqual('siteTextPresets');
                    done();
                });
            });
        });

        describe('getters', function(){
            var presets = {
                "Title": {
                    "editorKey": "font_0",
                    "lineHeight": "1.4em",
                    "style": "normal",
                    "weight": "normal",
                    "size": "28px",
                    "fontFamily": "lucida sans unicode",
                    "value": "font:normal normal normal 28px/1.4em \"lucida sans unicode\",\"lucida grande\",sans-serif;"
                }
            };

            var font = {
                "size": 16,
                "style": {
                    "bold": false,
                    "italic": false,
                    "underline": false
                },
                "family": "arial",
                "cssFontFamily": "'arial','ｍｓ ｐゴシック','ms pgothic','돋움','dotum','helvetica','sans-serif'",
                "preset": "Custom",
                "fontStyleParam": true,
                "value": "font:normal normal normal 16px/20px arial,\"ｍｓ ｐゴシック\",\"ms pgothic\",\"돋움\",dotum,helvetica,sans-serif;"
            };

            beforeEach(function(){
                styles.updateStylesCache({
                    fonts: {
                        fontsMeta: 'someObject',
                        imageSpriteUrl: 'someUrl',
                        cssUrls: []
                    },
                    style: {
                        colors:{
                            "wix-param-color": {
                                "themeName": "color_21",
                                "value": "#F4C3B1"
                            }
                        },
                        fonts: {
                            "wix-param-font": font
                        }
                    },
                    siteColors: [{
                        "name": "color_1",
                        "value": "#FFFFFF"
                    }],
                    siteTextPresets: presets
                });
            });

            it('getStyleFontByKey', function() {
                var fontByKey = Styles.getStyleFontByKey('wix-param-font');
                expect(fontByKey).toEqual(font);
            });

            it('getStyleColorByKey', function() {
                var colorByKey = Styles.getStyleColorByKey('wix-param-color');
                expect(colorByKey).toEqual('#F4C3B1');
            });

            it('getStyleColorByReference', function() {
                var colorByRef = Styles.getColorByreference('white/black');
                expect(colorByRef).toEqual({
                    reference: "white/black",
                    value: "#FFFFFF"
                });
            });

            it('getStyleFontByReference', function(){
                var titleFont = Styles.getStyleFontByReference('Title');
                expect(titleFont).toEqual(presets.Title);
            });
        });

        describe('setters', function() {
            beforeEach(function () {
                spyOn(postMessage, 'sendMessage');
            });

            it('setColorParam', function() {
                var key = 'wix-param-color';
                var param = {
                    type: 'color',
                    key: 'wix-param-color',
                    param: {
                        value: {
                            color: {name: 'color_23', reference: 'color-13', value: '#E05726'},
                            cssColor: '#E05726'
                        }
                    }
                };

                Styles.setColorParam(key, {value: param.param.value});
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SET_STYLE_PARAM, 'Styles', param, jasmine.any(Function));
            });

            it('setNumberParam', function(){
                var key = 'wix-param-number';
                var param = {type: 'number', key: 'wix-param-number', param: {value: 3}};

                Styles.setNumberParam(key, {value: param.param.value});
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SET_STYLE_PARAM, 'Styles', param, jasmine.any(Function));
            });

            it('setBooleanParam', function(){
                var key = 'wix-param-boolean';
                var param = {type: 'boolean', key: 'wix-param-boolean', param: {value: false}};

                Styles.setBooleanParam(key, {value: param.param.value});
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SET_STYLE_PARAM, 'Styles', param, jasmine.any(Function));
            });

            it('setFontParam', function(){
                var key = 'wix-param-font';
                var param = {
                    type: 'font', key: 'wix-param-font', param: {
                        value: {
                            'value': 'americantypwrteritcw01--731025',
                            'index': 1,
                            'fontParam': true,
                            'cssFontFamily': '\'americantypwrteritcw01--731025\',\'americantypwrteritcw02--737091\',\'serif\'',
                            'family': 'americantypwrteritcw01--731025'
                        }
                    }
                };
                Styles.setFontParam(key, {value: param.param.value});
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SET_STYLE_PARAM, 'Styles', param, jasmine.any(Function));
            });

            describe('setStyleParams', function () {
                var onError;
                var onSuccess;

                beforeEach(function () {
                    onError = jasmine.createSpy('onError');
                    onSuccess = jasmine.createSpy('onSuccess');
                    spyOn(reporter, 'reportSdkError');
                });

                it('should set array of style params with only one post message', function () {
                    var styleObjArr = [
                        {
                            "type": "font",
                            "key": "font_key",
                            "value": {
                                "value": {
                                    "value": "layout4",
                                    "fontStyleParam": false
                                }
                            }
                        },
                        {
                            "type": "boolean",
                            "key": "booleanKeyTruthy",
                            "value": {
                                "value": true
                            }
                        },
                        {
                            "type": "boolean",
                            "key": "booleanKeyFalsy",
                            "value": {
                                "value": false
                            }
                        },
                        {
                            "type": "number",
                            "key": "numberParam",
                            "value": {
                                "value": 6
                            }
                        },
                        {
                            "type": "color",
                            "key": "customRgbaColor",
                            "value": {
                                "value": {
                                    "color": false,
                                    "opacity": 0,
                                    "rgba": "rgba(16,63,84,0)"
                                }
                            }
                        },
                        {
                            "type": "color",
                            "key": "customHexadecimalColor",
                            "value": {
                                "value": {
                                    "color": false,
                                    "opacity": 0,
                                    "cssColor": "#123ABC"
                                }
                            }
                        },
                        {
                            "type": "color",
                            "key": "hexadecimalThemeColor",
                            "value": {
                                "value": {
                                    "cssColor": "#B6E8E3",
                                    "color": {
                                        "name": "color_21",
                                        "value": "#B6E8E3",
                                        "reference": "color-11"
                                    }
                                }
                            }
                        },
                        {
                            "type": "color",
                            "key": "rgbaThemeColor",
                            "value": {
                                "value": {
                                    "color": {
                                        "name": "color_20",
                                        "value": "#103F54",
                                        "reference": "color-10"
                                    },
                                    "opacity": 0,
                                    "rgba": "rgba(16,63,84,0)"
                                }
                            }
                        }
                    ];

                    var styleObjArrMapped = styleObjArr.map(function (current) {
                        return {
                            key: current.key,
                            type: current.type,
                            param: current.value
                        };
                    });

                    Styles.setStyleParams(styleObjArr, onSuccess, onError);
                    expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.SET_STYLE_PARAM, 'Styles', styleObjArrMapped, jasmine.any(Function));
                    expect(reporter.reportSdkError).not.toHaveBeenCalled();
                });

                it('should throw an exception if styleObjArr type different than array', function () {
                    Styles.setStyleParams();
                    expect(reporter.reportSdkError).toHaveBeenCalled();
                });

                it('should throw an exception if styleObjArr contain non object', function () {
                    Styles.setStyleParams([null]);
                    expect(reporter.reportSdkError).toHaveBeenCalledWith('styleObjArr[0] is not a valid style object.');
                });

                it('should not set any style and report an error when type isn\'t valid', function () {
                    var styleObjArr = [
                        {
                            "type": "masehu_yetzirati",
                            "key": "key",
                            "value": {
                                "value": {}
                            }
                        }
                    ];

                    Styles.setStyleParams(styleObjArr, onSuccess, onError);
                    expect(onError).toHaveBeenCalled();
                    expect(onSuccess).not.toHaveBeenCalled();
                    expect(reporter.reportSdkError).toHaveBeenCalled();
                });

                it('should not set any style and report an error when key isn\'t valid', function () {
                    var styleObjArr = [
                        {
                            "type": "masehu_yetzirati",
                            "value": {
                                "value": {}
                            }
                        }
                    ];

                    Styles.setStyleParams(styleObjArr, onSuccess, onError);
                    expect(onError).toHaveBeenCalled();
                    expect(onSuccess).not.toHaveBeenCalled();
                    expect(reporter.reportSdkError).toHaveBeenCalled();
                });

                it('should not set any style and report an error when value isn\'t valid', function () {
                    var styleObjArr = [
                        {
                            "type": "masehu_yetzirati",
                            "key": "key"
                        }
                    ];

                    Styles.setStyleParams(styleObjArr, onSuccess, onError);
                    expect(onError).toHaveBeenCalled();
                    expect(onSuccess).not.toHaveBeenCalled();
                    expect(reporter.reportSdkError).toHaveBeenCalled();
                });
            });

        });

        describe('getStyleId', function(){
            beforeEach(function () {
                spyOn(reporter, 'reportSdkError');
                spyOn(postMessage, 'sendMessage');
            });

           it('should report error if callback was not provided', function(){
               Styles.getStyleId();
               expect(reporter.reportSdkError).toHaveBeenCalled();
           });

            it('should report error if callback is not a function', function(){
                Styles.getStyleId(13);
                expect(reporter.reportSdkError).toHaveBeenCalled();
            });

            it('should send a post message', function(){
                Styles.getStyleId(function(){});
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_STYLE_ID, 'Styles', {}, jasmine.any(Function));
            });
        });

        describe('getStyleParamsByStyleId', function () {
            beforeEach(function () {
                spyOn(reporter, 'reportSdkError');
                this.postMessageSpy = spyOn(postMessage, 'sendMessage');
                this.onSuccessSpy = jasmine.createSpy('onSuccess');
                this.onFailureSpy = jasmine.createSpy('onFailure');
            });

            it('should report error if styleId was not provided', function () {
                Styles.getStyleParamsByStyleId();

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory arguments - styleId & onSuccess must be specified');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error if styleId is not a string', function () {
                Styles.getStyleParamsByStyleId(1, 1);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - styleId must be of type string');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error if onSuccess was not provided', function () {
                Styles.getStyleParamsByStyleId('styleId');

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Mandatory arguments - styleId & onSuccess must be specified');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error if onSuccess is not a function', function () {
                Styles.getStyleParamsByStyleId('styleId', 1);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - onSuccess must be of type Function');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report error if onFailure is not a function', function () {
                Styles.getStyleParamsByStyleId('styleId', function () {
                }, 1);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid argument - onFailure must be of type Function');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should send a post message if params are correct', function () {
                Styles.getStyleParamsByStyleId('styleId', function () {
                }, function () {
                });

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_STYLE_PARAMS_BY_STYLE_ID, 'Styles', {styleId: 'styleId'}, jasmine.any(Function));
            });

            it('should call onSuccess callback with normalized colors if post message succeeded', function () {
                this.postMessageSpy.and.callFake(function (msg, ns, args, callback) {
                    return callback({
                        booleans: {},
                        colors: {
                            gallery_background: {
                                themeName: "color_1",
                                value: "#8B0000"
                            }
                        },
                        fonts: {},
                        googleFontsCssUrl: "",
                        numbers: {},
                        uploadFontFaces: ""
                    });
                });

                Styles.getStyleParamsByStyleId('styleId', this.onSuccessSpy);

                expect(this.onSuccessSpy).toHaveBeenCalledWith({
                        booleans: {},
                        colors: {
                            gallery_background: {
                                themeName: "white/black",
                                value: "#8B0000"
                            }
                        },
                        fonts: {},
                        googleFontsCssUrl: "",
                        numbers: {},
                        uploadFontFaces: ""
                    }
                );
            });

            it('should call onError callback when editor retuns an error', function () {
                this.postMessageSpy.and.callFake(function (m, ns, args, callback) {
                    return callback({
                        error: {
                            message: 'error'
                        }
                    });
                });

                Styles.getStyleParamsByStyleId('styleId', this.onSuccessSpy, this.onFailureSpy);

                expect(this.onSuccessSpy).not.toHaveBeenCalled();
                expect(this.onFailureSpy).toHaveBeenCalledWith({
                    message: 'error'
                });
            });

        })
    });
});
