define(['Editor', 'privates/reporter', 'privates/postMessage', 'privates/viewMode'], function (Editor, reporter, postMessage, viewMode) {
    'use strict';

    describe('Editor', function () {

        var namespace = 'Editor';

        beforeEach(function () {
            spyOn(reporter, 'reportSdkError');
            spyOn(postMessage, 'sendMessage');
            spyOn(viewMode, 'getViewMode').and.returnValue('editor');
        });

        describe('isApplicationInstalled', function(){

            beforeEach(function(){
                this.callback = jasmine.createSpy('callback');
            });

            it('should report an error if appDefinitionId is not passed', function () {
                Editor.isApplicationInstalled();

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - appDefinitionId - should be of type String');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report an error if appDefinitionId is not a string', function () {
                Editor.isApplicationInstalled(1);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - appDefinitionId - should be of type String');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report an error if callback is not passed', function () {
                Editor.isApplicationInstalled('appDefId');

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - callback - should be of type Function');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report an error if callback is not a function', function () {
                Editor.isApplicationInstalled('appDefId', 1);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - callback - should be of type Function');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should send post message if params are valid', function(){
                Editor.isApplicationInstalled('appDefId', this.callback);

                expect(reporter.reportSdkError).not.toHaveBeenCalled();
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.IS_APPLICATION_INSTALLED, namespace, {
                    appDefinitionId: 'appDefId'
                }, this.callback);
            });
        });
    });
});
