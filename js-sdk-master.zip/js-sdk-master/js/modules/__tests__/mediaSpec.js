define(['Media', 'privates/utils', 'privates/reporter'], function (Media, utils, reporter) {
    'use strict';

    ['http:', 'https:'].forEach(function (protocol) {
        describe('Media tests ' + protocol, function () {
            beforeEach(function () {
                spyOn(utils, 'protocol').and.returnValue(protocol);
                spyOn(reporter, 'reportSdkError');
            });

            it('should get image url', function () {
                expect(Media.getImageUrl('a.png')).toBe('https://static.wixstatic.com/media/a.png');
            });

            it('should get resized image url', function () {
                expect(Media.getResizedImageUrl('a.png', 50, 50))
                    .toBe('https://static.wixstatic.com/media/a.png/v1/fill/w_50,h_50,q_85,usm_0.66_1.00_0.01/a.png');
            });

            it('should get audio url', function () {
                expect(Media.getAudioUrl('a.mp3')).toBe('https://music.wixstatic.com/mp3/a.mp3');
            });

            it('should get audio url for standard type', function () {
                expect(Media.getAudioUrl('a.mp3', Media.AudioType.STANDARD)).toBe('https://music.wixstatic.com/mp3/a.mp3');
            });

            it('should get audio url for preview type', function () {
                expect(Media.getAudioUrl('a.mp3', Media.AudioType.PREVIEW)).toBe('https://static.wixstatic.com/preview/a.mp3');
            });

            it('should get audio url for short preview type', function () {
                expect(Media.getAudioUrl('a.mp3', Media.AudioType.SHORT_PREVIEW)).toBe('https://static.wixstatic.com/a.mp3');
            });

            it('should report sdk error when audioType is invalid', function () {
                Media.getAudioUrl('a.mp3', 'INVALID_TYPE');
                expect(reporter.reportSdkError).toHaveBeenCalled();
            });

            it('should get document url', function () {
                expect(Media.getDocumentUrl('a.pdf')).toBe('https://docs.wixstatic.com/ugd/a.pdf');
            });

            it('should get swf url', function () {
                expect(Media.getSwfUrl('a.swf')).toBe('https://static.wixstatic.com/media/a.swf');
            });

            it('should get preview secure music url', function () {
                expect(Media.getPreviewSecureMusicUrl('a.mp3')).toBe('https://static.wixstatic.com/preview/a.mp3');
            });
        });
    })
});