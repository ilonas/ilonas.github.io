define(['lodash', 'Activities', 'privates/sharedAPI', 'privates/postMessage', 'privates/responseHandlers', 'privates/reporter', 'moment', 'privates/viewMode'],
    function (_, Activities, sharedAPI, postMessage, responseHandlers, reporter, moment, viewMode) {
    'use strict';

    describe('Activities tests', function () {
        var givenCursorObj = {
            nextCursor: "112",
            previousCursor: "332",
            results: [{
                data: {
                    contact: '1'
                }
            }]
        };

        var postMessageMock;

        beforeEach(function () {
            spyOn(reporter, 'reportSdkError');
            postMessageMock = spyOn(postMessage, 'sendMessage');
        });

        describe('postActivity test', function () {
            it('should report error if view mode is not site', function () {
                spyOn(viewMode, 'getViewMode').and.callFake(function () {
                    return "editor";
                });

                var onSuccess = jasmine.createSpy();
                Activities.postActivity({}, onSuccess);

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Invalid view mode. This function cannot be called in editor/preview mode. Supported view mode is: [site]');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should post message when view mode is site', function () {
                spyOn(viewMode, 'getViewMode').and.returnValue('site');

                Activities.postActivity({}, function () {});
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.POST_ACTIVITY, 'Activities', {activity:{}}, jasmine.any(Function));
            });
        });

        describe('getActivities tests', function () {
            it('should report a message when onSuccess callback is missing', function () {
                var now = moment();
                Activities.getActivities({until: now.toISOString(), from: now.toISOString()});

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - onSuccess, must be a function');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();

            });

            it('should report a message when onFailure callback is missing', function () {
                var now = moment();
                Activities.getActivities(function() {}, {until: now.toISOString(), from: now.toISOString()});

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - onFailure, must be a function');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should invoke the onSuccess callback when query is valid', function(){
                postMessageMock.and.callFake(function (m, n, args , callback) {
                    return callback({
                        data: givenCursorObj
                    });
                });

                spyOn(responseHandlers, 'handleCursorResponse');

                var success = jasmine.createSpy();
                var now = moment();
                var error = jasmine.createSpy();

                Activities.getActivities(success, error, {until: now.toISOString(), from: now.toISOString()});

                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_ACTIVITIES, 'Activities', {query : {until: now.toISOString(), from: now.toISOString()}}, jasmine.any(Function));
                expect(responseHandlers.handleCursorResponse).toHaveBeenCalledWith({data: givenCursorObj}, success, error, postMessage.MessageTypes.GET_ACTIVITIES);
            });

            it('should invoke the onFailure callback with Wix.Error.WIX_ERROR when an error happened on the handler', function() {
                postMessageMock.and.callFake(function (m, n, args , callback) {
                    return callback({
                        error: {
                            errorCode: 500
                        }
                    });
                });

                spyOn(responseHandlers, 'handleCursorResponse');

                var error = jasmine.createSpy();
                var success = jasmine.createSpy();

                Activities.getActivities(success, error, {from: moment().toISOString(), until: moment().toISOString()});
                expect(responseHandlers.handleCursorResponse).toHaveBeenCalledWith({error: { errorCode: 500 }}, success, error, postMessage.MessageTypes.GET_ACTIVITIES);
            });
        });

        describe('getActivityById tests', function () {
            it('should report a message when id is missing', function () {
                Activities.getActivityById();

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - id, must be a string');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report a message when onSuccess callback is missing', function () {
                Activities.getActivityById('11');

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - onSuccess, must be a function');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should report a message when onFailure callback is missing', function () {
                Activities.getActivityById('11', function() {});

                expect(reporter.reportSdkError).toHaveBeenCalledWith('Missing mandatory argument - onFailure, must be a function');
                expect(postMessage.sendMessage).not.toHaveBeenCalled();
            });

            it('should send message and call responseHandlers with the right arguments', function() {
                postMessageMock.and.callFake( function (m, n, args , callback) {
                    return callback({
                        data: 'data'
                    });
                });

                responseHandlers.handleDataResponse = jasmine.createSpy();

                var success = jasmine.createSpy();
                var error = jasmine.createSpy();

                Activities.getActivityById('1', success, error);

                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_ACTIVITY_BY_ID, 'Activities', {id : '1'}, jasmine.any(Function));
                expect(responseHandlers.handleDataResponse).toHaveBeenCalledWith({data: 'data'}, success, error);
            });
        });

        describe('getUserSessionToken tests', function () {
            it('should send message', function () {
                var success = jasmine.createSpy('success');

                Activities.getUserSessionToken(success);
                expect(postMessage.sendMessage).toHaveBeenCalledWith(postMessage.MessageTypes.GET_USER_SESSION, 'Activities', null, success);
            });
        });

    });

});