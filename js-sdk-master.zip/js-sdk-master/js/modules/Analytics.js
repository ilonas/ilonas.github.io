/**
 * Functions that allow to list pixels to get website events and also allows to report on website events.
 * @memberof Wix
 * @namespace Analytics
 */
define(['privates/utils', 'privates/reporter', 'privates/postMessage', 'privates/viewMode', 'privates/analytics'], function (utils, reporter, postMessage, viewMode, analytics) {

    var namespace = 'Analytics';

    var registerCampaignPixel = function (pixelType, pixelId){
        analytics.registerCampaignPixel(namespace, pixelType, pixelId);
    };

    var reportCampaignEvent = function(eventType, data){
        analytics.reportCampaignEvent(namespace, eventType, data);
    };

    return {
        /**
         * An enum of pixel types that are supported by Wix.Analytics.registerCampaignPixel
         * @enum
         * @memberof Wix.Analytics
         * @since 1.74.0
         */
        PixelType: {
            /**
             * Facebook pixel (see https://www.facebook.com/business/help/952192354843755)
             * @since 1.74.0
             */
            FACEBOOK: analytics.PIXEL_TYPES.FACEBOOK
        },

        /**
         * An enum of pixel event types and their parameters and required parameters that are supported by Wix.Analytics.reportCampaignEvent
         * @enum
         * @memberof Wix.Analytics
         * @since 1.74.0
         */
        PixelEventType: {
            /**
             * When a key page is viewed such as a product page, e.g. landing on a product detail page
             * @since 1.74.0
             */
            VIEW_CONTENT: analytics.EVENT_TYPES.VIEW_CONTENT,
            /**
             * When a search is made, e.g. when a product search query is made
             * @since 1.74.0
             */
            SEARCH: analytics.EVENT_TYPES.SEARCH,
            /**
             * When a product is added to the shopping cart, e.g. click on add to cart button
             * @since 1.74.0
             */
            ADD_TO_CART: analytics.EVENT_TYPES.ADD_TO_CART,
            /**
             * When a product is added to a wishlist, e.g. click on add to wishlist button
             * @since 1.74.0
             */
            ADD_TO_WISHLIST: analytics.EVENT_TYPES.ADD_TO_WISHLIST,
            /**
             * When a person enters the checkout flow prior to completing the checkout flow, e.g. click on checkout button
             * @since 1.74.0
             */
            INITIATE_CHECKOUT: analytics.EVENT_TYPES.INITIATE_CHECKOUT,
            /**
             * When a payment information is added in the checkout flow, e.g. click / LP on save billing info button
             * @since 1.74.0
             */
            ADD_PAYMENT_INFO: analytics.EVENT_TYPES.ADD_PAYMENT_INFO,
            /**
             * When a purchase is made or checkout flow is completed, e.g. landing on thank you/confirmation page
             * @since 1.74.0
             */
            PURCHASE: analytics.EVENT_TYPES.PURCHASE,
            /**
             * When a sign up is completed, e.g. click on pricing, signup for trial
             * @since 1.74.0
             */
            LEAD: analytics.EVENT_TYPES.LEAD,
            /**
             * When a registration form is completed, e.g. complete subscription/signup for a service
             * @since 1.74.0
             */
            COMPLETE_REGISTRATION: analytics.EVENT_TYPES.COMPLETE_REGISTRATION,
            /**
             * Any custom events a person chooses to report
             * @since 1.74.0
             */
            CUSTOM_EVENT: analytics.EVENT_TYPES.CUSTOM_EVENT
        },

        /**
         * registers and initializes a certain predefined Facebook pixel campaign with the public site
         * (see for example https://www.facebook.com/business/help/952192354843755)
         * The function accepts a pixel type (i.e Facebook or Google), and a pixel id - an id that was predefined by Facebook/Google and is attached
         * to some Facebook/Google account
         *
         * @function
         * @memberof Wix.Analytics
         * @since 1.74.0
         * @param {Wix.Analytics.PixelType} pixelType the type of pixel that needs to be initialized (i.e facebook or google)
         * @param {String} pixelId the pixel identifier to be initialized
         *
         * @example
         * Wix.Analytics.registerCampaignPixel(Wix.Analytics.PixelType.FACEBOOK, '1234567890');
         */
        registerCampaignPixel: registerCampaignPixel,

        /**
         * reports to facebook predefined and preregistered pixel about an event that occurred on the app on the public site.
         * the event will be fired to all registered pixels on the site, whether defined on this app, or on other apps using the sdk (or directly from within the site)
         * (see for example https://www.facebook.com/business/help/952192354843755)
         * The function accepts an event type and a data object that contains all event details and parameters.
         *
         * @function
         * @memberof Wix.Analytics
         * @since 1.74.0
         * @param {Wix.Analytics.PixelEventType[event].eventName} eventType the name of the type of event to report
         * @param {Object} data object with event parameters out of Wix.Analytics.PixelEventType[event].parameters,
         * Wix.Analytics.PixelEventType[event].requiredParameters are the required parameters
         *
         * @example
         * Wix.Analytics.reportCampaignEvent(Wix.Analytics.PixelEventType.PURCHASE.eventName, {value: 50, currency: 'USD'});
         */
        reportCampaignEvent: reportCampaignEvent
    };
});
