/**
 * @memberof Wix
 * @namespace Wix.Events
 */
define(function () {
    return {
        /**
         * Called when a site owner toggles between preview and edit mode in the Wix Editor.
         * @memberof Wix.Events
         * @since 1.11.0
         * @example
         * {
         *   editMode: 'editor' or 'preview'
         * }
         */
        EDIT_MODE_CHANGE:'EDIT_MODE_CHANGE',

        /**
         * Called when a user navigates (in Editor, preview or Viewer) to the page where the TPA component (Widget/Page) is.
         * @memberof Wix.Events
         * @since 1.11.0
         * @deprecated
         * @example
         * {
         *   toPage: 'mainPage',
         *   fromPage: 'cee5"'
         * }
         */
        PAGE_NAVIGATION_CHANGE:'PAGE_NAVIGATION_CHANGE',

        /**
         * Issued when the site owner publishes the site (in editor).
         * @memberof Wix.Events
         * @since 1.13.0
         */
        SITE_PUBLISHED: 'SITE_PUBLISHED',

        /**
         * Issued when the site owner deletes (in editor) a TPA component (Widget/Page).
         * @memberof Wix.Events
         * @since 1.13.0
         */
        COMPONENT_DELETED: 'COMPONENT_DELETED',

        /**
         * Issued by the Settings endpoint when new settings are applied by the site owner.
         * @memberof Wix.Events
         * @since 1.17.0
         * @example
         * Custom JSON
         */
        SETTINGS_UPDATED: 'SETTINGS_UPDATED',


        /**
         * Signal window placement change
         * @memberof Wix.Events
         * @since 1.18.0
         */
        WINDOW_PLACEMENT_CHANGED: 'WINDOW_PLACEMENT_CHANGED',

        /**
         * @memberof Wix.Events
         * @private
         */
        ON_MESSAGE_RESPONSE: "ON_MESSAGE_RESPONSE",

        /**
         * @memberof Wix.Events
         * @since 1.22.0
         */
        THEME_CHANGE: 'THEME_CHANGE',

        /**
         * @memberof Wix.Events
         * @since 1.22.0
         *
         */
        STYLE_PARAMS_CHANGE: 'STYLE_PARAMS_CHANGE',

        /**
         * @memberof Wix.Events
         * @since 1.25.0
         * @description
         * Issued when scroll happens inside the site (not when it happen inside the app iframe).
         * The event data contains multiple details that helps the app determine it's behaviour considering it's position in the site,
         * the browser window dimensions and a state.
         *
         *  Name          | Type      | Description
         * ---------------|-----------|------------
         * scrollTop      | `Number`  | Site's scroll position on the y axis
         * scrollLeft     | `Number`  | site's scroll position on the x axis
         * documentHeight | `Number`  | Site's document height
         * documentWidth  | `Number`  | Site's document width
         * x              | `Number`  | App offset within the site's page on the x axis (doesn't change)
         * y              | `Number`  | App offset within the site's page on the y axis (doesn't change)
         * height         | `Number`  | App height
         * width          | `Number`  | App width
         * left           | `Number`  | App top-left offset,within the viewport, from the left
         * bottom         | `Number`  | App top-left, offset within the viewport, from the bottom
         * right          | `Number`  | App top-left, offset within the viewport, from the right
         * top            | `Number`  | App top-left, offset within the viewport, from the top
         *
         * @example
         * {
         *      "scrollTop": 4,
         *      "scrollLeft": 0,
         *      "documentHeight": 724,
         *      "documentWidth": 1227,
         *      "x": 124,
         *      "y": 131,
         *      "height": 682,
         *      "width": 978,
         *      "left": 124.5,
         *      "bottom": 809,
         *      "right": 1102.5,
         *      "top": 127
         * }
         */
        SCROLL: 'SCROLL',


        /**
         * Issued on any page navigation within the Wix site.
         * @memberof Wix.Events
         * @since 1.25.0
         * @example
         * {
         *   toPage: 'mainPage',
         *   fromPage: 'cee5"'
         * }
         */
        PAGE_NAVIGATION: 'PAGE_NAVIGATION',

        /**
         * Issued on any page in navigation within the Wix site. This event is a utility event on top of the PAGE_NAVIGATION event.
         * @memberof Wix.Events
         * @since 1.25.0
         * @example
         * {
         *   toPage: 'mainPage',
         *   fromPage: 'cee5"'
         * }
         */
        PAGE_NAVIGATION_IN: 'PAGE_NAVIGATION_IN',

        /**
         * Issued on any page out navigation within the Wix site. This event is a utility event on top of the PAGE_NAVIGATION event.
         * @memberof Wix.Events
         * @since 1.25.0
         * @example
         * {
         *   toPage: 'mainPage',
         *   fromPage: 'cee5"'
         * }
         */
        PAGE_NAVIGATION_OUT: 'PAGE_NAVIGATION_OUT',

        /**
         * Issued when the site state changed.
         * @memberof Wix.Events
         * @since 1.29.0
         * @example
         * {
         *   newState: 'state'
         * }
         */
        STATE_CHANGED: 'STATE_CHANGED',

        /**
         * Issued when the site owner switch between desktop editor and mobile editor.
         * @memberof Wix.Events
         * @since 1.45.0
         * @experimental
         * @example
         * {
         *   deviceType: 'desktop'
         * }
         */
        DEVICE_TYPE_CHANGED: 'DEVICE_TYPE_CHANGED',

        /**
         * Issued when the user hits a keyboard key down, the following keys will be reported: Arrows (Left, Right), Esc, Enter and Spacebar
         * @memberof Wix.Events
         * @since 1.76.0
         */
        KEY_DOWN: 'KEY_DOWN',

        /**
         * Issued when the user hits a keyboard key up, the following keys will be reported: Arrows (Left, Right), Esc, Enter and Spacebar
         * @memberof Wix.Events
         * @since 1.76.0
         */
        KEY_UP: 'KEY_UP',

        /**
         * Issued when the site is saved.
         * @memberof Wix.Events
         * @since 1.62.0
         */
        SITE_SAVED: 'SITE_SAVED',

        /**
         * Issued when the user of user session changed.
         * @memberof Wix.Events
         * @since 1.66.0
         * @example
         * {
         *   userSession: 'fcc41e9cfd86c6431da4aaa750f09b405790ff215fcb96004c6f0ae135f37'
         * }
         */
        SESSION_CHANGED: 'SESSION_CHANGED',

        /**
         * Issued when the public data changed in component scope or app scope
         * If app data changes, all the registered components will get the event
         *
         * @memberof Wix.Events
         * @since 1.74.0
         * @example
         * {
         *   key1: value1
         * }
         */
        PUBLIC_DATA_CHANGED: 'PUBLIC_DATA_CHANGED',

        /**
         * Issued when the page metadata (title, description) changes.
         * @memberof Wix.Events
         * @since 1.75.0
         * @example
         * {
         *   title: 'example title',
         *   description: 'example description'
         * }
         */
        SITE_METADATA_CHANGED: 'SITE_METADATA_CHANGED',

        QUICK_ACTION_TRIGGERED: 'QUICK_ACTION_TRIGGERED'
    };
});
