/**
 * @memberof Wix
 * @namespace Wix.Dashboard
 */
define(['Base', 'Settings', 'privates/reporter', 'privates/postMessage', 'privates/sharedAPI', 'privates/utils'], function (Base, Settings, reporter, postMessage, sharedAPI, utils) {

    var namespace = 'Dashboard';

    var setHeight = function (height) {
        Base.setHeight(height);
    };

    var resizeWindow = function (width, height, onComplete) {
        Base.resizeWindow(width, height, onComplete);
    };

    var openMediaDialog = function (mediaType, multipleSelection, onSuccess, onCancel) {
        Settings.openMediaDialog(mediaType, multipleSelection, onSuccess, onCancel);
    };

    var openBillingPage = function (options) {
        Settings.openBillingPage(options);
    };

    var appEngaged = function(premiumIntent) {
        Settings.appEngaged(premiumIntent);
    };

    var openModal = function (url, width, height, onClose) {
        Base.openModal(url, width, height, onClose);
    };

    var closeWindow =function (message) {
        Base.closeWindow(message);
    };

    var scrollTo = function (x, y) {
        Base.scrollTo(x, y);
    };

    var getEditorUrl = function (callback) {
        if (!callback) {
            reporter.reportSdkError('Mandatory arguments - a callback must be specified');
            return;
        }
        postMessage.sendMessage(postMessage.MessageTypes.GET_EDITOR_URL, namespace, undefined, callback);
    };

    var pushState =  function (state) {
        if (typeof state !== "string") {
            reporter.reportSdkError('Missing mandatory argument - state');
            return;
        }

        postMessage.sendMessage(postMessage.MessageTypes.APP_STATE_CHANGED, namespace, {
            state: state
        });
    };

    var revalidateSession = function(onSuccess, onError) {
        Base.revalidateSession(onSuccess, onError);
    };

    var getProducts = function (onSuccess, onError) {
        sharedAPI.getProducts(namespace, {}, onSuccess, onError);
    };

    var getSiteViewUrl = function(options, onSuccess) {

        if (utils.isObject(options)) {
            if (onSuccess && utils.isFunction(onSuccess)) {
                postMessage.sendMessage(postMessage.MessageTypes.GET_SITE_VIEW_URL, namespace, options, onSuccess);
            } else {
                reporter.reportSdkError('Missing mandatory argument - onSuccess');
            }
        } else if (!utils.isFunction(options)) {
            reporter.reportSdkError('Missing mandatory argument - onSuccess');
        } else {
            postMessage.sendMessage(postMessage.MessageTypes.GET_SITE_VIEW_URL, namespace, undefined, options);
        }

    };

    return {

        /**
         * @enum
         * @memberof Wix.Dashboard
         * @since 1.78.0
         */
        PremiumIntent: Settings.PremiumIntent,

        /**
         * This method requests the hosting Wix platform to change the iframe height inside the side dashboard (under the My Account tab in Wix.com). Works on the app or modal iframes.
         * @function
         * @author lior.shefer@wix.com
         * @deprecated
         * @memberof Wix.Dashboard
         * @since 1.24.0
         * @see Wix.setHeight
         * @example
         *
         * Wix.Dashboard.setHeight(height);
         *
         */
        setHeight:setHeight,

        /**
         * This method opens Wix media dialog inside WIx Dashboard, and let's the site owner choose a an existing file from the Wix media galleries,
         * or upload a new file instead. When completed a callback function returns the meta data of the selected item/s.
         * This method returns a meta data descriptor for a selected media item.
         * To access the media item from your code you will need to construct a full URL using that descriptor.
         * Since the media items URLs format is set by Wix and might changed in the future, we are requiring that the URL construction will be done using the SDK.
         * Use one of the Wix.Utils.Media.get* methods to get the desired media item URL.
         * The following media type are currently supported - Wix.Settings.MediaType
         * @function
         * @author lior.shefer@wix.com
         * @memberof Wix.Dashboard
         * @since 1.40.0
         * @see Wix.Settings.openMediaDialog
         *
         * @example
         *
         * Wix.Dashboard.openMediaDialog(Wix.Settings.MediaType.IMAGE, false, function(data) {
         *    // save image data
         * });
         */
        openMediaDialog: openMediaDialog,

        /**
         * The Dashboard.openBillingPage method allows the app to offer a premium package from within the app.
         * When called will open the Wix billing system page in a new browser window.
         * @function
         * @author lior.shefer@wix.com
         * @memberof Wix.Dashboard
         * @since 1.79.0
         * @see Wix.Settings.openBillingPage
         * @example
         *
         * Wix.Dashboard.openBillingPage({premiumIntent: Wix.Settings.PremiumIntent.FREE});
         */
        openBillingPage: openBillingPage,

        /**
         * The openModal method allows an app to open a modal window within the dashboard. A modal is a runtime Widget that is not part of the dashboard structure.
         * The modal window is a singleton (every new modal closes the previous one) and contains a lightbox.
         * A modal can be dismissed by the user if it touches the lightbox, presses the closing button or by the app itself
         * if it calls the Wix.Dashboard.closeWindow() from within the modal iframe. The onClose argument can be used to detect modal close.
         * @function
         * @memberof Wix.Dashboard
         * @since 1.27.0
         * @see Wix.openModal
         * @example
         *
         * var onClose = function(message) { console.log("modal closed", message); }
         * Wix.Dashboard.openModal("http://sslstatic.wix.com/services/js-sdk/1.16.0/html/modal.html", 400, 400, onClose);
         *
         */
        openModal:openModal,

        /**
         * The closeWindow method is available only under a modal endpoint (will not have any effect for other endpoints). It allows the modal to close itself programmatically.
         * @function
         * @memberof Wix.Dashboard
         * @since 1.27.0
         * @see Wix.closeWindow
         * @example
         *
         * // The following call will close the modal/popup window and send a the object message to the opener onClose callback
         * var message = {"reason": "button-clicked"};
         * Wix.Dashboard.closeWindow(message);
         *
         */
        closeWindow:closeWindow,

        /**
         * The Dashboard.scrollTo method allows the app to scroll to an absolute offset - vertical & horizontal.
         * @function
         * @author lior.shefer@wix.com
         * @memberof Wix.Dashboard
         * @since 1.31.0
         * @see Wix.scrollTo
         * @example
         *
         * Wix.Dashboard.scrollTo(0, 0);
         *
         */
        scrollTo:scrollTo,

        /**
         * Returns a url for the app in the Editor. Once directed to the Editor, the app will be shown to your user. If your app has components on more than one page, the first page that contains your app will be opened.
         * @function
         * @memberof Wix.Dashboard
         * @since 1.33.0
         * @param {Function} callback A callback which gets editor url as parameter.
         * @example
         *
         * Wix.Dashboard.getEditorUrl(function(url) {
         *    //editor url as a callback parameter
         * });
         *
         */
        getEditorUrl:getEditorUrl,

        /**
         * This method enable AJAX style Page apps to inform the Wix platform about a change in the app internal state. The new state will be reflected in the site/page URL.
         * Once you call the pushState method, the browser top window URL will change the 'app-state' path part to the new state you provide with the pushState
         * method (similar to the browser history API - https://developer.mozilla.org/en-US/docs/Web/Guide/API/DOM/Manipulating_the_browser_history).
         * For a full explanation of how deep-linking works with AJAX style apps, see Deep Linking for AJAX Style Apps - http://dev.wix.com/docs/display/DRAF/Developing+a+Page+App.
         * @function
         * @memberof Wix.Dashboard
         * @since 1.35.0
         * @see Wix.pushState
         * @example
         *
         * Wix.Dashboard.pushState("app-state");
         *
         */
        pushState:pushState,

        /**
         * Applicable only for modal component. Re-sizes the modal window.
         * @function
         * @memberof Wix.Dashboard
         * @author tomergab@wix.com
         * @since 1.40.0
         * @see Wix.resizeWindow
         * @param {Number} width Window width in pixels.
         * @param {Number} height Window height in pixels.
         * @param [Function] onComplete On resize complete callback function.
         * @example
         *
         * // The following call will resize the widget window
         * Wix.Dashboard.resizeWindow(300, 300);
         *
         */
        resizeWindow:resizeWindow,

        /**
         * Before showing sensitive information or making an action which requires a secure session,
         * an app should verify that a secure session exists.
         * Get a newly signed app instance by calling Wix.Dashboard.revalidateSession.
         *
         * @function
         * @memberof Wix.Dashboard
         * @since 1.52.0
         * @param {Function} onSuccess Receives a newly signed and encoded app instance.
         * @param {Function} onFailure
         * @example
         *
         *
         * Wix.Dashboard.revalidateSession(function(instanceData){
         *  //handle success use-case
         * }, function(error){
         *    //Handle error use-case
         * });
         */
        revalidateSession: revalidateSession,

        /**
         *  Returns an Array of objects containing product and pricing info.
         *
         * @function
         * @memberof Wix.Dashboard
         * @since 1.71.0
         * @param {Function} onSuccess A callback function to receive the products.
         * @param {Function} onError A callback error function.
         *
         * @example
         * var onError = function () {
         *  //handle the error
         * };
         * var onSuccess = function (data) {
         *  //handle onSuccess
         *  //sample data schema:
         *  [{
         *     "id": <vendorProductId>,
         *     "name": "App Premium Package",
         *     "price": "4.95",
         *     "is_active": true,
         *     "freeMonth": true,
         *     "currencyCode": "USD",
         *     "currencySymbol": "US$"
         *     "monthly": {
         *          "price": "4.95",
         *          "url": "https://premium.wix.com/wix/api/tpaPriceQuote?appInstanceId=aaa-bbb&appDefinitionId=aa-bb&paymentCycle=MONTHLY&vendorProductId=1234"
         *     },
         *     "yearly:: {
         *          "price": "3.97",
         *          "url": "https://premium.wix.com/wix/api/tpaPriceQuote?appInstanceId=aaa-bbb&appDefinitionId=aa-bb&paymentCycle=YEARLY&vendorProductId=1234"
         *     },
         *     "oneTime": {
         *          "price": "5.99",
         *          "url": "https://premium.wix.com/wix/api/tpaPriceQuote?appInstanceId=aaa-bbb&appDefinitionId=aa-bb&paymentCycle=ONE_TIME&vendorProductId=1234"
         *     },
         *     "bestSellingFeature": "",
         *      "discountPercent": 20
         *     ]
         *  }]
         *
         * };
         * Wix.Dashboard.getProducts(onSuccess, onError);
         */
        getProducts: getProducts,

        /**
         *  Returns URL object that contains the site's base URL under 'base'.
         *
         * @function
         * @memberof Wix.Dashboard
         * @since 1.74.0
         * @param {Object} [options[ An object contains optional parameters
         * @param {Function} onSuccess A callback function to receive the base url object.
         *
         * @example
         *
         * var onSuccess = function (data) {
         *   // do something with base url
         * };
         * Wix.Dashboard.getSiteViewUrl(onSuccess);
         */
        getSiteViewUrl: getSiteViewUrl,

        /**
         * The Wix.Dashboard.appEngaged method allows to indicate if an app is "engaged" or "highly engaged" to give a better indication to BA funnel / package picker
         * @function
         * @memberof Wix.Dashboard
         * @since 1.79.0
         * @see Wix.Settings.appEngaged
         * @example
         *
         * Wix.Dashboard.appEngaged(Wix.Dashboard.PremiumIntent.FREE);
         */
        appEngaged: appEngaged
    };
});
