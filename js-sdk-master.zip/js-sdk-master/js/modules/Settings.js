/**
 * This is the description for the Settings namespace.
 * @memberof Wix
 * @namespace Wix.Settings
 */
define(['WindowPlacement', 'privates/utils', 'privates/reporter', 'privates/postMessage', 'privates/sharedAPI'],
    function (WindowPlacement, utils, reporter, postMessage, sharedAPI) {

    var namespace = 'Settings';

    var getStyleParams = function (callback) {
        reporter.reportSdkMsg('Wix.Settings.getStyleParams is DEPRECATED use Wix.Styles.getStyleParams');
        postMessage.sendMessage(postMessage.MessageTypes.GET_STYLE_PARAMS, namespace);
        return sharedAPI.getStyleParams(callback);
    };

    /** Function getStyleColorByKey
     *
     * Returns the css color value of saved style parameter
     *
     * @deprecated
     * @since SDK 1.22.0
     * @param colorKey (String) a unique key describing a color style parameter
     * @return (String) css color string. E.g "#FFFFFF" or "rgba(0,0,0,0.5)"
     */
    var getStyleColorByKey = function (colorKey) {
        reporter.reportSdkMsg('Wix.Settings.getStyleColorByKey is DEPRECATED use Wix.Styles.getStyleColorByKey');
        postMessage.sendMessage(postMessage.MessageTypes.GET_STYLE_COLOR_BY_KEY, namespace);
        return sharedAPI.getStyleColorByKey(colorKey);
    };

    /**
     * Function getColorByreference
     * Returns the color object of editor style
     *
     * @deprecated
     * @since 1.22.0
     * @param colorReference (String) a unique key describing a theme color parameter
     * @return (Object) a map describing a Wix style color.
     */
    var getColorByreference = function (colorReference) {
        reporter.reportSdkMsg('Wix.Settings.getColorByreference is DEPRECATED use Wix.Styles.getColorByreference');
        postMessage.sendMessage(postMessage.MessageTypes.GET_COLOR_BY_REFERENCE, namespace);
        return sharedAPI.getColorByreference(colorReference);
    };

    /**
     * Function setColorParam
     * Sets a style color parameter
     *
     * @deprecated
     * @since 1.22.0
     * @param key (String) a unique key describing a color style parameter
     * @param value (Object)
     */
    var setColorParam = function (key, value) {
        reporter.reportSdkMsg('Wix.Settings.setColorParam is DEPRECATED use Wix.Styles.setColorParam');
        postMessage.sendMessage(postMessage.MessageTypes.SET_COLOR_PARAM, namespace);
        return sharedAPI.setColorParam(key, value);
    };

    /**
     * Function setNumberParam
     * Sets a style number parameter
     *
     * @deprecated
     * @since 1.22.0
     * @param key (String) a unique key describing a number style parameter
     * @param value (Number)
     */
    var setNumberParam = function (key, value) {
        reporter.reportSdkMsg('Wix.Settings.setNumberParam is DEPRECATED use Wix.Styles.setNumberParam');
        postMessage.sendMessage(postMessage.MessageTypes.SET_NUMBER_PARAM, namespace);
        return sharedAPI.setEditorParam(namespace, 'color', key, value);
    };

    /** Function setBooleanParam
     *
     * Sets a style boolean parameter
     *
     * @deprecated
     * @since 1.22.0
     * @param key (String) a unique key describing a boolean style parameter
     * @param value (Boolean)
     */
    var setBooleanParam = function (key, value) {
        reporter.reportSdkMsg('Wix.Settings.setBooleanParam is DEPRECATED use Wix.Styles.setBooleanParam');
        postMessage.sendMessage(postMessage.MessageTypes.SET_BOOLEAN_PARAM, namespace);
        return sharedAPI.setEditorParam(namespace, 'boolean', key, value);
    };

    /** Function getSiteColors
     *
     * Returns the currently active site colors
     *
     * @deprecated
     * @since 1.12.0
     * @param callback (Function) callback function: function(colors)
     */
    var getSiteColors = function (callback) {
        reporter.reportSdkMsg('Wix.Settings.getSiteColors is DEPRECATED use Wix.Styles.getSiteColors');
        postMessage.sendMessage(postMessage.MessageTypes.GET_SITE_COLORS, namespace);
        return sharedAPI.getStyle(callback, 'siteColors');
    };

    var getWindowPlacement = function (compId, callback) {
        if (!compId || !callback) {
            reporter.reportSdkError('Mandatory arguments - compId & callback must be specified');
        }

        postMessage.sendMessage(postMessage.MessageTypes.GET_WINDOW_PLACEMENT, namespace, {
            compId: compId
        }, callback);
    };

    var getSiteInfo = function (onSuccess) {
        sharedAPI.getSiteInfo(namespace, onSuccess);
    };

    var refreshApp = function (queryParams) {
        postMessage.sendMessage(postMessage.MessageTypes.REFRESH_APP, namespace, {queryParams});
    };

    var refreshAppByCompIds = function (compIds, queryParams) {
        postMessage.sendMessage(postMessage.MessageTypes.REFRESH_APP, namespace, {queryParams, compIds});
    };

    var openBillingPage = function (options) {
        var args = sharedAPI.validateParamsForOpenBillingPage(this.PremiumIntent, options);
        if (args){
            postMessage.sendMessage(postMessage.MessageTypes.OPEN_BILLING_PAGE, namespace, args);
        }
    };

    var appEngaged = function(premiumIntent){
        if (!utils.isString(premiumIntent) || !utils.has(this.PremiumIntent, premiumIntent)) {
            reporter.reportSdkError('Missing mandatory argument - premiumIntent - should be one of Wix.Settings.PremiumIntent');
            return;
        }

        var args = {
            premiumIntent: premiumIntent
        };

        postMessage.sendMessage(postMessage.MessageTypes.APP_ENGAGED, namespace, args);
    };

    var openMediaDialog = function (mediaType, multipleSelection, onSuccess, onCancel) {
        sharedAPI.openMediaDialog(postMessage.MessageTypes.OPEN_MEDIA_DIALOG, namespace, this.MediaType, mediaType, multipleSelection, onSuccess, onCancel);
    };

    var openSiteMembersSettingsDialog = function(){
        postMessage.sendMessage(postMessage.MessageTypes.OPEN_SITE_MEMBERS_SETTINGS_DIALOG, namespace);
    };

    var triggerSettingsUpdatedEvent = function (message, compId) {
        message = message || {};
        compId = compId || '*';

        postMessage.sendMessage(postMessage.MessageTypes.POST_MESSAGE, namespace, {
            message: message,
            compId: compId
        });
    };

    var getSitePages = function (options, callback) {
        sharedAPI.getSitePages(namespace, options, callback);
    };

    var getSiteMap = function (callback) {
        sharedAPI.getSiteMap(namespace, callback);
    };

    var setWindowPlacement = function (compId, placement, verticalMargin, horizontalMargin) {
        if (!compId || !placement) {
            reporter.reportSdkError('Mandatory arguments - compId & placement must be specified');
        }

        if (!WindowPlacement.hasOwnProperty(placement)) {
            reporter.reportSdkError('Invalid argument - placement value should be set using Wix.WindowPlacement');
        }
        postMessage.sendMessage(postMessage.MessageTypes.SET_WINDOW_PLACEMENT, namespace, {
            compId: compId,
            placement: placement,
            verticalMargin: verticalMargin,
            horizontalMargin: horizontalMargin
        });
    };

    var getDashboardAppUrl = function (callback) {
        if (!callback) {
            reporter.reportSdkError('Mandatory arguments - a callback must be specified');
        }

        postMessage.sendMessage(postMessage.MessageTypes.GET_DASHBOARD_APP_URL, namespace, undefined, callback);
    };

    var openModal = function (url, width, height, title, onClose, bareUI) {
        sharedAPI.openModal(namespace, url, width, height, title, onClose, bareUI);
    };

    var closeWindow = function (message) {
        sharedAPI.closeWindow(namespace, message);
    };

    var addComponent = function (options, onSuccess, onError) {
        if (!options || !options.componentType) {
            reporter.reportSdkError('Mandatory arguments - options has to have componentType');
            return;
        }

        var callback = function (data) {
            if (data.onError) {
                if (onError) {
                    onError.apply(this, arguments);
                }
            } else {
                if (onSuccess) {
                    onSuccess.apply(this, arguments);
                }
            }
        };

        if (options.copyStyle && !utils.isBoolean(options.copyStyle)) {
            reporter.reportSdkError('Invalid argument - copyStyle should be of type Boolean');
            return;
        }

        var args = {
            componentType: options.componentType
        };

        if (options.copyStyle) {
            args.copyStyle = options.copyStyle;
        }

        if (options.styleId) {
            args.styleId = options.styleId;
        }

        if (options.componentType === 'WIDGET') {

            if (!options.widget) {
                reporter.reportSdkError('Mandatory arguments - options has to have widget object');
                return;
            }


            args.widget = {
                tpaWidgetId: options.widget.widgetId,
                allPages: options.widget.allPages || false,
                wixPageId: options.widget.wixPageId
            };
        }

        if (options.componentType === 'PAGE') {
            if (!options.page) {
                reporter.reportSdkError('Mandatory arguments - options has to have page object');
                return;
            }

            args.page = {
                pageId: options.page.pageId,
                title: options.page.title
            };
        }

        postMessage.sendMessage(postMessage.MessageTypes.ADD_COMPONENT, namespace, args, callback);
    };

    var setExternalId = function (guid, onSuccess, onError) {
        if (!guid) {
            reporter.reportSdkError('Mandatory arguments - GUID must be provided');
            return;
        }

        var callback = function (data) {
            if (data.onError) {
                if (onError) {
                    onError.apply(this, arguments);
                }
            } else {
                if (onSuccess) {
                    onSuccess.apply(this, arguments);
                }
            }
        };

        var args = {
            externalId: guid
        };

        postMessage.sendMessage(postMessage.MessageTypes.SET_EXTERNAL_ID, namespace, args, callback);
    };

    var revalidateSession = function(onSuccess, onError) {
        sharedAPI.revalidateSession(namespace, onSuccess, onError);
    };

    var setFullWidth = function (shouldBeFullWidth, options, onSuccess, onError) {
        if (!utils.isBoolean(shouldBeFullWidth)){
            reporter.reportSdkError('Mandatory argument - shouldBeFullWidth - should be of type Boolean');
            return;
        }

        var callback = function (data) {
            if (data && data.onError) {
                if (onError) {
                    onError.apply(this, arguments);
                }
            } else {
                if (onSuccess) {
                    onSuccess.apply(this, arguments);
                }
            }
        };

        var margins;
        if (options && options.margins) {
            margins = options && options.margins;
            _.forIn(margins, function(value, key) {
                if (_.endsWith(margins[key], '%')) {
                    margins[key] = _.replace(margins[key], '%', 'vw');
                }
            });
        }

        var args = {
            stretch: shouldBeFullWidth,
            margins: margins
        };

        postMessage.sendMessage(postMessage.MessageTypes.SET_FULL_WIDTH, namespace, args, callback);
    };

    var isFullWidth = function (callback) {
        if (!callback) {
            reporter.reportSdkError('Mandatory arguments - a callback must be specified');
        }

        postMessage.sendMessage(postMessage.MessageTypes.IS_FULL_WIDTH, namespace, undefined, callback);
    };

    var openReviewInfo = function() {
        postMessage.sendMessage(postMessage.MessageTypes.OPEN_REVIEW_INFO, namespace);
    };

    var resizeComponent = function(options, onSuccess, onFailure) {
        sharedAPI.resizeComponent(options, namespace, onSuccess, onFailure);
    };

    var getCurrentPageAnchors = function(callback){
        sharedAPI.getCurrentPageAnchors(namespace, callback);
    };

    var getStateUrl = function(sectionId, state, callback) {
        sharedAPI.getStateUrl(namespace, sectionId, state, callback);
    };

    var isComponentInstalled = function (componentId, callback) {
        if (!componentId || !utils.isString(componentId)) {
            reporter.reportSdkError('Missing mandatory argument - componentId - should be a non empty String');
            return;
        }
        if (!utils.isFunction(callback)) {
            reporter.reportSdkError('Missing mandatory argument - callback - should be of type Function');
            return;
        }
        postMessage.sendMessage(postMessage.MessageTypes.IS_COMPONENT_INSTALLED, namespace, {componentId}, callback);
    };

    var openLinkPanelImpl = function (options, onSuccess, onCacnel) {
        if (!utils.isFunction(onSuccess)) {
            reporter.reportSdkError('Missing mandatory argument - onSuccess - should be of type Function');
            return;
        }
        if (onCacnel && !utils.isFunction(onCacnel)) {
            reporter.reportSdkError('Invalid argument - onCacnel - should be of type Function');
            return;
        }

        var callback = function (data) {
            if (data && data.onCacnel) {
                if (onCacnel) {
                    onCacnel.apply(this, arguments);
                }
            } else {
                if (onSuccess) {
                    onSuccess.apply(this, arguments);
                }
            }
        };

        var args = {};
        if (options.link) {
            args.link = options.link;
        }

        postMessage.sendMessage(postMessage.MessageTypes.OPEN_LINK_PANEL, namespace, args, callback);
    };

    var openLinkPanel = function (options, onSuccess, onCacnel) {
        if (options && utils.isObject(options)) {
            openLinkPanelImpl(options, onSuccess, onCacnel);
        } else if (utils.isFunction(options)){
            openLinkPanelImpl({}, options, onSuccess);
        } else {
            reporter.reportSdkError('Missing mandatory argument - first argument should be of type Object or Function');
        }
    };

    var isApplicationInstalled = function(appDefinitionId, callback) {
        sharedAPI.isApplicationInstalled(namespace, appDefinitionId, callback);
    };

    return {
        /**
         * @enum
         * @memberof Wix.Settings
         * @since 1.40.0
         */
        MediaType: {
            IMAGE: 'photos',
            BACKGROUND: 'backgrounds',
            AUDIO: 'audio',
            DOCUMENT: 'documents',
            SWF: 'swf',
            SECURE_MUSIC: 'secure_music'
        },

        /**
         * @enum
         * @memberof Wix.Settings
         * @since 1.78.0
         */
        PremiumIntent: {
            NEUTRAL: 'NEUTRAL',
            FREE: 'FREE',
            PAID: 'PAID'
        },

        getColorByreference: getColorByreference,
        setBooleanParam: setBooleanParam,
        setColorParam: setColorParam,
        setNumberParam: setNumberParam,
        getSiteColors: getSiteColors,
        getStyleColorByKey: getStyleColorByKey,

        /**
         * Get window placement for a Glued Widget. Error will be thrown for non-Glued widgets.
         *
         * @function
         * @memberof Wix.Settings
         * @since 1.19.0
         * @param compId (String) component ID of the Glued Widget
         * @param callback (Function) a callback function that gets the component placement as an argument
         *   callback signature: function(data) {}
         * @example
         *
         * var compId = Wix.Utils.getOrigCompId();
         * Wix.Settings.getWindowPlacement(compId, function (data) {
         *  // do something with widget placement
         * });
         */
        getWindowPlacement: getWindowPlacement,

        /**
         * This method returns the URL leading to your BackOffice (AKA Business) application, in the Wix Dashboard.
         * The URL is fully qualified and starts with "//" for using HTTPS if supported. If the site is not saved, save dialog will be prompted.
         * @function
         * @memberof Wix.Settings
         * @author tomergab@wix.com
         * @since 1.32.0
         * @param {Function} callback A callback function to receive the URL of the app in the dashboard (AKA BackOffice/Business).
         * @example
         *
         * Wix.Settings.getDashboardAppUrl(function(url) {
         *    // do something with the URL
         * });
         */
        getDashboardAppUrl: getDashboardAppUrl,

        /**
         * The getsiteInfo method is used to retrieve information about the host site in which the app is shown.
         * @function
         * @memberof Wix.Settings
         * @since 1.12.0
         * @see Wix.getSiteInfo
         *
         * @example
         *
         * Wix.Settings.getSiteInfo(function(siteInfo) {
         *    // do something with the siteInfo
         * });
         *
         */
        getSiteInfo: getSiteInfo,

        /**
         * The getSitePages method is used to retrieve the site structure from the hosting Wix Platform. The site structure includes visible and hidden pages as well as sub pages.
         * @function
         * @memberof Wix.Settings
         * @since 1.68.0
         * @see Wix.getSitePages
         *
         * @example
         *
         * Wix.Settings.getSitePages(function(sitePages) {
         *    // do something with the site pages
         * });
         */
        getSitePages: getSitePages,


        /**
         * The getSiteMap method is used to retrieve the site structure from the hosting Wix Platform. The site structure includes visible and hidden pages, sub pages, links and menu headers.
         * This method will eventually replace the getSitepages.
         *
         * @function
         * @memberof Wix.Settings
         * @since 1.81.0
         * @see Wix.getSiteMap
         *
         * @example
         *
         * Wix.Settings.getSiteMap(function(siteMap) {
         *    // do something with the site pages
         * });
         */
        getSiteMap: getSiteMap,

        /**
         * The getStyleParams method is used to retrieve the style parameters from the hosting Wix Platform. The parameters includes colors numbers, booleans.
         * @function
         * @memberof Wix.Settings
         * @deprecated Use Wix.Styles.getStyleParams
         * @since 1.22.0
         * @param {Function} callback A callback function to receive the style parameters.
         * @example
         *
         * Wix.Settings.getStyleParams(function(styleParams) {
         *    // do something with the style params
         * });
         */
        getStyleParams: getStyleParams,

        /**
         * The Setting.openBillingPage method allows the app to offer a premium package from within the app settings.
         * When called it will open the Wix billing system page in a modal window.
         * @function
         * @memberof Wix.Settings
         * @since 1.79.0
         * @param {Object} options may contain: a 'premiumIntent' property with possible values: Wix.Settings.PremiumIntent to be sent to the billing page window
         * @example
         *
         * Wix.Settings.openBillingPage({premiumIntent: Wix.Settings.PremiumIntent.FREE});
         */
        openBillingPage: openBillingPage,

        /**
         * The Wix.Setting.appEngaged method allows to indicate if an app is "engaged" or "highly engaged" to give a better indication to BA funnel / package picker
         * @function
         * @memberof Wix.Settings
         * @since 1.79.0
         * @param {Wix.Settings.PremiumIntent} premiumIntent the app's premium intent
         * @example
         *
         * Wix.Settings.appEngaged(Wix.Settings.PremiumIntent.FREE);
         */
        appEngaged: appEngaged,

        /**
         * This method opens the Wix media dialog inside the WIx Editor, and let's the site owner choose a an existing file from the Wix media galleries,
         * or upload a new file instead. When completed a callback function returns the meta data of the selected item/s.
         * This method returns a meta data descriptor for a selected media item. To access the media item from your code you will need to construct a
         * full URL using that descriptor. Since the media items URLs format is set by Wix and might changed in the future,
         * we are requiring that the URL construction will be done using the SDK. Use one of the Wix.Utils.Media.get* methods to get the desired media item URL.
         * @function
         * @memberof Wix.Settings
         * @author lior.shefer@wix.com
         * @since 1.40.0
         * @param {Wix.Settings.MediaType} mediaType Media gallery to choose from - image, background, audio, swf and secure music.
         * @param {Boolean} multiSelect selection mode, single (false) or multiple (true) item to choose from.
         * @param {Function} onSuccess callback function, passing the media item/s meta data.
         * @param {Function} [onCancel] callback function called when user cancels.
         * @return This is an asynchronous function, the returned value is passed in the onSuccess callback function.
         * An object (single selection) or Array of objects (multiple selection). The object describes the meta data of the selected media item.
         *
         * @example
         *
         * Wix.Settings.openMediaDialog(Wix.Settings.MediaType.IMAGE, false, function(data) {
         *    // save image data
         * });
         */
        openMediaDialog: openMediaDialog,

        /**
         * This method opens the site members settings dialog in which the user can configure who can be a site member, which site members dialog to show first etc.
         * The function will first close all other open dialogs or panels in the editor.
         * @function
         * @memberof Wix.Settings
         * @since 1.74.0
         * @example
         *
         * Wix.Settings.openSiteMembersSettingsDialog();
         */
        openSiteMembersSettingsDialog: openSiteMembersSettingsDialog,

        /**
         * Notifying the host site that the app requires reloading.
         * The refreshApp method is normally used when a user changes the app settings in the settings iframe, and as a result requires that the Widget or Page iframes should be reloaded such that the new settings will take affect.
         * The refreshApp method accepts a single optional argument, an object. Where each of the object's properties will translate into a query parameter in the iframe URL.
         * @function
         * @memberof Wix.Settings
         * @since 1.12.0
         * @param {Object} [queryParams] A map of custom query parameters that should be added to the iframe URL.
         * @example
         *
         * //The App's components (all of them) will be refreshed without custom query parameters
         * Wix.Settings.refreshApp();
         *
         * //The App's components (all of them) will be refreshed with custom query parameters as specified in the object argument - [BASE-URL]?[WIX-QUERY-PARAMETERS]&param1=value1&param2=value2
         * Wix.Settings.refreshApp({param1: "value1", param2: "value2"})
         */
        refreshApp: refreshApp,

        /**
         * Notifying the host site that some specific components of the app requires reloading. It does the same as Settings.refreshApp but for specific components.
         * @function
         * @memberof Wix.Settings
         * @since 1.12.0
         * @param {Array} compIds An array of the app component ids that should be refreshed.
         * @param {Object} [queryParams] A map of custom query parameters that should be added to the iframe URL.
         * @example
         *
         * //For example, if the user adds 3 components of the same app with ids: "id1", "id2" and "id3", and then he changes something in
         * the settings iframe that affects only 2 components display, to refresh these 2 components:
         * //The App's components with ids "id1" and "id3" will be refreshed without custom query parameters
         * Wix.Settings.refreshAppByCompIds(["id1", "id3"]);
         * //The App's components with ids "id1" and "id3" will be refreshed with custom query parameters as specified in the object argument - [BASE-URL]?[WIX-QUERY-PARAMETERS]&param1=value1&param2=value2
         * Wix.Settings.refreshAppByCompIds(["id1", "id3"], {param1: "value1", param2: "value2"});
         */
        refreshAppByCompIds: refreshAppByCompIds,

        /**
         * The setWindowPlacement method sets the placement for fixed position widgets in an editing session.
         * @function
         * @memberof Wix.Settings
         * @since 1.19.0
         * @param {String} compId Component id to change window placement to.
         * @param {WindowPlacement} placement New placement for the widget window
         * @param {Number} [verticalMargin] Vertical offset from the window placement. Valid values are between -2 and 2.
         * @param {Number} [horizontalMargin] Horizontal offset from the window placement. Valid values are between -2 and 2.
         * @example
         *
         * var compId = Wix.Utils.getOrigCompId();
         * Wix.Settings.setWindowPlacement(compId, Wix.WindowPlacement.CENTER, 2, 0);
         */
        setWindowPlacement: setWindowPlacement,

        /**
         * The triggerSettingsUpdatedEvent method is used from the Settings iframe to trigger a Wix.Events.SETTINGS_UPDATED event in a Widget/Page iframe.
         * It should be used in an editing session when a developer wants to reflect editing changes but avoid refresh/reload on the Widget/Page iframe.
         * @function
         * @memberof Wix.Settings
         * @since 1.17.0
         * @param {Object} message A custom JSON which will be passed to the Widget/Page as the event data.
         * @param {String} [compId] A component id the developer wants to trigger the event on. The most obvious compId is Utils.getOrigCompId(). If no compId is given all components that registered to
         *  Wix.Events.SETTINGS_UPDATED will receive the event.
         * @example
         *
         * Wix.Settings.triggerSettingsUpdatedEvent(message, compId);
         */
        triggerSettingsUpdatedEvent: triggerSettingsUpdatedEvent,

        /**
         * The openModal method allows the Settings iframe to open a modal window.
         *
         * The modal window is a singleton (every new modal closes the previous one) and contains a lightbox.
         *
         * A modal can be dismissed by the user if it touches the lightbox, presses the closing button or by the app itself
         * if it calls the Wix.closeWindow from within the modal iframe.
         *
         * @function
         * @memberof Wix.Settings
         * @author lior.shefer@wix.com
         * @since 1.43.0
         * @param {String} url Model iframe url.
         * @param {Number} width The modal window width (can be a string for percent, i.e., '90%', or an integer for pixels, i.e., 90).
         * @param {Number} height The modal window height (can be a string for percent, i.e., '90%', or an integer for pixels, i.e., 90).
         * @param {String} [title] Title of the modal.
         * @param {Function} [onClose] onClose callback function.
         * @example
         *
         * var onClose = function(message) { console.log("modal closed", message); }
         * //Open a modal when width and height are in pixels.
         * Wix.Settings.openModal("http://sslstatic.wix.com/services/js-sdk/1.41.0/html/modal.html", 400, 400, "My modal's title", onClose);
         *
         * //Open a modal when width and height in percentages.
         * Wix.Settings.openModal("http://sslstatic.wix.com/services/js-sdk/1.41.0/html/modal.html", '70%', '90%', "My modal's title", onClose);
         */
        openModal: openModal,

        /**
         * The closeWindow method is available only under a modal/settings endpoint. It allows to close the modal or settings.
         * @function
         * @memberof Wix.Settings
         * @param {Object} options object to pass the opener's onClose callback function.
         *                 options can contains  target, that can be SETTINGS/MODAL/ALL, the default target is MODAL. when passing SETTINGS,
         *                 only the settings panel would be closed, MODAL will close the modal/popup window and ALL will close both.
         * @since 1.83.0
         * @example
         *
         * var options = {"reason": "button-clicked", target: "MODAL"};
         * Wix.Settings.closeWindow(options);
         *
         */
        closeWindow: closeWindow,
        /**
         * Add a new component to the site. Component will be added with it's default style unless the 'copyStyle' property is true and then the style would be copied from the current component.
         * if the styleId property is also passed, the style will be according to it.
         * Once the component is added, the user would be directed to the page where the component was added.
         * @function
         * @memberof Wix.Settings
         * @author lior.shefer@wix.com
         * @since 1.66.0
         * @experimental
         * @param {Object} options Options for this function: componentType (required), copyStyle (boolean), styleId (string), widget (object), page (object)
         * @param {Function} onSuccess  Receives the component compId
         * @param {Function} onError  Receives the error if the operation failed
         * @example
         *
         * // create a new page from a pageId. User is prompted for page name, compId is returned in callback
         * Wix.Settings.addComponent({
	     *      componentType : 'PAGE',
	     *      page : {
		 *          pageId : 'product-catalog',
	     *      }
         * }, function(compId) {
	     *      console.log(compId);
         * });
         */
        addComponent: addComponent,

        /**
         * Sets the width or height of the given component. Works for both pages and widgets.
         * @function
         * @author lior.shefer@wix.com
         * @memberof Wix.Settings
         * @since 1.45.0
         * @experimental
         * @example
         *
         *
         * Wix.Settings.resizeComponent({
         *    width: 400,
         *    height:600
         * });
         */
        resizeComponent: resizeComponent,

        /**
         * Stores the value, which is a GUID. If a value for the given component did not previously exist, it is created. If it already exists, its existing value is overwritten with the new contents of value.
         * @function
         * @author lior.shefer@wix.com
         * @param {String} guid - GUID value to set
         * @memberof Wix.Settings
         * @since 1.45.0
         * @example
         *
         *
         * Wix.Settings.setExternalId('71e2d60f-421d-4a7f-a63d-d45479b82349');
         */
        setExternalId: setExternalId,

        /**
         * Before showing sensitive information or making an action which requires a secure session,
         * an app should verify that a secure session exists.
         * Get a newly signed app instance by calling Wix.Settings.revalidateSession.
         * @function
         * @memberof Wix.Settings
         * @since 1.47.0
         * @param {Function} onSuccess Receives a newly signed and encoded app instance.
         * @param {Function} onFailure
         * @example
         *
         *
         * Wix.Settings.revalidateSession(function(instanceData){
         *  //handle success use-case
         * }, function(error){
         *    //Handle error use-case
         * });
         */
        revalidateSession: revalidateSession,

        /**
         * The getAnchors method is used to retrieve the anchors found on the current page.
         * By default the method will return the top page anchor on the current page.
         * @function
         * @memberof Wix.Settings
         * @since 1.62.0
         * @param {function} callback - a callback function which receives an array of anchors.
         * @example
         *
         * Wix.Settings.getCurrentPageAnchors(function(anchors) {
         *      // do something with anchors
         * });
         */
        getCurrentPageAnchors: getCurrentPageAnchors,

        /**
         * Sets the widget/page components to full width/exit full width (true/false)
         * @function
         * @memberof Wix.Settings
         * @since 1.81.0
         * @param {Boolean} fullWidth - Set true/false if to set the app as full width or not
         * @param {Object} options can contain margins, margins need to contain values for left and right.
         *                 The values can be defined with px, % (from screen width ) or nothing (default px)
         * @param {function} onSuccess
         * @param {function} onFailure
         * @example
         *
         * Wix.Settings.setFullWidth(true, {margins: {left:'100px',right:'200'}}, function() {..}, function() {...});
         * Wix.Settings.setFullWidth(true, {margins: {left:100,right:'200'}}, function() {..}, function() {...});
         * Wix.Settings.setFullWidth(true, {margins: {left:'20%',right:'200px'}}, function() {..}, function() {...});
         */
        setFullWidth: setFullWidth,

        /**
         * Return true if the app is set to full width and false if not.
         * @function
         * @memberof Wix.Settings
         * @since 1.65.0
         * @param {function} callback
         * @example
         *
         * Wix.Settings.isFullWidth(function() {...});
         */
        isFullWidth: isFullWidth,

        /**
         * Open the reviews tab of the application's info modal
         * @function
         * @memberof Wix.Settings
         * @since 1.65.0
         * @example
         *
         * Wix.Settings.openReviewInfo();
         */
        openReviewInfo: openReviewInfo,

        /**
         * Gets a URL for a given deep-linked state in a given sectionIdentifier. In the editor, gets the public URL for the address.
         *
         * Available from Editor, Preview and Viewer
         *
         * @function
         * @memberOf Wix.Settings
         * @since 1.69.0
         * @param {String} sectionId - the sectionId of the page to deep-link
         * @param {String} state - the deep-linked state
         * @returns {Object} The section url for the given sectionId
         * @example
         *
         * Wix.Settings.getStateUrl("cd1mp", "internal/app/state", function (url) {
         *      // do something with the URL for the state
         * });
         */
        getStateUrl: getStateUrl,

        /**
         * For multi-component apps that would like to know if one if it's components is installed on the site
         *
         * @function
         * @memberOf Wix.Settings
         * @since 1.74.0
         * @param {String} componentId - the id of the component taken from the dev center
         * @param {function} callback - that gets the component status (boolean) as an argument
         *   callback signature: function(isInstalled) {}
         * @example
         *
         * Wix.Settings.isComponentInstalled("compId");
         */
        isComponentInstalled: isComponentInstalled,

        /**
         * Opens the editor link selector panel
         *
         * @function
         * @memberOf Wix.Settings
         * @since 1.81.0
         * @param {object} [options] to open the panel with a previous selected link, a 'link' property with the returned object can be passed
         * @param {function} onSuccess called when the user clicks on the Done button, with an object containing the selected link data
         *   callback signature: function(linkData) {}
         * @param {function} [onCancel] called when the user clicked on the Cancel button
         * @example
         *
         * Wix.Settings.openLinkPanel({
         *  link: {
                  "type": "EmailLink",
                  "recipient": "example@gmail.com",
                  "subject": "title"
                }
         * }, function(linkData) {console.log(linkData)}, function(error){console.log(error))};
         */
        openLinkPanel: openLinkPanel,

        /**
         * Checks if at least one of the application components was added to the site
         *
         * @function
         * @memberOf Wix.Settings
         * @since 1.83.0
         * @param {string} appDefinitionId the id of the app
         * @param {function} callback called with the boolean result
         *   callback signature: function(isInstalled) {}
         * @example
         *
         * Wix.Settings.isApplicationInstalled(
         *          '1380b703-ce81-ff05-f115-39571d94dfcd',
         *          function(isInstalled){console.log(isInstalled)}
         * );
         */
        isApplicationInstalled: isApplicationInstalled
    };
});
