/**
 * This is the description for the Error namespace.
 * @memberof Wix
 * @namespace Wix.Error
 */
define(function () {
    return {
        /**
         * Indicates an unknown error happened on Wix side which could not be recovered. When handling this error, you can try again or prompt the user with an error dialog.
         * @memberof Wix.Error
         * @since 1.27.0
         */
        WIX_ERROR: 'WIX_ERROR',

        /**
         * Indicates the activity could not be found.
         * @memberof Wix.Error
         * @since 1.27.0
         */
        NOT_FOUND: 'NOT_FOUND',

        /**
         * Indicates the dates you provided are in the wrong format or are not valid date ranges.
         * @memberof Wix.Error
         * @since 1.27.0
         */
        BAD_REQUEST: 'BAD_REQUEST',

        /**
         * @memberof Wix.Error
         * @since 1.27.0
         */
        INVALID_SCHEMA: 'INVALID_SCHEMA',

        /**
         * @memberof Wix.Error
         * @since 1.46.0
         */
        FORBIDDEN: 'FORBIDDEN'
    };
});