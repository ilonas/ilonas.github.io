/**
 * This is the description for the Media namespace.
 * @memberof Wix.Utils
 * @namespace Wix.Utils.Media
 */
define(['privates/utils', 'privates/reporter', 'privates/postMessage'], function (utils, reporter, postMessage) {

    var namespace = 'Utils.Media';

    var getWixStatic = function () {
        return 'https://static.wixstatic.com/';
    };

    var getWixMedia = function (prefix) {
        return 'https://' + prefix + '.wixstatic.com/';
    };

    var getImageUrl = function (relativeUrl) {
        postMessage.sendMessage(postMessage.MessageTypes.GET_IMAGE_URL, namespace);
        return getWixStatic() + 'media/' + relativeUrl;
    };

    var getResizedImageUrl = function (imageURI, width, height, params) {
        // assign sharp default parameters
        params = params || {};
        params.quality = params.quality || 85;
        params.usm_r = (params.usm_r || 0.66).toFixed(2);
        params.usm_a = (params.usm_a || 1.00).toFixed(2);
        params.usm_t = (params.usm_t || 0.01).toFixed(2);

        // build the image url
        // e.g. http://static.wixstatic.com/media/12-345.jpg/v1/fill/w_1280,h_720,q_85,usm_0.66_1.00_0.01/12-345.jpg
        var tramsformStr ='';
        // domain
        tramsformStr += getWixStatic() + 'media/';
        // image uri
        tramsformStr += imageURI + '/';
        // api version
        tramsformStr += 'v1/';
        // image transform type - fill
        tramsformStr += 'fill/';
        // target width
        tramsformStr += 'w_' + Math.round(width) + ',';
        // target height
        tramsformStr += 'h_' + Math.round(height) + ',';
        // quality - applicable for jpeg only (no effect otherwise)
        tramsformStr += 'q_' + params.quality + ',';
        // un-sharp mask
        tramsformStr += 'usm_' + params.usm_r + '_' + params.usm_a + '_' + params.usm_t + '/';
        // image uri
        tramsformStr += imageURI;

        postMessage.sendMessage(postMessage.MessageTypes.GET_RESIZED_IMAGE_URL, namespace);

        return tramsformStr;
    };

    var getAudioUrl = function (relativeUrl, audioType) {
        //support for old usage: when no audioType is given should return the standard
        audioType = audioType || AudioType.STANDARD;
        if (!utils.has(AudioType, audioType)) {
            reporter.reportSdkError('Invalid argument - audioType value should be set using Wix.Utils.Media.AudioType');
        }

        postMessage.sendMessage(postMessage.MessageTypes.GET_AUDIO_URL, namespace);

        switch(audioType){
            case AudioType.STANDARD:
                return getWixMedia('music') + 'mp3/' + relativeUrl;
            case AudioType.PREVIEW:
                return getWixStatic() + 'preview/' + relativeUrl;
            case AudioType.SHORT_PREVIEW:
                return getWixStatic() + relativeUrl;
        }
    };

    var getDocumentUrl = function (relativeUrl) {
        postMessage.sendMessage(postMessage.MessageTypes.GET_DOCUMENT_URL, namespace);
        return getWixMedia('docs') + 'ugd/' + relativeUrl;
    };

    var getSwfUrl = function (relativeUrl) {
        postMessage.sendMessage(postMessage.MessageTypes.GET_SWF_URL, namespace);
        return getWixStatic() + 'media/' + relativeUrl;
    };

    var getPreviewSecureMusicUrl = function (previewFileName) {
        postMessage.sendMessage(postMessage.MessageTypes.GET_PREVIEW_SECURE_MUSIC_URL, namespace);
        reporter.reportSdkMsg('Wix.Utils.Media.getPreviewSecureMusicUrl is DEPRECATED please use Wix.Utils.Media.getAudioUrl(\'myFileName.mp3\', Wix.Utils.Media.AudioType.PREVIEW)');
        return getWixStatic() + 'preview/' + previewFileName;
    };

    var AudioType =  {
            STANDARD: 'STANDARD',
            PREVIEW: 'PREVIEW',
            SHORT_PREVIEW: 'SHORT_PREVIEW'
        };

    return {

        /**
         * An enum of audio types that are supported by Wix.Utils.Media.getAudioUrl
         * @enum
         * @memberof Wix.Utils.Media
         * @since 1.45.0
         */
        AudioType: {
            /**
             * Standard mp3 audio file
             * @since 1.45.0
             */
            STANDARD: AudioType.STANDARD,
            /**
             * A full preview of a high-quality audio file playable in the browser
             * @since 1.45.0
             */
            PREVIEW: AudioType.PREVIEW,
            /**
             * A short preview of a high-quality audio file playable in the browser
             * @since 1.45.0
             */
            SHORT_PREVIEW: AudioType.SHORT_PREVIEW
        },


        /**
         * This method constructs a URL for a media item of type image.
         * @function
         * @memberof Wix.Utils.Media
         * @since 1.17.0
         * @param {String} Image item uri (relative to Wix media gallery).
         * @returns {String} A full URL pointing to the Wix static servers of an image with the default dimensions - width and height.
         * @example
         *
         * var imageUrl = Wix.Utils.Media.getImageUrl('relative_url.jpg')
         */
        getImageUrl: getImageUrl,

        /**
         * This method constructs a URL for a media item of type image and let the developer change the image dimensions as well as it's sharpening properties (optional),
         * see sharpening explained here - http://en.wikipedia.org/wiki/Unsharp_masking.
         * @function
         * @memberof Wix.Utils.Media
         * @since 1.17.0
         * @param {String} relativeUrl Static image url provided by the media dialog.
         * @param {Number} width Desired image width.
         * @param {Number} height Desired image height.
         * @param {Object} [sharpParams]
         * @param {Number} sharpParams.quality JPEG quality, leave as is (75) unless image size is important for your app.
         * @param {Number} sharpParams.resizeFilter Resize filter.
         * @param {Number} sharpParams.usm_r Unsharp mask radius.
         * @param {Number} sharpParams.usm_a Unsharp mask amount (percentage).
         * @param {Number} sharpParams.usm_t Unsharp mask threshold.
         * @returns {String} A full URL pointing to the Wix static servers of an image with the custom dimension parameters.
         * @example
         *
         * var resizedImageUrl = Wix.Utils.Media.getResizedImageUrl('relative_url.jpg', 500, 500)
         */
        getResizedImageUrl: getResizedImageUrl,

        /**
         * Constructs an absolute URL for a relative path to an audio file. By default, returns a URL to a standard audio file.
         * @function
         * @memberof Wix.Utils.Media
         * @since 1.81.0
         * @param {String} relativeUri A relative URL to the target audio file.
         * @param {Wix.Utils.Media.AudioType} audioType the type of audio URL to build. Default is Wix.Media.AudioType.STANDARD.
         * @returns {String} An absolute URL pointing to the audio file hosted on Wix's static.
         * @example
         *
         * var audioUrl = Wix.Utils.Media.getAudioUrl('relative_url.mp3', Wix.Utils.Media.AudioType.SHORT_PREVIEW)
         */
        getAudioUrl: getAudioUrl,

        /**
         * This method constructs a URL for a media item of type document.
         * @function
         * @memberof Wix.Utils.Media
         * @since 1.81.0
         * @param {String} relativeUri Document item uri (relative to Wix media gallery).
         * @returns {String} A full URL pointing to the Wix static servers of a document media file with the default dimensions.
         * @example
         *
         * var documentUrl = Wix.Utils.Media.getDocumentUrl('relative_url.pdf')
         */
        getDocumentUrl: getDocumentUrl,

        /**
         * This method constructs a URL for a media item of type swf.
         * @function
         * @memberof Wix.Utils.Media
         * @since 1.17.0
         * @param {String} relativeUri Swf item uri (relative to Wix media gallery).
         * @returns {String} A full URL pointing to the Wix static servers of a swf media file  with the default dimensions.
         * @example
         *
         * var swfUrl = Wix.Utils.Media.getSwfUrl('relative_url.swf')
         */
        getSwfUrl: getSwfUrl,

        /**
         * This method constructs a URL for a media item of type secure music.
         * @function
         * @memberof Wix.Utils.Media
         * @since 1.41.0
         * @param {String} relativeUri secure music item uri (relative to Wix media gallery).
         * @returns {String} A full URL pointing to the Wix static servers of a secure media file.
         * @deprecated
         * @example
         * var preview = Wix.Utils.Media.getPreviewSecureMusicUrl('relative_url.mp3')
         */
        getPreviewSecureMusicUrl: getPreviewSecureMusicUrl

    };
});
