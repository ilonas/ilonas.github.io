/**
 * @memberof Wix
 * @namespace Wix.Data
 */
define(['privates/utils', 'privates/postMessage', 'privates/reporter', 'privates/sharedAPI', 'privates/data'], function(utils, postMessage, reporter, sharedAPI, data) {

    var namespace = 'Data.Public';

    var getMulti = function() {
        data.getMulti(namespace, ...arguments);
    };

    var set = function() {
        data.set(namespace, ...arguments);
    };

    var get = function() {
        data.get(namespace, ...arguments);
    };

    var remove = function() {
        data.remove(namespace, ...arguments);
    };

    return {
        /**
         * An enum of scope types indicates if data is accessible from a specific component or all components of an app
         * @enum
         * @memberof Wix.Data
         * @since 1.61.0
        */
        SCOPE: data.SCOPE,

        /**
         * @memberof Wix.Data
         * @namespace Wix.Data.Public
         */
        Public: {

            /**
             * Stores the value under the key. If the key did not previously exist, it is created.
             * If the key already exists, its existing value is overwritten with the new value.
             * User can set: string, bool, number and json.
             * Data is stored per component unless otherwise stated.
             * Data will only be accessible from the component from which it was set. Data can also be stored globally, in which case it will be available across all components.
             *
             * Available in the components, settings panel, modal and popups (for example: the Manage window) in the Editor.
             * @function
             * @author mayah@wix.com
             * @memberof Wix.Data.Public
             * @since 1.61.0
             * @param {String} key - key of value to set
             * @param {Object | String | Number | Boolean} value - value to set
             * @param {Object} [Options] - Object that contains Wix.Data.SCOPE that indicates if data is accessible by specific comp or all apps comps installed
             * @param {function} [onSuccess] - result will be a JSON Object mirroring the values given
             * @param {Function} [onFailure] the function will return an object that specifies the error that occurred, it will be invoked in the following scenarios:
             *        1. The app exceeded the provided 1K storage space.
             *        2. Invalid value type, valid types are boolean, string, number and JSON.
             *
             * @experimental
             * @example
             *
             * // Will be accessible only from the component from which it was called
             * Wix.Data.Public.set(‘defaultSettings’,
             *   { "menu": {
             *     "showSuccessMsg": true,
             *     "formFields": {
             *         "name": "What is your name?",
             *         "quest": "What is your quest?",
             *         "color": "What is your favorite color?"
             *     }
             *   });
             */
             set: set,

            /**
             * Get a single value that was stored
             *
             * Available from Editor and Viewer, in all components, popups and modals.
             * @function
             * @author mayah@wix.com
             * @memberof Wix.Data.Public
             * @since 1.61.0
             * @param {String} key - key of value to get.
             * @param {Object} [Options] - Object that contains Wix.Data.SCOPE that indicates which scope to get the key from. Default scope is COMPONENT.
             * @param {function} [onSuccess] - result will be the value attached to the key provided. For example: {  key1: value1 }
             * @param {Function} [onFailure] will be invoked when the provided key is not found
             *
             * @experimental
             * @example
             * // returns a key named 'myKey' from the APP scope
             * Wix.Data.Public.get(‘myKey’, { scope: 'APP' }, function(result){
	         *  console.log(result);
             * });
             */
             get: get,

            /**
             * Remove a single value.
             * Future attempts to access this key will raise an exception until something is stored again for this key using one of the set methods.
             *
             * Available in the settings panel, modal and popups (for example: the Manage window) in the Editor.
             * @function
             * @author mayah@wix.com
             * @memberof Wix.Data.Public
             * @since 1.61.0
             * @param {String} key - key of value to remove.
             * @param {Object} [Options] - Object that contains Wix.Data.SCOPE that indicates which scope to remove the key from. Default scope is COMPONENT.
             * @param {function} [onSuccess] - result will be a JSON Object with the key and value that were found. For example: {  key1: value1 }
             * @param {Function} [onFailure] invoked when the provided key is not found
             *
             * @experimental
             * @example
             * // Will remove a key named 'myKey' from the COMPONENT scope
             * Wix.Data.Public.remove(‘myKey’, function(result){
	         *  console.log(result);
             * });
             */
             remove:remove,

            /**
             * Get multiple values.
             * To get multiple values, use the more efficient getMulti method. Pass it an array of keys and it will return a JSON object with those keys and matching values.
             *
             * Available from Editor and Viewer, in all components, popups and modals.
             * @function
             * @author mayah@wix.com
             * @memberof Wix.Data.Public
             * @since 1.61.0
             * @param {Array} keys - array of keys of values to get. All values returned will be from the provided scope.
             * @param {Object} [Options] - Object that contains Wix.Data.SCOPE that indicates which scopes to get the keys from. Default scope is COMPONENT.
             * @param {function} [onSuccess] - result will be a JSON Object with the key and value that were found. For example: {  key1: value1 }
             * @param {Function} [onFailure] invoked when the one of the keys is not found
             *
             * @experimental
             * @example
             * // Returns key1 and key2 from the APP scope
             * Wix.Data.Public.getMulti([‘key1’, ‘key2’], { scope: 'APP' }, function(results){
             *  for(key in results) {
             *      console.log(key + ‘: ‘ + results[key]);
             *  };
             * });
             */
             getMulti: getMulti
        }
    };

});
