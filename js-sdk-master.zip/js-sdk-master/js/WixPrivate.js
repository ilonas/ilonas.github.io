//TODO - dependency order init our core module - need to clean this up
define(['./Wix', 'SuperApps', 'privates/utils'], function (Wix, SuperApps, utils) {
    "use strict";

    const getNamespaceToExport = function () {
        Wix.SuperApps = SuperApps;
        utils.merge(Wix, SuperApps);
        return Wix;
    };

    return getNamespaceToExport();
});