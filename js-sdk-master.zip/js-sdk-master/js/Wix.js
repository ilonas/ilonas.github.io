define(['privates/core', 'Base', 'Billing', 'privates/utils', 'Activities', 'Settings',
        'Contacts', 'Utils', 'Styles', 'Editor', 'Events', 'Error', 'Media', 'WindowOrigin',
        'WindowPlacement', 'Worker', 'PubSub', 'Preview', 'Dashboard', 'Theme', 'Features', 'privates/urlUtils', 'Data', 'Analytics', 'Performance'],
    function (core, Base, Billing, utils, Activities, Settings,
              Contacts, Utils, Styles, Editor, Events, Error, Media, WindowOrigin,
              WindowPlacement, Worker, PubSub, Preview, Dashboard, Theme, Features, urlUtils, Data, Analytics, Performance) {

    core.init({});

    var getNamespaceToExport = function () {
        if (urlUtils.getQueryParameter('endpointType') === 'worker') {
            return {
                Worker: Worker,
                Events: Events,
                Error: Error
            };
        }
        return getDefaultNamespaces();
    };

    var getDefaultNamespaces = function () {
        return {
            Activities: Activities,
            Analytics: Analytics,
            Billing: Billing,
            Contacts: Contacts,
            Dashboard: Dashboard,
            Editor: Editor,
            Error: Error,
            Events: Events,
            Features: Features,
            Media: Media,
            PubSub: PubSub,
            Preview: Preview,
            Settings: Settings,
            Styles: Styles,
            Theme: Theme,
            Utils: Utils,
            Data: Data,
            Performance: Performance,
            WindowOrigin: WindowOrigin,
            WindowPlacement: WindowPlacement,

            openModal: Base.openModal,
            openPopup: Base.openPopup,
            setHeight: Base.setHeight,
            closeWindow: Base.closeWindow,
            scrollTo: Base.scrollTo,
            scrollBy: Base.scrollBy,
            getSiteInfo: Base.getSiteInfo,
            getSitePages: Base.getSitePages,
            getSiteMap: Base.getSiteMap,
            getBoundingRectAndOffsets: Base.getBoundingRectAndOffsets,
            removeEventListener: Base.removeEventListener,
            addEventListener: Base.addEventListener,
            resizeWindow: Base.resizeWindow,
            requestLogin: Base.requestLogin,
            logOutCurrentMember: Base.logOutCurrentMember,
            currentMember: Base.currentMember,
            navigateTo: Base.navigateTo,
            navigateToPage: Base.navigateToPage,
            getCurrentPageId: Base.getCurrentPageId,
            pushState: Base.pushState,
            reportHeightChange: Base.reportHeightChange,
            getStyleParams: Base.getStyleParams,
            getExternalId: Base.getExternalId,
            navigateToComponent: Base.navigateToComponent,
            resizeComponent: Base.resizeComponent,
            revalidateSession: Base.revalidateSession,
            getCurrentPageAnchors: Base.getCurrentPageAnchors,
            navigateToAnchor: Base.navigateToAnchor,
            getComponentInfo: Base.getComponentInfo,
            replaceSectionState: Base.replaceSectionState,
            setPageMetadata: Base.setPageMetadata,
            getStateUrl: Base.getStateUrl,
            getAdsOnPage: Base.getAdsOnPage
        };
    };

    return getNamespaceToExport();

});
