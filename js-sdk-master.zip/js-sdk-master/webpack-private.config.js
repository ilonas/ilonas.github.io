module.exports = require("./make-webpack-config")({
    entry: './js/WixPrivate.js',
    filename: 'wix-private.js'
});