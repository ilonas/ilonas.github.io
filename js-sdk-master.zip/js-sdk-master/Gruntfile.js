module.exports = function (grunt) {
    grunt.initConfig({
        jsdoc : {
            docstrap : {
                src : ['js/modules/*.js', 'README.md'],
                options : {
                    destination : 'jsdoc/docstrap',
                    template : "node_modules/grunt-jsdoc/node_modules/ink-docstrap/template",
                    configure : "config/jsdoc.conf.json"
                }
            }
        },
        webpack: {
            wix: require("./webpack.config.js"),
            wixmin: require("./webpack.config.min.js"),
            wixprivate: require("./webpack-private.config.js"),
            wixprivatemin: require("./webpack-private.config.min.js")
        }
    });

    grunt.loadNpmTasks('grunt-jsdoc');
    grunt.loadNpmTasks('grunt-webpack');

    grunt.registerTask('all', ['jsdoc:docstrap', 'webpack']);
};