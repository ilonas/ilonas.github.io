#Overview#

The Javascript SDK exposes a set of functions that enables the app to communicate with the Wix platform - site or editor.

###Including The Library###

In order to use the SDK you must include the following script tag in your HTML document head:

```html
<script type="text/javascript" src="//static.parastorage.com/services/js-sdk/1.84.0/js/wix-private.js"></script>
```

Once included, your window object will contain a new global Object named Wix from which you could call functions that are used to notify the host site of events in the app.

###Version###

The Javascript SDK is always version-ed. To load a specific version of the SDK you have to change the path appropriately by replacing the version part to the version number you need.

###Structure/Scope###
The Wix Object can be used in all the app's endpoints - widget, page, modal, popup, dashboard and settings. However, some of it's functions make sense only in certain endpoints. The most obvious distinction is the Settings endpoint.

The Settings endpoint is different since it is the only endpoint that resides in the Wix Editor while the others reside in Wix site or the Wix dashboard. For that reason we created a namespace [Wix.Settings](Wix.Settings.html) that holds all the function that are valid in the Settings endpoint.

Another special namespace is the [Wix.Utils](Wix.Utils.html). It provides utility functions that can be called by all endpoints.

Although Wix.Utils is valid for all endpoints (beside Wix.Worker), if the called function doesn't have a meaningful value to return it will return null. E.g Wix.Utils.getOrigCompId() will return null in Widget, Page, Modal or popup and return the original component id in the App Settings endpoint.

